<?php

class Sms {


    public static function africastalking($phoneNumber,$message,$sms="no") {

        if(strlen($phoneNumber)>10){
            $phoneNumber = "91".substr($phoneNumber, -10);
        }else{
            $phoneNumber = "91".$phoneNumber;
        }

        $source = 'en';//Source language
        $target = 'hi';

        $message .= "\n\n".self::translate($source, $target, $message, $type='intl');

        $fields = array(
            'receiver' => $phoneNumber,
            'message' => array('text'=>$message)
        );
        
        $json_string = json_encode($fields);

        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => "http://127.0.0.1:8888/chats/send?id=rCdSwHaTs",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $json_string,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "Accept-Encoding: gzip, deflate"
          ),
        ));
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        
        curl_close($curl);

        $send= true;

        if($sms=="yes"){
            $send = sms($phoneNumber,$message);
        }
        
        if ($err) {
          return false;
        }else {
            return true;
        }

        

    }

    public static function translate($source, $target, $text, $type)
    {
        // Request translation
        $response = self::requestTranslation($source, $target, $text, $type);

        // Clean translation
        $translation = self::getSentencesFromJSON($response);

        return $translation;
    }

    /**
     * Internal function to make the request to the translator service
     *
     * @internal
     *
     * @param string $source
     *            Original language taken from the 'translate' function
     * @param string $target
     *            Target language taken from the ' translate' function
     * @param string $text
     *            Text to translate taken from the 'translate' function
         * @param string $type
         *            'intl' use `translate.google.com` API, 'cn' use 'translate.google.cn' API. (default use translate.google.com)
     *
     * @return object[] The response of the translation service in JSON format
     */
    protected static function requestTranslation($source, $target, $text, $type='intl')
    {
        if($type=='intl'){//use 'translate.google.com' API
            $host='translate.google.com';
        }else{//use 'translate.google.cn' API
            $host='translate.google.cn';
        }

        // Google translate URL
        $url = "https://{$host}/translate_a/single?client=at&dt=t&dt=ld&dt=qca&dt=rm&dt=bd&dj=1&hl=es-ES&ie=UTF-8&oe=UTF-8&inputm=2&otf=2";

        $fields = array(
            'sl' => urlencode($source),
            'tl' => urlencode($target),
            'q' => urlencode($text)
        );

        // URL-ify the data for the POST
        $fields_string = "";
        foreach ($fields as $key => $value) {
            $fields_string .= $key . '=' . $value . '&';
        }

        rtrim($fields_string, '&');

        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_ENCODING, 'UTF-8');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_USERAGENT, 'AndroidTranslate/5.3.0.RC02.130475354-53000263 5.1 phone TRANSLATE_OPM5_TEST_1');

        // Execute post
        $result = curl_exec($ch);

        // Close connection
        curl_close($ch);

        return $result;
    }

    /**
     * Dump of the JSON's response in an array
     *
     * @param string $json
     *            The JSON object returned by the request function
     *
     * @return string A single string with the translation
     */
    protected static function getSentencesFromJSON($json)
    {
        $sentencesArray = json_decode($json, true);
        $sentences = "";

        foreach ($sentencesArray["sentences"] as $s) {
            $sentences .= isset($s["trans"]) ? $s["trans"] : '';
        }

        return $sentences;
    }
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rcds4";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT contact, message, id FROM usermessages WHERE status='Pending'";
$result = $conn->query($sql);
$success = 0;
$failed = 0;

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    //echo "Phone: " . $row["contact"]. " - Message: " . $row["message"]. "<br>";

    $phoneNumber = $row["contact"];
    $message = $row["message"];
    $id = $row["id"];

    $send = new sms();
    if($send->africastalking($phoneNumber,$message)){
        $success++;
        $sql2 = "UPDATE usermessages SET status='Sent' WHERE id=$id";
        $conn->query($sql2);
    }else{
        $failed++;
        $sql2 = "UPDATE usermessages SET status='Failed' WHERE id=$id";
        $conn->query($sql2);
    }
  }
  
/*   $lastsync = date("d-m-Y H:i:s");
  $txt = "Notification Synced at Date: ".$lastsync.", Success: ".$success.", Failed: ".$failed;
  $myfile = file_put_contents('logs.txt', $txt.PHP_EOL , FILE_APPEND | LOCK_EX); */

  echo "Synced...";

} else {
  echo "Synced...";
}
$conn->close();

?>