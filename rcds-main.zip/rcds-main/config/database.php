<?php

return [
    'host'      => env('DB_HOST', 'localhost'),
    'database'  => env('DB_DATABASE', 'land'),
    'username'  => env('DB_USERNAME', 'root'),
    'password'  => env('DB_PASSWORD', ''),
];
