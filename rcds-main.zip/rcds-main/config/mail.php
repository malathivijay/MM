<?php

return [
    'from'  => env('MAIL_SENDER', env('MAIL_USERNAME'))
];
