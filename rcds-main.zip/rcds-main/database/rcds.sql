-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2023 at 06:39 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rcds`
--

-- --------------------------------------------------------

--
-- Table structure for table `accountdetails`
--

CREATE TABLE `accountdetails` (
  `id` int(11) NOT NULL,
  `salary` varchar(10) NOT NULL,
  `bankname` varchar(100) DEFAULT NULL,
  `accountnumber` varchar(50) DEFAULT NULL,
  `ifsccode` varchar(50) DEFAULT NULL,
  `branchaddress` varchar(256) DEFAULT NULL,
  `updatedby` int(11) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accountdetails`
--

INSERT INTO `accountdetails` (`id`, `salary`, `bankname`, `accountnumber`, `ifsccode`, `branchaddress`, `updatedby`, `lastupdate`, `school`, `branch`) VALUES
(5, '18000', 'SBI', '12121212', '3213123123', 'tester', 1, '2022-09-29 11:16:32', 1, 1),
(6, '15000', 'tester', '231312312', '3213123', 'tester', 1, '2022-08-19 21:46:42', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `advance`
--

CREATE TABLE `advance` (
  `sr` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `amount` varchar(256) NOT NULL,
  `balance` varchar(256) NOT NULL,
  `emi` int(11) DEFAULT NULL,
  `comment` varchar(256) DEFAULT NULL,
  `ispaid` int(11) NOT NULL DEFAULT 0,
  `dateadjusted` text DEFAULT NULL,
  `payslipid` int(11) DEFAULT 0,
  `date` date NOT NULL,
  `updateby` int(11) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `advance`
--

INSERT INTO `advance` (`sr`, `id`, `amount`, `balance`, `emi`, `comment`, `ispaid`, `dateadjusted`, `payslipid`, `date`, `updateby`, `lastupdate`, `school`, `branch`) VALUES
(5, 5, '1000', '1000', NULL, 'dGVzdGVy', 1, '', 58, '2022-09-19', 1, '2022-11-03 20:42:38', 1, 1),
(18, 11, '100', '100', NULL, 'TGF0ZSBGaW5l', 0, NULL, 0, '2022-11-07', 5, '2022-11-07 11:04:38', 1, 1),
(19, 11, '200', '200', NULL, 'TGF0ZSBGaW5l', 0, NULL, 0, '2022-11-09', 11, '2022-11-09 15:55:31', 1, 1),
(26, 11, '100', '100', NULL, 'TGF0ZSBGaW5lICggMTE6NTg6NTAgKQ', 0, NULL, 0, '2023-04-06', 11, '2023-04-06 06:28:50', 1, 1),
(30, 1, '100', '100', NULL, 'TGF0ZSBGaW5lICggMTE6MjU6MzEgKQ', 0, NULL, 0, '2023-06-07', 1, '2023-06-07 05:55:31', 1, 1),
(31, 1, '100', '100', NULL, 'TGF0ZSBGaW5lICggMTE6Mjc6NTMgKQ', 0, NULL, 0, '2023-06-07', 1, '2023-06-07 05:57:53', 1, 1),
(34, 5, '1000', '1000', NULL, 'dGVzdGVy', 1, '', 58, '2022-09-19', 1, '2022-11-03 20:42:38', 1, 1),
(36, 5, '100', '100', NULL, 'TGF0ZSBGaW5lICggMDY6NTA6MDggKQ', 0, NULL, 0, '2023-06-10', 5, '2023-06-10 01:20:08', 1, 1),
(37, 5, '100', '100', NULL, 'TGF0ZSBGaW5lICggMTM6NDM6NDYgKQ', 0, NULL, 0, '2023-08-05', 5, '2023-08-05 08:13:46', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE `attachments` (
  `id` int(11) NOT NULL,
  `uploaded_by` int(11) NOT NULL,
  `attachment_for` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `attachment` varchar(256) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `attachments`
--

INSERT INTO `attachments` (`id`, `uploaded_by`, `attachment_for`, `name`, `attachment`, `created_at`) VALUES
(6, 1, 36, 'Learning License', 'A49Svt0FxtdK9vD2T7Ua2ZxGq1gKH8sE.png', '2023-10-04 04:56:33');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `sr` int(255) NOT NULL,
  `id` int(100) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 0,
  `isstarted` int(11) NOT NULL DEFAULT 0,
  `date` date NOT NULL,
  `branch` int(10) NOT NULL,
  `school` int(10) NOT NULL,
  `comment` text DEFAULT NULL,
  `starttime` time DEFAULT NULL,
  `endtime` time DEFAULT NULL,
  `setendtime` time DEFAULT NULL,
  `kmdriven` int(11) DEFAULT NULL,
  `trainingitems` text DEFAULT NULL,
  `customerlink` text DEFAULT NULL,
  `isverified` int(11) DEFAULT 0,
  `customerratings` int(11) DEFAULT NULL,
  `customercomments` text DEFAULT NULL,
  `trainerratings` int(11) DEFAULT NULL,
  `lastupdate` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`sr`, `id`, `status`, `isstarted`, `date`, `branch`, `school`, `comment`, `starttime`, `endtime`, `setendtime`, `kmdriven`, `trainingitems`, `customerlink`, `isverified`, `customerratings`, `customercomments`, `trainerratings`, `lastupdate`) VALUES
(1, 30, 0, 0, '2023-10-03', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(2, 30, 0, 0, '2023-10-04', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(3, 30, 0, 0, '2023-10-05', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(4, 30, 0, 0, '2023-10-06', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(5, 30, 0, 0, '2023-10-07', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(6, 30, 0, 0, '2023-10-09', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(7, 30, 0, 0, '2023-10-10', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(8, 30, 0, 0, '2023-10-11', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(9, 30, 0, 0, '2023-10-12', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(10, 30, 0, 0, '2023-10-13', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(11, 30, 0, 0, '2023-10-14', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(12, 30, 0, 0, '2023-10-16', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(13, 30, 0, 0, '2023-10-17', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(14, 30, 0, 0, '2023-10-18', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(15, 30, 0, 0, '2023-10-19', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(16, 30, 0, 0, '2023-10-20', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(17, 30, 0, 0, '2023-10-21', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(18, 30, 0, 0, '2023-10-23', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(19, 30, 0, 0, '2023-10-24', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(20, 30, 0, 0, '2023-10-25', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(21, 30, 0, 0, '2023-10-26', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(22, 30, 0, 0, '2023-10-27', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(23, 30, 0, 0, '2023-10-28', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(24, 30, 0, 0, '2023-10-30', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(25, 30, 0, 0, '2023-10-31', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(26, 30, 0, 0, '2023-11-01', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(27, 30, 0, 0, '2023-11-02', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50'),
(28, 30, 0, 0, '2023-11-03', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, '2023-10-03 13:27:50');

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `school` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `postalcode` int(11) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `wgroupid` text NOT NULL,
  `type` enum('headquarters','branch') DEFAULT NULL,
  `mstartdate` int(11) NOT NULL,
  `salarydate` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`id`, `name`, `school`, `email`, `address`, `postalcode`, `phone`, `wgroupid`, `type`, `mstartdate`, `salarydate`, `created_at`, `updated_at`) VALUES
(1, 'Headquarters', 1, 'realcardrive@gmail.com', 'Kuber Vatika, Near Rothak Railway Flyover, Sonipat', NULL, '+917419999195', '120363026398884059@g.us', 'headquarters', 4, 4, '2019-01-08 06:51:03', '2019-01-08 06:51:03'),
(7, 'Dallas Texas', 1, 'dallas@example.com', 'Dallas, Texas', NULL, '12345678', '', NULL, 0, 0, NULL, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `branchmessages`
--

CREATE TABLE `branchmessages` (
  `id` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `type` enum('sms','email') NOT NULL,
  `contact` varchar(64) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` longtext DEFAULT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Sent','Failed') NOT NULL DEFAULT 'Sent',
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `classescompleted`
--

CREATE TABLE `classescompleted` (
  `id` int(11) NOT NULL,
  `student` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `instructor` int(11) NOT NULL,
  `date` date NOT NULL,
  `starttime` time NOT NULL,
  `endtime` time DEFAULT NULL,
  `trainercomment` text DEFAULT NULL,
  `isverifiedbycustomer` int(11) NOT NULL DEFAULT 0,
  `customerreview` text DEFAULT NULL,
  `customerrating` int(11) DEFAULT NULL,
  `trainerrating` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `classremainder`
--

CREATE TABLE `classremainder` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `message` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `lastreq` text NOT NULL,
  `sentat` text NOT NULL,
  `remainders` int(11) NOT NULL DEFAULT 1,
  `reply` int(11) DEFAULT 0,
  `repliedat` text DEFAULT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classremainder`
--

INSERT INTO `classremainder` (`id`, `sid`, `message`, `status`, `lastreq`, `sentat`, `remainders`, `reply`, `repliedat`, `school`, `branch`, `lastupdate`) VALUES
(3, 36, 'Greeting from RCDS!!!\n\nKindly confirm if you are available to attend the class scheduled at 12:00 AM today. Also please note if you do not reply to this message we will not come for your class.\n\nKindly Please reply *1* for *Yes* and *2* for *No*!', 1, '2023-08-22 00:42:50', '2023-08-22 00:42:50', 2, 0, NULL, 1, 1, '2023-08-21 19:12:50');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(11) NOT NULL,
  `code` varchar(2) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `code`, `name`) VALUES
(1, 'AF', 'Afghanistan'),
(2, 'AL', 'Albania'),
(3, 'DZ', 'Algeria'),
(4, 'DS', 'American Samoa'),
(5, 'AD', 'Andorra'),
(6, 'AO', 'Angola'),
(7, 'AI', 'Anguilla'),
(8, 'AQ', 'Antarctica'),
(9, 'AG', 'Antigua and Barbuda'),
(10, 'AR', 'Argentina'),
(11, 'AM', 'Armenia'),
(12, 'AW', 'Aruba'),
(13, 'AU', 'Australia'),
(14, 'AT', 'Austria'),
(15, 'AZ', 'Azerbaijan'),
(16, 'BS', 'Bahamas'),
(17, 'BH', 'Bahrain'),
(18, 'BD', 'Bangladesh'),
(19, 'BB', 'Barbados'),
(20, 'BY', 'Belarus'),
(21, 'BE', 'Belgium'),
(22, 'BZ', 'Belize'),
(23, 'BJ', 'Benin'),
(24, 'BM', 'Bermuda'),
(25, 'BT', 'Bhutan'),
(26, 'BO', 'Bolivia'),
(27, 'BA', 'Bosnia and Herzegovina'),
(28, 'BW', 'Botswana'),
(29, 'BV', 'Bouvet Island'),
(30, 'BR', 'Brazil'),
(31, 'IO', 'British Indian Ocean Territory'),
(32, 'BN', 'Brunei Darussalam'),
(33, 'BG', 'Bulgaria'),
(34, 'BF', 'Burkina Faso'),
(35, 'BI', 'Burundi'),
(36, 'KH', 'Cambodia'),
(37, 'CM', 'Cameroon'),
(38, 'CA', 'Canada'),
(39, 'CV', 'Cape Verde'),
(40, 'KY', 'Cayman Islands'),
(41, 'CF', 'Central African Republic'),
(42, 'TD', 'Chad'),
(43, 'CL', 'Chile'),
(44, 'CN', 'China'),
(45, 'CX', 'Christmas Island'),
(46, 'CC', 'Cocos (Keeling) Islands'),
(47, 'CO', 'Colombia'),
(48, 'KM', 'Comoros'),
(49, 'CG', 'Congo'),
(50, 'CK', 'Cook Islands'),
(51, 'CR', 'Costa Rica'),
(52, 'HR', 'Croatia (Hrvatska)'),
(53, 'CU', 'Cuba'),
(54, 'CY', 'Cyprus'),
(55, 'CZ', 'Czech Republic'),
(56, 'DK', 'Denmark'),
(57, 'DJ', 'Djibouti'),
(58, 'DM', 'Dominica'),
(59, 'DO', 'Dominican Republic'),
(60, 'TP', 'East Timor'),
(61, 'EC', 'Ecuador'),
(62, 'EG', 'Egypt'),
(63, 'SV', 'El Salvador'),
(64, 'GQ', 'Equatorial Guinea'),
(65, 'ER', 'Eritrea'),
(66, 'EE', 'Estonia'),
(67, 'ET', 'Ethiopia'),
(68, 'FK', 'Falkland Islands (Malvinas)'),
(69, 'FO', 'Faroe Islands'),
(70, 'FJ', 'Fiji'),
(71, 'FI', 'Finland'),
(72, 'FR', 'France'),
(73, 'FX', 'France, Metropolitan'),
(74, 'GF', 'French Guiana'),
(75, 'PF', 'French Polynesia'),
(76, 'TF', 'French Southern Territories'),
(77, 'GA', 'Gabon'),
(78, 'GM', 'Gambia'),
(79, 'GE', 'Georgia'),
(80, 'DE', 'Germany'),
(81, 'GH', 'Ghana'),
(82, 'GI', 'Gibraltar'),
(83, 'GK', 'Guernsey'),
(84, 'GR', 'Greece'),
(85, 'GL', 'Greenland'),
(86, 'GD', 'Grenada'),
(87, 'GP', 'Guadeloupe'),
(88, 'GU', 'Guam'),
(89, 'GT', 'Guatemala'),
(90, 'GN', 'Guinea'),
(91, 'GW', 'Guinea-Bissau'),
(92, 'GY', 'Guyana'),
(93, 'HT', 'Haiti'),
(94, 'HM', 'Heard and Mc Donald Islands'),
(95, 'HN', 'Honduras'),
(96, 'HK', 'Hong Kong'),
(97, 'HU', 'Hungary'),
(98, 'IS', 'Iceland'),
(99, 'IN', 'India'),
(100, 'IM', 'Isle of Man'),
(101, 'ID', 'Indonesia'),
(102, 'IR', 'Iran (Islamic Republic of)'),
(103, 'IQ', 'Iraq'),
(104, 'IE', 'Ireland'),
(105, 'IL', 'Israel'),
(106, 'IT', 'Italy'),
(107, 'CI', 'Ivory Coast'),
(108, 'JE', 'Jersey'),
(109, 'JM', 'Jamaica'),
(110, 'JP', 'Japan'),
(111, 'JO', 'Jordan'),
(112, 'KZ', 'Kazakhstan'),
(113, 'KE', 'Kenya'),
(114, 'KI', 'Kiribati'),
(115, 'KP', 'Korea, Democratic People\'s Republic of'),
(116, 'KR', 'Korea, Republic of'),
(117, 'XK', 'Kosovo'),
(118, 'KW', 'Kuwait'),
(119, 'KG', 'Kyrgyzstan'),
(120, 'LA', 'Lao People\'s Democratic Republic'),
(121, 'LV', 'Latvia'),
(122, 'LB', 'Lebanon'),
(123, 'LS', 'Lesotho'),
(124, 'LR', 'Liberia'),
(125, 'LY', 'Libyan Arab Jamahiriya'),
(126, 'LI', 'Liechtenstein'),
(127, 'LT', 'Lithuania'),
(128, 'LU', 'Luxembourg'),
(129, 'MO', 'Macau'),
(130, 'MK', 'Macedonia'),
(131, 'MG', 'Madagascar'),
(132, 'MW', 'Malawi'),
(133, 'MY', 'Malaysia'),
(134, 'MV', 'Maldives'),
(135, 'ML', 'Mali'),
(136, 'MT', 'Malta'),
(137, 'MH', 'Marshall Islands'),
(138, 'MQ', 'Martinique'),
(139, 'MR', 'Mauritania'),
(140, 'MU', 'Mauritius'),
(141, 'TY', 'Mayotte'),
(142, 'MX', 'Mexico'),
(143, 'FM', 'Micronesia, Federated States of'),
(144, 'MD', 'Moldova, Republic of'),
(145, 'MC', 'Monaco'),
(146, 'MN', 'Mongolia'),
(147, 'ME', 'Montenegro'),
(148, 'MS', 'Montserrat'),
(149, 'MA', 'Morocco'),
(150, 'MZ', 'Mozambique'),
(151, 'MM', 'Myanmar'),
(152, 'NA', 'Namibia'),
(153, 'NR', 'Nauru'),
(154, 'NP', 'Nepal'),
(155, 'NL', 'Netherlands'),
(156, 'AN', 'Netherlands Antilles'),
(157, 'NC', 'New Caledonia'),
(158, 'NZ', 'New Zealand'),
(159, 'NI', 'Nicaragua'),
(160, 'NE', 'Niger'),
(161, 'NG', 'Nigeria'),
(162, 'NU', 'Niue'),
(163, 'NF', 'Norfolk Island'),
(164, 'MP', 'Northern Mariana Islands'),
(165, 'NO', 'Norway'),
(166, 'OM', 'Oman'),
(167, 'PK', 'Pakistan'),
(168, 'PW', 'Palau'),
(169, 'PS', 'Palestine'),
(170, 'PA', 'Panama'),
(171, 'PG', 'Papua New Guinea'),
(172, 'PY', 'Paraguay'),
(173, 'PE', 'Peru'),
(174, 'PH', 'Philippines'),
(175, 'PN', 'Pitcairn'),
(176, 'PL', 'Poland'),
(177, 'PT', 'Portugal'),
(178, 'PR', 'Puerto Rico'),
(179, 'QA', 'Qatar'),
(180, 'RE', 'Reunion'),
(181, 'RO', 'Romania'),
(182, 'RU', 'Russian Federation'),
(183, 'RW', 'Rwanda'),
(184, 'KN', 'Saint Kitts and Nevis'),
(185, 'LC', 'Saint Lucia'),
(186, 'VC', 'Saint Vincent and the Grenadines'),
(187, 'WS', 'Samoa'),
(188, 'SM', 'San Marino'),
(189, 'ST', 'Sao Tome and Principe'),
(190, 'SA', 'Saudi Arabia'),
(191, 'SN', 'Senegal'),
(192, 'RS', 'Serbia'),
(193, 'SC', 'Seychelles'),
(194, 'SL', 'Sierra Leone'),
(195, 'SG', 'Singapore'),
(196, 'SK', 'Slovakia'),
(197, 'SI', 'Slovenia'),
(198, 'SB', 'Solomon Islands'),
(199, 'SO', 'Somalia'),
(200, 'ZA', 'South Africa'),
(201, 'GS', 'South Georgia South Sandwich Islands'),
(202, 'SS', 'South Sudan'),
(203, 'ES', 'Spain'),
(204, 'LK', 'Sri Lanka'),
(205, 'SH', 'St. Helena'),
(206, 'PM', 'St. Pierre and Miquelon'),
(207, 'SD', 'Sudan'),
(208, 'SR', 'Suriname'),
(209, 'SJ', 'Svalbard and Jan Mayen Islands'),
(210, 'SZ', 'Swaziland'),
(211, 'SE', 'Sweden'),
(212, 'CH', 'Switzerland'),
(213, 'SY', 'Syrian Arab Republic'),
(214, 'TW', 'Taiwan'),
(215, 'TJ', 'Tajikistan'),
(216, 'TZ', 'Tanzania, United Republic of'),
(217, 'TH', 'Thailand'),
(218, 'TG', 'Togo'),
(219, 'TK', 'Tokelau'),
(220, 'TO', 'Tonga'),
(221, 'TT', 'Trinidad and Tobago'),
(222, 'TN', 'Tunisia'),
(223, 'TR', 'Turkey'),
(224, 'TM', 'Turkmenistan'),
(225, 'TC', 'Turks and Caicos Islands'),
(226, 'TV', 'Tuvalu'),
(227, 'UG', 'Uganda'),
(228, 'UA', 'Ukraine'),
(229, 'AE', 'United Arab Emirates'),
(230, 'GB', 'United Kingdom'),
(231, 'US', 'United States'),
(232, 'UM', 'United States minor outlying islands'),
(233, 'UY', 'Uruguay'),
(234, 'UZ', 'Uzbekistan'),
(235, 'VU', 'Vanuatu'),
(236, 'VA', 'Vatican City State'),
(237, 'VE', 'Venezuela'),
(238, 'VN', 'Vietnam'),
(239, 'VG', 'Virgin Islands (British)'),
(240, 'VI', 'Virgin Islands (U.S.)'),
(241, 'WF', 'Wallis and Futuna Islands'),
(242, 'EH', 'Western Sahara'),
(243, 'YE', 'Yemen'),
(244, 'ZR', 'Zaire'),
(245, 'ZM', 'Zambia'),
(246, 'ZW', 'Zimbabwe');

-- --------------------------------------------------------

--
-- Table structure for table `courseinstructor`
--

CREATE TABLE `courseinstructor` (
  `id` int(11) NOT NULL,
  `instructor` int(11) NOT NULL,
  `course` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `duration` int(11) NOT NULL,
  `period` varchar(255) NOT NULL,
  `practical_classes` int(11) NOT NULL,
  `theory_classes` int(11) NOT NULL,
  `status` enum('Available','Unavailable') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `school`, `branch`, `name`, `price`, `image`, `duration`, `period`, `practical_classes`, `theory_classes`, `status`, `created_at`) VALUES
(11, 1, 1, 'Beginner', 7000, 'g1OrnQxVz6Ew0LFflg6NT2YrOdPHpsUw.png', 30, 'Days', 30, 0, 'Available', '2022-07-15 12:47:02'),
(13, 1, 1, 'Intermediate', 3500, 'Q0IlD3JUfiBA4W7bnmykdhMC0HkXm2Li.png', 15, 'Days', 15, 0, 'Available', '2022-07-15 12:53:13'),
(14, 1, 1, 'Intermediate - Fast Track', 3500, 'GePawt0K3PyRINOlID1Sdc46TPQzkR31.png', 7, 'Days', 7, 0, 'Available', '2022-07-15 12:53:49'),
(15, 1, 1, 'Beginner - Fast Track', 7000, '80BeUWmzmju2hqOqpPQD9kBLwsA5NbBL.png', 15, 'Days', 15, 0, 'Available', '2023-01-04 18:15:28');

-- --------------------------------------------------------

--
-- Table structure for table `coursesenrolled`
--

CREATE TABLE `coursesenrolled` (
  `id` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `student` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `total_theory` int(11) NOT NULL,
  `total_practical` int(11) NOT NULL,
  `completed_theory` int(11) NOT NULL DEFAULT 0,
  `completed_practical` int(11) NOT NULL DEFAULT 0,
  `completed_on` date DEFAULT NULL,
  `status` enum('Pending','Complete') NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `coursesenrolled`
--

INSERT INTO `coursesenrolled` (`id`, `school`, `branch`, `student`, `course`, `created_at`, `updated_at`, `total_theory`, `total_practical`, `completed_theory`, `completed_practical`, `completed_on`, `status`) VALUES
(31, 1, 1, 23, 11, '2023-04-13 15:31:56', '2023-04-13 14:36:50', 0, 30, 0, 0, NULL, 'Pending'),
(33, 1, 1, 24, 13, '2023-08-06 15:39:34', '2023-08-06 16:43:09', 0, 15, 0, 0, NULL, 'Pending'),
(34, 1, 1, 30, 11, '2022-07-31 22:11:28', '2023-10-03 17:27:50', 0, 30, 0, 2, NULL, 'Pending'),
(38, 1, 1, 21, 11, '2022-09-21 13:31:54', '2022-11-09 20:44:01', 0, 30, 0, 1, NULL, 'Pending'),
(44, 1, 1, 22, 11, '2022-10-03 13:55:08', '2022-10-03 13:55:08', 0, 30, 0, 0, NULL, 'Pending'),
(45, 1, 1, 32, 11, '2022-10-18 12:45:21', '2022-10-18 12:45:21', 0, 30, 0, 0, NULL, 'Pending'),
(48, 1, 1, 33, 15, '2023-08-06 22:15:43', '2023-08-06 17:54:05', 0, 15, 0, 2, NULL, 'Pending'),
(49, 1, 1, 36, 11, '2023-08-06 22:58:22', '2023-08-11 20:58:30', 0, 30, 0, 0, NULL, 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE `currencies` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `code` varchar(56) NOT NULL,
  `symbol` varchar(19) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`id`, `name`, `code`, `symbol`) VALUES
(1, 'United Arab Emirates Dirham', 'AED', '\\u062f.\\u0625'),
(4, 'Armenia Dram', 'AMD', 'AMD'),
(5, 'Netherlands Antilles Guilder', 'ANG', '\\u0192'),
(7, 'Argentina Peso', 'ARS', '$'),
(8, 'Australia Dollar', 'AUD', '$'),
(9, 'Aruba Guilder', 'AWG', '\\u0192'),
(11, 'Bosnia and Herzegovina Convertible Marka', 'BAM', 'KM'),
(13, 'Bangladesh Taka', 'BDT', 'Tk'),
(15, 'Bahrain Dinar', 'BHD', 'BHD'),
(17, 'Bermuda Dollar', 'BMD', '$'),
(18, 'Brunei Darussalam Dollar', 'BND', '$'),
(19, 'Bolivia Boliviano', 'BOB', '$b'),
(20, 'Brazil Real', 'BRL', 'R$'),
(21, 'Bahamas Dollar', 'BSD', '$'),
(24, 'Botswana Pula', 'BWP', 'P'),
(26, 'Belize Dollar', 'BZD', 'BZ$'),
(27, 'Canada Dollar', 'CAD', '$'),
(29, 'Switzerland Franc', 'CHF', 'CHF'),
(30, 'Chile Peso', 'CLP', '$'),
(31, 'China Yuan Renminbi', 'CNY', '\\xa5'),
(32, 'Colombia Peso', 'COP', 'p.'),
(33, 'Costa Rica Colon', 'CRC', '\\u20a1'),
(34, 'Cuba Convertible Peso', 'CUC', 'CUC'),
(35, 'Cuba Peso', 'CUP', '\\u20b1'),
(37, 'Czech ReKoruna', 'CZK', 'K\\u010d'),
(39, 'Denmark Krone', 'DKK', 'kr'),
(40, 'Dominican RePeso', 'DOP', 'RD$'),
(42, 'Egypt Pound', 'EGP', '\\xa3'),
(45, 'Euro Member Countries', 'EUR', '\\u20ac'),
(48, 'United Kingdom Pound', 'GBP', '\\xa3'),
(52, 'Gibraltar Pound', 'GIP', '\\xa3'),
(55, 'Guatemala Quetzal', 'GTQ', 'Q'),
(57, 'Hong Kong Dollar', 'HKD', 'HK$'),
(58, 'Honduras Lempira', 'HNL', 'L'),
(59, 'Croatia Kuna', 'HRK', 'kn'),
(61, 'Hungary Forint', 'HUF', 'Ft'),
(62, 'Indonesia Rupiah', 'IDR', 'Rp'),
(63, 'Israel Shekel', 'ILS', '\\u20aa'),
(65, 'India Rupee', 'INR', 'Rs'),
(67, 'Iran Rial', 'IRR', 'IRR'),
(68, 'Iceland Krona', 'ISK', 'kr'),
(70, 'Jamaica Dollar', 'JMD', 'J$'),
(71, 'Jordan Dinar', 'JOD', 'JOD'),
(72, 'Japan Yen', 'JPY', '\\xa5'),
(73, 'Kenya Shilling', 'KES', 'KSh'),
(78, 'Korea (South) Won', 'KRW', '\\u20a9'),
(79, 'Kuwait Dinar', 'KWD', '\\u0643'),
(80, 'Cayman Islands Dollar', 'KYD', '$'),
(83, 'Lebanon Pound', 'LBP', '\\xa3'),
(87, 'Lithuania Litas', 'LTL', 'Lt'),
(88, 'Latvia Lat', 'LVL', 'Ls'),
(93, 'Macedonia Denar', 'MKD', '\\u0434\\u0435\\u043d'),
(98, 'Mauritius Rupee', 'MUR', 'Rs'),
(101, 'Mexico Peso', 'MXN', '$'),
(102, 'Malaysia Ringgit', 'MYR', 'RM'),
(107, 'Norway Krone', 'NOK', 'kr'),
(108, 'Nepal Rupee', 'NPR', 'Rs'),
(109, 'New Zealand Dollar', 'NZD', '$'),
(110, 'Oman Rial', 'OMR', 'OMR'),
(112, 'Peru Nuevo Sol', 'PEN', 'S/.'),
(114, 'Philippines Peso', 'PHP', '\\u20b1'),
(115, 'Pakistan Rupee', 'PKR', 'Rs'),
(116, 'Poland Zloty', 'PLN', 'z\\u0142'),
(119, 'Romania New Leu', 'RON', 'lei'),
(121, 'Russia Ruble', 'RUB', '\\u0440\\u0443\\u0431'),
(123, 'Saudi Arabia Riyal', 'SAR', 'SAR'),
(127, 'Sweden Krona', 'SEK', 'kr'),
(128, 'Singapore Dollar', 'SGD', '$'),
(135, 'El Salvador Colon', 'SVC', '$'),
(137, 'Swaziland Lilangeni', 'SZL', 'SZL'),
(138, 'Thailand Baht', 'THB', '\\u0e3f'),
(142, 'Tonga Paanga', 'TOP', 'TOP'),
(143, 'Turkey Lira', 'TRY', 'TRY'),
(147, 'Tanzania Shilling', 'TZS', 'TSh'),
(148, 'Ukraine Hryvna', 'UAH', '\\u20b4'),
(150, 'United States Dollar', 'USD', '$'),
(151, 'Uruguay Peso', 'UYU', '$U'),
(153, 'Venezuela Bolivar', 'VEF', 'Bs'),
(154, 'Viet Nam Dong', 'VND', '\\u20ab'),
(155, 'Vanuatu Vatu', 'VUV', 'VUV'),
(158, 'East Caribbean Dollar', 'XCD', '$'),
(163, 'South Africa Rand', 'ZAR', 'R'),
(164, 'Zimbabwe Dollar', 'ZWD', 'Z$');

-- --------------------------------------------------------

--
-- Table structure for table `dropreading`
--

CREATE TABLE `dropreading` (
  `id` int(11) NOT NULL,
  `car` int(11) NOT NULL,
  `date` date NOT NULL,
  `reading` int(11) NOT NULL,
  `photo` text NOT NULL,
  `recordby` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `branch` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dropreading`
--

INSERT INTO `dropreading` (`id`, `car`, `date`, `reading`, `photo`, `recordby`, `comment`, `branch`, `school`, `lastupdate`) VALUES
(15, 3, '2023-06-11', 41900, 'laDY9tD7ctLa1jzMmStuuUSsTjO949g2.png', 1, 'dGVzdGVyDQozMjE', 1, 1, '2023-09-20 07:35:09'),
(16, 1, '2023-09-29', 321312, 'MDaJH1Q8gGlhRGl8f2aXbeqETCtVizT7.png', 1, 'YWRzZmFkc2Zhcw', 1, 1, '2023-09-29 13:10:25');

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `id` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `retakes` int(11) NOT NULL,
  `description` text NOT NULL,
  `status` enum('Unpublished','Published') NOT NULL DEFAULT 'Unpublished',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `examsreports`
--

CREATE TABLE `examsreports` (
  `id` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `exam` int(11) NOT NULL,
  `student` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `correctlyAnswered` int(11) NOT NULL,
  `totalQuestions` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `car` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  `photo` text NOT NULL,
  `date` date NOT NULL,
  `recordby` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `car`, `type`, `amount`, `photo`, `date`, `recordby`, `comment`, `school`, `branch`, `lastupdate`) VALUES
(1, 3, 'puncher', 90.00, 'f0KMgqgjGJXgN0VzeTp6GTRKtpSifUKj.png', '2023-04-13', 5, 'test', 1, 1, '2023-04-13 10:40:33'),
(5, 2, 'rear', 314.00, 'Bb2gGLMnnxVKR1fAUumLbX2A4HvkCD29.png', '2022-08-19', 1, NULL, 1, 1, '2022-10-03 13:48:00'),
(6, 1, 'service', 1000.00, '14RgnBBVrOHXonOIdopnzlbLE2ViwarH.png', '2022-09-20', 1, 'dGVzdGVy', 1, 1, '2022-09-20 18:42:58'),
(7, 3, 'tester', 100.00, '7NlUYVeFTdCPzfovUof3m5FPWSbWYWfn.png', '2022-09-21', 1, NULL, 1, 1, '2022-10-03 13:48:04'),
(8, 1, '100', 1000.00, 'gVItevAM0uirsQxTP003DMSJNAxsm5HV.png', '2022-09-21', 1, NULL, 1, 1, '2022-10-03 13:48:07'),
(9, 0, 'tester', 900.00, 'UcByu8OwoqpejhXn2Xu24IHUwjMGkQw1.png', '2022-09-21', 1, NULL, 1, 1, '2022-09-20 19:32:04'),
(10, 0, 'service', 100.00, 'Bfb4tVuNmxMJJiIgegMwzjF4ltLvVLqN.png', '2022-10-12', 1, NULL, 1, 1, '2022-10-12 06:10:00'),
(11, 0, 'Services', 2000.00, 'MsQmJFEjjGMVeIbAf8pcwY6QXgepXtu5.png', '2023-06-11', 1, 'ZmxlZXQgc2VydmljZXMgDQp0ZXN0ZXI', 1, 1, '2023-09-20 07:34:53'),
(13, 0, 'etster', 1234.00, 'xv7GKXbCWfvNcOfoywhNP5Ax7lmJMh6S.png', '2023-09-29', 1, 'YXNkZnNkZg', 1, 1, '2023-09-29 13:04:35');

-- --------------------------------------------------------

--
-- Table structure for table `fleet`
--

CREATE TABLE `fleet` (
  `id` int(11) NOT NULL,
  `carno_` varchar(32) NOT NULL,
  `carplate` varchar(255) NOT NULL,
  `nextservice` text DEFAULT NULL,
  `make` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `modelyear` varchar(6) NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `instructor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `fleet`
--

INSERT INTO `fleet` (`id`, `carno_`, `carplate`, `nextservice`, `make`, `model`, `modelyear`, `school`, `branch`, `instructor`) VALUES
(1, '1', 'HR10AL6222', '32312', 'Maruti Suzuki', 'Spresso', '2021', 1, 1, 5),
(2, '2', 'HR10AL8236', '25000', 'Maruti Suzuki', 'Spresso', '2021', 1, 1, 5),
(3, '3', 'HR10AM1017', '30000', 'Maruti Suzuki', 'Spresso', '2021', 1, 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `fleetchecks`
--

CREATE TABLE `fleetchecks` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `checkName` text NOT NULL,
  `createdby` int(11) NOT NULL,
  `lastudpate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fleetchecks`
--

INSERT INTO `fleetchecks` (`id`, `name`, `checkName`, `createdby`, `lastudpate`) VALUES
(1, 'Stearing Cover', 'stearingCover', 1, '2023-05-15 20:00:00'),
(2, 'Car Perfume', 'carPerfuem', 1, '2023-05-15 20:00:00'),
(3, 'Clean Inside', 'cleanInside', 1, '2023-05-15 20:00:00'),
(4, 'Clean Outside', 'cleanOutside', 1, '2023-05-15 20:00:00'),
(5, 'iPad', 'iPad', 1, '2023-05-15 20:00:00'),
(6, 'iPad Charging Cable', 'iPadChargingCable', 1, '2023-05-15 20:00:00'),
(7, 'Internet Dongle', 'internalDongel', 1, '2023-05-15 20:00:00'),
(8, 'Internet Status', 'internetStatus', 1, '2023-05-15 20:00:00'),
(9, 'Camera Status', 'cameraStatus', 1, '2023-05-15 20:00:00'),
(10, 'Camera SD Card', 'cameraSD', 1, '2023-05-15 20:00:00'),
(11, 'Car AC', 'carAC', 1, '2023-05-15 20:00:00'),
(12, 'Trainer Pedal', 'trainerPedal', 1, '2023-05-15 20:00:00'),
(13, 'Trainer Pedal Wire', 'trainerPedalWire', 1, '2023-05-15 20:00:00'),
(14, 'Driver Seat', 'driverSeat', 1, '2023-05-15 20:00:00'),
(15, 'Conductor Sear', 'conducterSeat', 1, '2023-05-15 20:00:00'),
(16, 'Back Seat', 'BackSeat', 1, '2023-05-15 20:00:00'),
(17, 'Driver Floor Matt', 'driverMatt', 1, '2023-05-15 20:00:00'),
(18, 'Conductor Floor Matt', 'conducterMatt', 1, '2023-05-15 20:00:00'),
(19, 'Back Floor Matt', 'backMatt', 1, '2023-05-15 20:00:00'),
(20, 'Driver Side Door Mirror', 'driverSideBackMirror', 1, '2023-05-15 20:00:00'),
(21, 'Conductor Side Door Mirror', 'conducterSideBackMirror', 1, '2023-05-15 20:00:00'),
(22, 'Rear View Mirror', 'middlebackMirror', 1, '2023-05-15 20:00:00'),
(23, 'Wind Shield', 'frontWindShield', 1, '2023-05-15 20:00:00'),
(24, 'Driver Side Door Glass', 'driverSideGlass', 1, '2023-05-15 20:00:00'),
(25, 'Driver Side Back Door Glass', 'driverSideBackGlass', 1, '2023-05-15 20:00:00'),
(26, 'Conductor Side Door Glass', 'conducterSideGlass', 1, '2023-05-15 20:00:00'),
(27, 'Conductor Side Backdoor Glass', 'conducterSideBackGlass', 1, '2023-05-15 20:00:00'),
(28, 'Boot Door Glass', 'backWindShield', 1, '2023-05-15 20:00:00'),
(29, 'Driver Side Wiper', 'rightWiper', 1, '2023-05-15 20:00:00'),
(30, 'Conductor Side Wiper ', 'leftWiper', 1, '2023-05-15 20:00:00'),
(31, 'Driver Side Door Bidding', 'doorBiddingR1', 1, '2023-05-15 20:00:00'),
(32, 'Driver Side Back Door Bidding', 'doorBiddingR2', 1, '2023-05-15 20:00:00'),
(33, 'Conductor Side Door Bidding', 'doorBiddingL1', 1, '2023-05-15 20:00:00'),
(34, 'Conductor Side Back Door Bidding', 'doorBiddingL2', 1, '2023-05-15 20:00:00'),
(35, 'Driver Side Wheelcover', 'wheelCoverR1', 1, '2023-05-15 20:00:00'),
(36, 'Driver Side Back Wheelcover', 'wheelCoverR2', 1, '2023-05-15 20:00:00'),
(37, 'Conductor Side Wheelcover', 'wheelCoverL1', 1, '2023-05-15 20:00:00'),
(38, 'Conductor Side Back Wheelcover', 'wheelCoverL2', 1, '2023-05-15 20:00:00'),
(39, 'Driver Side Wheel AIR', 'volTyreR1', 1, '2023-05-15 20:00:00'),
(40, 'Driver Side Back Wheel AIR', 'volTyreR2', 1, '2023-05-15 20:00:00'),
(41, 'Conductor Side Wheel AIR', 'volTyreL1', 1, '2023-05-15 20:00:00'),
(42, 'Conductor Side Back Wheel AIR', 'volTyreL2', 1, '2023-05-15 20:00:00'),
(43, 'Driver Side Wheel Status', 'sTyreR1', 1, '2023-05-15 20:00:00'),
(44, 'Driver Side Back Wheel Status', 'sTyreR2', 1, '2023-05-15 20:00:00'),
(45, 'Conductor Side Wheel Status', 'sTyreL1', 1, '2023-05-15 20:00:00'),
(46, 'Conductor Side Back Wheel Status', 'sTyreL2', 1, '2023-05-15 20:00:00'),
(47, 'Spare Wheel AIR', 'volSpareTyre', 1, '2023-05-15 20:00:00'),
(48, 'Spare Wheel Status', 'sSpareTyre', 1, '2023-05-15 20:00:00'),
(49, 'Driver Side Headlight', 'headLightR', 1, '2023-05-15 20:00:00'),
(50, 'Conductor Side Headlight', 'headLightL', 1, '2023-05-15 20:00:00'),
(51, 'Driver Side Taillight', 'tailLightR', 1, '2023-05-15 20:00:00'),
(52, 'Conductor Side Taillight', 'tailLightL', 1, '2023-05-15 20:00:00'),
(53, 'Toolkit', 'toolkitStatus', 1, '2023-05-15 20:00:00'),
(54, 'Jack', 'jack', 1, '2023-05-15 20:00:00'),
(55, 'Caution Light', 'cautionTriangle', 1, '2023-05-15 20:00:00'),
(56, 'Engine Oil', 'engineOil', 1, '2023-05-15 20:00:00'),
(57, 'Break Oil', 'breakOil', 1, '2023-05-15 20:00:00'),
(58, 'Coolent Bottle', 'coolentBottle', 1, '2023-05-15 20:00:00'),
(59, 'Readiator Coolent', 'coolentEngine', 1, '2023-05-15 20:00:00'),
(60, 'Water Bottle', 'bottelWater', 1, '2023-05-15 20:00:00'),
(61, 'Battery Water', 'batteryWater', 1, '2023-05-15 20:00:00'),
(62, 'Current ODO', 'currentKM', 1, '2023-05-15 20:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `fleetmaintainancerecords`
--

CREATE TABLE `fleetmaintainancerecords` (
  `id` int(11) NOT NULL,
  `car` int(11) NOT NULL,
  `date` text NOT NULL,
  `stearingCover` text NOT NULL,
  `carPerfuem` text NOT NULL,
  `cleanInside` text NOT NULL,
  `cleanOutside` text NOT NULL,
  `iPad` text NOT NULL,
  `iPadChargingCable` text NOT NULL,
  `internalDongel` text NOT NULL,
  `internetStatus` text NOT NULL,
  `cameraStatus` text NOT NULL,
  `cameraSD` text NOT NULL,
  `carAC` text NOT NULL,
  `trainerPedal` text NOT NULL,
  `trainerPedalWire` text NOT NULL,
  `driverSeat` text NOT NULL,
  `conducterSeat` text NOT NULL,
  `BackSeat` text NOT NULL,
  `driverMatt` text NOT NULL,
  `conducterMatt` text NOT NULL,
  `backMatt` text NOT NULL,
  `driverSideBackMirror` text NOT NULL,
  `conducterSideBackMirror` text NOT NULL,
  `middlebackMirror` text NOT NULL,
  `frontWindShield` text NOT NULL,
  `driverSideGlass` text NOT NULL,
  `driverSideBackGlass` text NOT NULL,
  `conducterSideGlass` text NOT NULL,
  `conducterSideBackGlass` text NOT NULL,
  `backWindShield` text NOT NULL,
  `rightWiper` text NOT NULL,
  `leftWiper` text NOT NULL,
  `doorBiddingR1` text NOT NULL,
  `doorBiddingR2` text NOT NULL,
  `doorBiddingL1` text NOT NULL,
  `doorBiddingL2` text NOT NULL,
  `wheelCoverR1` text NOT NULL,
  `wheelCoverR2` text NOT NULL,
  `wheelCoverL1` text NOT NULL,
  `wheelCoverL2` text NOT NULL,
  `volTyreR1` text NOT NULL,
  `volTyreR2` text NOT NULL,
  `volTyreL1` text NOT NULL,
  `volTyreL2` text NOT NULL,
  `sTyreR1` text NOT NULL,
  `sTyreR2` text NOT NULL,
  `sTyreL1` text NOT NULL,
  `sTyreL2` text NOT NULL,
  `volSpareTyre` text NOT NULL,
  `sSpareTyre` text NOT NULL,
  `headLightR` text NOT NULL,
  `headLightL` text NOT NULL,
  `tailLightR` text NOT NULL,
  `tailLightL` text NOT NULL,
  `toolkitStatus` text NOT NULL,
  `jack` text NOT NULL,
  `cautionTriangle` text NOT NULL,
  `engineOil` text NOT NULL,
  `breakOil` text NOT NULL,
  `coolentBottle` text NOT NULL,
  `coolentEngine` text NOT NULL,
  `bottelWater` text NOT NULL,
  `batteryWater` text NOT NULL,
  `currentKM` text NOT NULL,
  `frontPhoto` text NOT NULL,
  `rightPhoto` text NOT NULL,
  `backPhoto` text NOT NULL,
  `leftPhoto` text NOT NULL,
  `openBonnet` text NOT NULL,
  `comment` text NOT NULL,
  `wcomment` text NOT NULL,
  `score` text NOT NULL,
  `status80to99` int(11) NOT NULL,
  `status60to80` int(11) NOT NULL,
  `status40to60` int(11) NOT NULL,
  `status0to40` int(11) NOT NULL,
  `statusOther` int(11) NOT NULL,
  `createdby` text NOT NULL,
  `createdat` timestamp NOT NULL DEFAULT current_timestamp(),
  `branch` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fleetmaintainancerecords`
--

INSERT INTO `fleetmaintainancerecords` (`id`, `car`, `date`, `stearingCover`, `carPerfuem`, `cleanInside`, `cleanOutside`, `iPad`, `iPadChargingCable`, `internalDongel`, `internetStatus`, `cameraStatus`, `cameraSD`, `carAC`, `trainerPedal`, `trainerPedalWire`, `driverSeat`, `conducterSeat`, `BackSeat`, `driverMatt`, `conducterMatt`, `backMatt`, `driverSideBackMirror`, `conducterSideBackMirror`, `middlebackMirror`, `frontWindShield`, `driverSideGlass`, `driverSideBackGlass`, `conducterSideGlass`, `conducterSideBackGlass`, `backWindShield`, `rightWiper`, `leftWiper`, `doorBiddingR1`, `doorBiddingR2`, `doorBiddingL1`, `doorBiddingL2`, `wheelCoverR1`, `wheelCoverR2`, `wheelCoverL1`, `wheelCoverL2`, `volTyreR1`, `volTyreR2`, `volTyreL1`, `volTyreL2`, `sTyreR1`, `sTyreR2`, `sTyreL1`, `sTyreL2`, `volSpareTyre`, `sSpareTyre`, `headLightR`, `headLightL`, `tailLightR`, `tailLightL`, `toolkitStatus`, `jack`, `cautionTriangle`, `engineOil`, `breakOil`, `coolentBottle`, `coolentEngine`, `bottelWater`, `batteryWater`, `currentKM`, `frontPhoto`, `rightPhoto`, `backPhoto`, `leftPhoto`, `openBonnet`, `comment`, `wcomment`, `score`, `status80to99`, `status60to80`, `status40to60`, `status0to40`, `statusOther`, `createdby`, `createdat`, `branch`, `school`, `lastupdate`) VALUES
(1, 1, '2023-05-26', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', 'I9EKFJjbHcPmyQKcviacLnN4i8s0rd5I.jpeg', 'duh5z6SdiT4XIo9b7RnTkUEqSDGkMkKT.jpeg', 'l4JCnzrCNXlntmBPGbnJqLkCwZbWLCVN.jpeg', 'XUX1zcnevGzJmIYlHN6ExnBJ9waWuejx.jpeg', 'W9jSG13JC8zE8ePMaqBQo48wsmVazi0I.jpeg', 'Z3V5Z3Vr', 'Z3V5Z3Vr', '310', 62, 0, 0, 0, 0, '23', '2023-05-26 17:52:25', 1, 1, '2023-05-26 17:52:25'),
(4, 1, '2023-05-28', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', 'am4muaRwHQmxUIn3iyVKMqYnJ1uMlpyX.jpeg', 'oZJU6KfcDbtj0sOBrZPHweTjosMUML5F.jpeg', '6Rgt8rcpjWWE9xJRYNpqtiAavAlh1lik.jpeg', 'fYjRVFfYp7bkkQiPaXZznKupeClF6OYY.jpeg', 'zLk0b5nTFUriBjM9p8lUpDDxK5vQ1M3z.jpeg', 'dGVzdGVy', 'dGVzdGVy', '310', 62, 0, 0, 0, 0, '1', '2023-05-28 14:55:09', 1, 1, '2023-05-28 14:55:09'),
(5, 1, '2023-05-28', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', 'znQxY8wgC1bs28kxWl9XUg6IktNsYLNo.jpeg', '5GP1NM6ss9lqkrq4ko1UxhTWD09BhWxr.jpeg', 'eQtz8q8vUjt2XS0HDewTPX4xebfwAUCT.jpeg', 'dVnV3qxdnJphE19bnfSPyoDwaitJI4eI.jpeg', 'CJN8MKiQAKfQjeTX8ckvvZNaT1MlyftL.jpeg', 'dGVzdGVy', 'dGVzdGVy', '310', 62, 0, 0, 0, 0, '1', '2023-05-28 15:21:55', 1, 1, '2023-05-28 15:21:55'),
(6, 1, '2023-05-28', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', 'HmsuyQyX9K5EiIBPFZcBerv636nPVBap.jpeg', 'JsWdCELc1tCbTwQW8bSIGapED1qWcGLm.jpeg', '9bwhkE8eDVB2HXUbw3zz67DdNFoJ3zJB.jpeg', 'NbUsBMji6RVZjlKxKHlLUXgfd1y7DarR.jpeg', 'fmyEsdNziAFmp5NlNJD3oiTxhcDHFnS0.jpeg', 'dGVzdGVy', 'dGVzdGVy', '310', 62, 0, 0, 0, 0, '1', '2023-05-28 15:22:04', 1, 1, '2023-05-28 15:22:04'),
(7, 1, '2023-05-28', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', 'iN1Hwwxn8iY2TPbnJaG0xO8G6hWrozCs.jpeg', '2OgkEvIyR3GUHdryeP19yQ9k6r0kW375.jpeg', 'SR2A73lUX0iCnz21zqjRtIur5FK2jWCD.jpeg', '2EhPfC1R7SCKRaPmpBu2lw7UFo8TFSiV.jpeg', 'WCs3eV7QLY6fXRnFr4gePzY2PGjYJdr6.jpeg', 'dGVzdGVy', 'dGVzdGVy', '310', 62, 0, 0, 0, 0, '1', '2023-05-28 15:22:15', 1, 1, '2023-05-28 15:22:15'),
(8, 1, '2023-05-28', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', 'ptE2ezeAcinuuuv6UrDB9EuiKiofurni.jpeg', '4KK61TbNZKOdiZX9tuPRea3hohBm331d.jpeg', 'FVF6zqqWHXoEmE51WvAvzuS6aaOxNzbE.jpeg', 'Hb72QDYHO7rqWrTzRJhIfjypE3R295C8.jpeg', 'bs5l8AUyiytMR6iDoh7WbCS9zmelgLkK.jpeg', 'dGVzdGVy', 'dGVzdGVy', '310', 62, 0, 0, 0, 0, '1', '2023-05-28 15:27:33', 1, 1, '2023-05-28 15:27:33'),
(9, 1, '2023-05-28', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', 'sTKlAxZRHfgV2Ugf4nwnz1DEfaIPhFr4.jpeg', 'axsMkfxvYUWDM3rZNa9qBAILToZ0qJjZ.jpeg', '8KtGbli8dsA1kHksjG7WSOUvEsrpbQIE.jpeg', 'MAJfT7vkVw1hDLudE8lUU19RPSZidk8o.jpeg', 'LsyjR8G3EKuGQPU0SkGkFWDI2uLF2fVu.jpeg', 'dGVzdGVy', 'dGVzdGVy', '310', 62, 0, 0, 0, 0, '1', '2023-05-28 15:30:31', 1, 1, '2023-05-28 15:30:31'),
(10, 1, '2023-05-28', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', '5.5', 'huA0USqb2Y09XKFd1CEeulfus4tBLDuQ.jpeg', 'MWP5HLCrGKztjTGFJAr4XuNHxLMmVRiZ.jpeg', 'jGkzDTFNdhrnQKtDnWR2ekOlbSOb8SyY.jpeg', 'v8k0X0fXmXBx5NbDMaF8yqILoYMcYm91.jpeg', 'yXjJTldILtD8s9Its6llyjSKDyIuHnXV.jpeg', 'dGVzdGVy', 'dGVzdGVy', '310', 62, 0, 0, 0, 0, '1', '2023-05-28 15:30:37', 1, 1, '2023-05-28 15:30:37');

-- --------------------------------------------------------

--
-- Table structure for table `fuel`
--

CREATE TABLE `fuel` (
  `id` int(11) NOT NULL,
  `car` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `date` date NOT NULL,
  `amount` decimal(11,2) NOT NULL,
  `photo` text NOT NULL,
  `odo` text NOT NULL,
  `reading` int(11) NOT NULL,
  `recordby` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fuel`
--

INSERT INTO `fuel` (`id`, `car`, `type`, `date`, `amount`, `photo`, `odo`, `reading`, `recordby`, `comment`, `school`, `branch`, `lastupdate`) VALUES
(3, 1, 1, '2022-08-10', 100.00, 'y8PpGxah5kWnHjtxJeUmc0d3WAc2uT9u.png', '4TQpiaZ6lAmdcXxM1WH9OssBswkvYPIj.png', 312312, 23, 'test', 1, 1, '2022-09-20 11:24:44'),
(4, 1, 1, '2023-04-13', 500.00, 'eFofxLsDJyKf2ZmOzJ03GjU4xffEyTPc.png', 'oA4Xz9FMBYEgNr3zUyCALjs923P6jgDe.png', 34535, 23, 'dGVzdGVyDQp0ZXN0ZXIy', 1, 1, '2023-09-20 07:34:25'),
(5, 1, 1, '2022-08-16', 311.00, 'BTxoQT1qHAt3Lnx6Zqlj0S85RDcfmhU1.png', 'S90AXYS04vZnroljPO0N4b4Lrim7nm4a.png', 31231231, 1, NULL, 1, 1, '2022-08-16 13:29:05'),
(6, 1, 1, '2022-08-19', 232.00, 'sEfiWVi5g1YnY4j6bQhJvdiytdMlB9nT.png', 'Dg1EqFpf6IGv1sVEIc3ymDcYlzageMwW.png', 32131231, 1, 'dGVzdGVyDQp0ZXN0ZXI', 1, 1, '2022-09-20 18:54:35'),
(7, 1, 1, '2023-04-04', 500.00, 'nZknV2H9nRoSc3bMTAglRrqGBJHdjvBw.png', 'kTswcN9XQmn6WZAFbjb2tocXzqiNouA4.png', 100, 1, NULL, 1, 1, '2023-04-06 17:30:52'),
(8, 1, 1, '2023-04-05', 300.00, 'nZknV2H9nRoSc3bMTAglRrqGBJHdjvBw.png', 'kTswcN9XQmn6WZAFbjb2tocXzqiNouA4.png', 250, 1, NULL, 1, 1, '2023-04-06 17:30:52'),
(9, 1, 1, '2023-04-06', 321.00, 'nZknV2H9nRoSc3bMTAglRrqGBJHdjvBw.png', 'kTswcN9XQmn6WZAFbjb2tocXzqiNouA4.png', 430, 1, NULL, 1, 1, '2023-04-06 18:33:33'),
(11, 1, 1, '2023-09-29', 312.00, 'A050uY5iDgBOftIHTdiWObSZyATjRvyx.png', 'LrPkPcV70ieWyCRHlfqvd3mZisRif1RG.png', 321312, 1, 'ZGFzYXM', 1, 1, '2023-09-29 12:18:52');

-- --------------------------------------------------------

--
-- Table structure for table `incentive`
--

CREATE TABLE `incentive` (
  `sr` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `amount` varchar(256) NOT NULL,
  `comment` varchar(256) NOT NULL,
  `ispaid` int(11) NOT NULL DEFAULT 0,
  `dateadjusted` text DEFAULT NULL,
  `payslipid` int(11) DEFAULT 0,
  `date` date NOT NULL,
  `updateby` int(11) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `incentive`
--

INSERT INTO `incentive` (`sr`, `id`, `amount`, `comment`, `ispaid`, `dateadjusted`, `payslipid`, `date`, `updateby`, `lastupdate`, `school`, `branch`) VALUES
(6, 5, '900', 'dGVzdGVy', 1, '', 58, '2022-09-20', 1, '2022-11-03 20:42:38', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `reference` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `student` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `item` varchar(256) NOT NULL,
  `amountpaid` int(11) NOT NULL,
  `discount` int(10) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `reference`, `school`, `branch`, `student`, `amount`, `item`, `amountpaid`, `discount`, `created_at`, `updated_at`) VALUES
(9, 142552, 1, 1, 21, 7000, 'Beginner', 100, 0, '2022-07-17 09:16:04', '2022-08-26 11:50:10'),
(12, 609334, 1, 1, 24, 3500, 'Intermediate', 1000, 0, '2022-07-18 11:39:34', '2022-07-29 13:43:19'),
(13, 143088, 1, 1, 30, 7000, 'Beginner', 4000, 0, '2022-07-31 18:11:28', '2023-09-30 14:09:34'),
(16, 353543, 1, 1, 21, 7000, 'Beginner', 0, 0, '2022-09-21 05:19:28', '0000-00-00 00:00:00'),
(17, 302869, 1, 1, 21, 7000, 'Beginner', 0, 0, '2022-09-21 09:31:54', '0000-00-00 00:00:00'),
(23, 194739, 1, 1, 22, 7000, 'Beginner', 0, 0, '2022-10-03 09:55:08', '0000-00-00 00:00:00'),
(24, 778093, 1, 1, 32, 7000, 'Beginner', 0, 0, '2022-10-18 08:45:21', '0000-00-00 00:00:00'),
(27, 219737, 1, 1, 33, 7000, 'Beginner - Fast Track', 246, 0, '2023-01-04 18:15:43', '2023-04-26 11:14:29'),
(28, 766907, 1, 1, 36, 7000, 'Beginner', 0, 0, '2023-05-24 18:58:22', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `lectureprogress`
--

CREATE TABLE `lectureprogress` (
  `id` int(11) NOT NULL,
  `student` int(11) NOT NULL,
  `lecture` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `class` int(11) NOT NULL,
  `chapter` int(11) NOT NULL,
  `started_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lectures`
--

CREATE TABLE `lectures` (
  `id` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `type` enum('pdf','link','text','downloads','video') NOT NULL,
  `content` text NOT NULL,
  `indexing` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `class` int(11) NOT NULL,
  `chapter` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `license`
--

CREATE TABLE `license` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `type` enum('RTA License','CAR RC','CAR PUC','Rent Agreement','Employee Contract','CAR Insurance','Other Insurance','Recharge','Other Contract','Other License') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `number` text NOT NULL,
  `file` text NOT NULL,
  `updateby` int(11) NOT NULL,
  `start` date NOT NULL,
  `end` date NOT NULL,
  `alertdays` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `license`
--

INSERT INTO `license` (`id`, `name`, `type`, `number`, `file`, `updateby`, `start`, `end`, `alertdays`, `status`, `school`, `branch`, `comment`, `lastupdate`) VALUES
(19, 'License1', 'RTA License', 'dGVzdGVyMjEzMTQxMzIvNTQz', 'goSD1WFIpwfSLg8xQkPtRIECxRXXiImz.jpeg', 1, '2023-04-04', '2023-05-05', '15', 0, 1, 1, 'YXNkYXNk', '2023-04-18 06:25:21'),
(21, 'License1', 'RTA License', 'dGVzdGVyMjEzMQ', 'hjUwmdipmObHwmQQw3GoT4wPaRkmCbFt.jpg', 1, '2022-09-16', '2023-04-30', '15', 1, 1, 1, 'cmVud2Vk', '2023-04-20 19:48:35');

-- --------------------------------------------------------

--
-- Table structure for table `newdrivinglicense`
--

CREATE TABLE `newdrivinglicense` (
  `id` int(11) NOT NULL,
  `student` int(11) NOT NULL,
  `currentstatus` enum('Enrolled','Started','Payment','Processing','Learning','Permanent','Completed') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `timeline` text NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `createdby` text NOT NULL,
  `createdat` timestamp NOT NULL DEFAULT current_timestamp(),
  `comment` text DEFAULT NULL,
  `lastudpate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` int(11) NOT NULL,
  `note_by` int(11) NOT NULL,
  `note_for` int(11) NOT NULL,
  `note` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`id`, `note_by`, `note_for`, `note`, `created_at`) VALUES
(1, 11, 33, 'Date: 2023-04-21 Class has been removed and added completed classs for 2023-04-06 as Mr. Sahil has completed multiple classess on 2023-04-06', '2023-04-06 08:54:25'),
(2, 11, 33, 'Date: 2023-04-20 Class has been removed and added completed classs for 2023-04-06 as Mr. Sahil has completed multiple classess on 2023-04-06', '2023-04-06 08:54:25');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `type` enum('newaccount','payment','delete','message','calendar','update') DEFAULT NULL,
  `class` enum('personal','school','branch','system') NOT NULL,
  `message` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user`, `school`, `branch`, `type`, `class`, `message`, `created_at`) VALUES
(2, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>Mark Angelo</strong>.', '2019-01-27 13:50:27'),
(4, 1, 1, 1, 'payment', 'branch', 'A payment of <strong>$5.00</strong> has been received from <strong>Mark Angelo</strong>.', '2019-01-27 13:50:27'),
(6, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>Vera Watson</strong>.', '2019-01-27 13:51:31'),
(8, 1, 1, 1, 'payment', 'branch', 'A payment of <strong>$4.00</strong> has been received from <strong>Vera Watson</strong>.', '2019-01-27 13:51:31'),
(10, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>Emmah Miles</strong>.', '2019-01-27 13:52:15'),
(12, 1, 1, 1, 'payment', 'branch', 'A payment of <strong>$199.00</strong> has been received from <strong>Mark Angelo</strong>.', '2019-01-27 13:52:36'),
(14, 1, 1, 1, 'payment', 'branch', 'A payment of <strong>$3.00</strong> has been received from <strong>Mark Angelo</strong>.', '2019-01-27 13:52:58'),
(16, 1, 1, 1, 'payment', 'branch', 'A payment of <strong>$12.00</strong> has been received from <strong>Mark Angelo</strong>.', '2019-01-27 13:53:09'),
(18, 1, 1, 1, 'delete', 'branch', 'A payment record of <strong>$12.00</strong> has been deleted by <strong>John Doe</strong>.', '2019-01-27 13:53:14'),
(20, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>Tony Stark</strong>.', '2019-02-11 07:47:44'),
(21, 1, 1, 1, 'message', 'branch', 'SMS sent to all students by <strong>John Doe</strong>.', '2019-04-16 11:58:09'),
(23, 1, 1, 1, 'payment', 'branch', 'A payment of <strong>$6.00</strong> has been received from <strong>Mark Angelo</strong>.', '2019-06-16 14:44:00'),
(25, 1, 1, 1, 'delete', 'branch', 'Invoice #357751 of <strong>$499.00</strong>  has been deleted by <strong>John Doe</strong>.', '2019-06-16 14:54:55'),
(27, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>Sagar Sharma</strong>.', '2022-07-13 08:40:45'),
(29, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>Sagar2 Sag</strong>.', '2022-07-15 13:28:29'),
(31, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>Sagar2 tester</strong>.', '2022-07-15 14:04:30'),
(33, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>Sagar2 tester</strong>.', '2022-07-15 14:06:06'),
(35, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>Sagar Sharma</strong>.', '2022-07-17 09:03:44'),
(36, 21, 1, 1, 'newaccount', 'personal', 'Account created by <strong>Sagar Sharma</strong>', '2022-07-17 09:05:21'),
(37, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>Sagar Sharma</strong>.', '2022-07-17 09:05:21'),
(38, 22, 1, 1, 'newaccount', 'personal', 'Account created by <strong>Sagar Sharma</strong>', '2022-07-18 10:20:56'),
(39, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>Sahil Vashisth</strong>.', '2022-07-18 10:20:56'),
(40, 23, 1, 1, 'newaccount', 'personal', 'Account created by <strong>Sagar Sharma</strong>', '2022-07-18 11:30:41'),
(41, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>Pratham Sharma</strong>.', '2022-07-18 11:30:41'),
(42, 24, 1, 1, 'newaccount', 'personal', 'Account created by <strong>Sagar Sharma</strong>', '2022-07-18 11:36:22'),
(43, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>Sagar2ew Sag</strong>.', '2022-07-18 11:36:22'),
(44, 25, 1, 1, 'newaccount', 'personal', 'Account created by <strong>Sagar Sharma</strong>', '2022-07-20 11:14:17'),
(45, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>Sagar2 Sag</strong>.', '2022-07-20 11:14:17'),
(46, 5, 1, 1, 'update', 'branch', 'New Student account created for <strong>Sagar2 Sag</strong>.', '2022-07-26 14:09:51'),
(47, 1, 1, 1, 'update', 'branch', 'New Student account created for <strong>Sagar2 Sag</strong>.', '2022-07-26 14:12:38'),
(48, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at Time - 26-07-2022 07:49:34 PM</strong>.', '2022-07-26 14:19:34'),
(49, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at Time - 26-07-2022 07:49:34 PM</strong>.', '2022-07-26 14:19:34'),
(50, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at Time - 26-07-2022 10:27:13 PM</strong>.', '2022-07-26 16:57:13'),
(51, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at Time - 26-07-2022 10:27:13 PM</strong>.', '2022-07-26 16:57:13'),
(52, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at Time - 26-07-2022 10:29:10 PM</strong>.', '2022-07-26 16:59:10'),
(53, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at Time - 26-07-2022 10:29:10 PM</strong>.', '2022-07-26 16:59:10'),
(54, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:31:28 PM</strong>.', '2022-07-26 17:01:28'),
(55, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:31:28 PM</strong>.', '2022-07-26 17:01:28'),
(56, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:32:28 PM</strong>.', '2022-07-26 17:02:28'),
(57, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:32:28 PM</strong>.', '2022-07-26 17:02:28'),
(58, 23, 1, 1, 'newaccount', 'personal', 'Account created by <strong>Sagar Sharma</strong>', '2022-07-18 11:30:41'),
(59, 23, 1, 1, 'newaccount', 'personal', 'Account created by <strong>Sagar Sharma</strong>', '2022-07-18 11:30:41'),
(60, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:42:04 PM</strong>.', '2022-07-26 17:12:04'),
(61, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:42:04 PM</strong>.', '2022-07-26 17:12:04'),
(62, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:45:30 PM</strong>.', '2022-07-26 17:15:30'),
(63, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:45:30 PM</strong>.', '2022-07-26 17:15:30'),
(64, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:46:45 PM</strong>.', '2022-07-26 17:16:45'),
(65, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:46:45 PM</strong>.', '2022-07-26 17:16:45'),
(66, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:57:23 PM</strong>.', '2022-07-26 17:27:23'),
(67, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:57:23 PM</strong>.', '2022-07-26 17:27:23'),
(68, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:58:57 PM</strong>.', '2022-07-26 17:28:57'),
(69, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:58:57 PM</strong>.', '2022-07-26 17:28:57'),
(70, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:59:20 PM</strong>.', '2022-07-26 17:29:20'),
(71, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 10:59:20 PM</strong>.', '2022-07-26 17:29:20'),
(72, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 11:00:50 PM</strong>.', '2022-07-26 17:30:50'),
(73, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 26-07-2022 11:00:50 PM</strong>.', '2022-07-26 17:30:50'),
(74, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 27-07-2022 01:03:36 AM</strong>.', '2022-07-26 19:33:36'),
(75, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 27-07-2022 01:03:36 AM</strong>.', '2022-07-26 19:33:36'),
(76, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 27-07-2022 05:50:58 PM</strong>.', '2022-07-27 12:20:58'),
(77, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 27-07-2022 05:50:58 PM</strong>.', '2022-07-27 12:20:58'),
(78, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 28-07-2022 12:27:59 AM</strong>.', '2022-07-27 18:57:59'),
(79, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 28-07-2022 12:27:59 AM</strong>.', '2022-07-27 18:57:59'),
(80, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 28-07-2022 12:42:46 AM</strong>.', '2022-07-27 19:12:46'),
(81, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 28-07-2022 12:42:46 AM</strong>.', '2022-07-27 19:12:46'),
(82, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:13:46 AM</strong>.', '2022-07-28 18:43:46'),
(83, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:13:46 AM</strong>.', '2022-07-28 18:43:46'),
(84, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:20:30 AM</strong>.', '2022-07-28 18:50:30'),
(85, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:20:30 AM</strong>.', '2022-07-28 18:50:30'),
(86, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:45:09 AM</strong>.', '2022-07-28 19:15:09'),
(87, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:45:09 AM</strong>.', '2022-07-28 19:15:09'),
(88, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:48:19 AM</strong>.', '2022-07-28 19:18:19'),
(89, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:48:19 AM</strong>.', '2022-07-28 19:18:19'),
(90, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:49:30 AM</strong>.', '2022-07-28 19:19:30'),
(91, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:49:30 AM</strong>.', '2022-07-28 19:19:30'),
(92, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:50:05 AM</strong>.', '2022-07-28 19:20:05'),
(93, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:50:05 AM</strong>.', '2022-07-28 19:20:05'),
(94, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:50:39 AM</strong>.', '2022-07-28 19:20:39'),
(95, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:50:39 AM</strong>.', '2022-07-28 19:20:39'),
(96, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:51:08 AM</strong>.', '2022-07-28 19:21:08'),
(97, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:51:08 AM</strong>.', '2022-07-28 19:21:08'),
(98, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:52:18 AM</strong>.', '2022-07-28 19:22:18'),
(99, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:52:18 AM</strong>.', '2022-07-28 19:22:18'),
(100, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:54:16 AM</strong>.', '2022-07-28 19:24:16'),
(101, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:54:16 AM</strong>.', '2022-07-28 19:24:16'),
(102, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:54:32 AM</strong>.', '2022-07-28 19:24:32'),
(103, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:54:32 AM</strong>.', '2022-07-28 19:24:32'),
(104, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:54:47 AM</strong>.', '2022-07-28 19:24:47'),
(105, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:54:47 AM</strong>.', '2022-07-28 19:24:47'),
(106, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:55:52 AM</strong>.', '2022-07-28 19:25:52'),
(107, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:55:52 AM</strong>.', '2022-07-28 19:25:52'),
(108, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:56:26 AM</strong>.', '2022-07-28 19:26:26'),
(109, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 12:56:26 AM</strong>.', '2022-07-28 19:26:26'),
(110, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 05:13:58 PM</strong>.', '2022-07-29 11:43:58'),
(111, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 05:13:58 PM</strong>.', '2022-07-29 11:43:58'),
(112, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 05:20:06 PM</strong>.', '2022-07-29 11:50:06'),
(113, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 05:20:06 PM</strong>.', '2022-07-29 11:50:06'),
(114, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 05:42:23 PM</strong>.', '2022-07-29 12:12:23'),
(115, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 05:42:23 PM</strong>.', '2022-07-29 12:12:23'),
(116, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 05:43:11 PM</strong>.', '2022-07-29 12:13:11'),
(117, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 05:43:11 PM</strong>.', '2022-07-29 12:13:11'),
(118, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 05:49:56 PM</strong>.', '2022-07-29 12:19:56'),
(119, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 05:49:56 PM</strong>.', '2022-07-29 12:19:56'),
(120, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 05:51:10 PM</strong>.', '2022-07-29 12:21:10'),
(121, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 05:51:10 PM</strong>.', '2022-07-29 12:21:10'),
(122, 30, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 06:08:14 PM</strong>.', '2022-07-29 12:38:14'),
(123, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 29-07-2022 06:08:14 PM</strong>.', '2022-07-29 12:38:14'),
(124, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 12:53:45 AM</strong>.', '2022-08-23 19:23:45'),
(125, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 12:53:45 AM</strong>.', '2022-08-23 19:23:45'),
(126, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 01:11:03 AM</strong>.', '2022-08-23 19:41:03'),
(127, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 01:11:03 AM</strong>.', '2022-08-23 19:41:03'),
(128, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 01:32:05 AM</strong>.', '2022-08-23 20:02:05'),
(129, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 01:32:05 AM</strong>.', '2022-08-23 20:02:05'),
(130, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 01:36:49 AM</strong>.', '2022-08-23 20:06:49'),
(131, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 01:36:49 AM</strong>.', '2022-08-23 20:06:49'),
(132, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 01:36:57 AM</strong>.', '2022-08-23 20:06:57'),
(133, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 01:36:57 AM</strong>.', '2022-08-23 20:06:57'),
(134, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 01:41:54 AM</strong>.', '2022-08-23 20:11:54'),
(135, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 01:41:54 AM</strong>.', '2022-08-23 20:11:54'),
(136, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 01:42:03 AM</strong>.', '2022-08-23 20:12:03'),
(137, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 01:42:03 AM</strong>.', '2022-08-23 20:12:03'),
(138, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 03:50:27 PM</strong>.', '2022-08-24 10:20:27'),
(139, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 03:50:27 PM</strong>.', '2022-08-24 10:20:27'),
(140, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 03:54:15 PM</strong>.', '2022-08-24 10:24:15'),
(141, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 03:54:15 PM</strong>.', '2022-08-24 10:24:15'),
(142, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 03:55:01 PM</strong>.', '2022-08-24 10:25:01'),
(143, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 03:55:01 PM</strong>.', '2022-08-24 10:25:01'),
(144, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 03:56:28 PM</strong>.', '2022-08-24 10:26:28'),
(145, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 03:56:28 PM</strong>.', '2022-08-24 10:26:28'),
(146, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 03:58:05 PM</strong>.', '2022-08-24 10:28:05'),
(147, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 03:58:05 PM</strong>.', '2022-08-24 10:28:05'),
(148, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 03:58:54 PM</strong>.', '2022-08-24 10:28:54'),
(149, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 03:58:54 PM</strong>.', '2022-08-24 10:28:54'),
(150, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 04:00:14 PM</strong>.', '2022-08-24 10:30:14'),
(151, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 04:00:14 PM</strong>.', '2022-08-24 10:30:14'),
(152, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 04:04:04 PM</strong>.', '2022-08-24 10:34:04'),
(153, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 04:04:04 PM</strong>.', '2022-08-24 10:34:04'),
(154, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 04:05:45 PM</strong>.', '2022-08-24 10:35:45'),
(155, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 04:05:45 PM</strong>.', '2022-08-24 10:35:45'),
(156, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 04:08:56 PM</strong>.', '2022-08-24 10:38:56'),
(157, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 04:08:56 PM</strong>.', '2022-08-24 10:38:56'),
(158, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 04:10:04 PM</strong>.', '2022-08-24 10:40:04'),
(159, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 04:10:04 PM</strong>.', '2022-08-24 10:40:04'),
(160, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 04:10:33 PM</strong>.', '2022-08-24 10:40:33'),
(161, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 04:10:33 PM</strong>.', '2022-08-24 10:40:33'),
(162, 32, 1, 1, 'newaccount', 'personal', 'Account created by <strong>Sagar Sharma</strong>', '2022-08-24 12:26:34'),
(163, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>suni master</strong>.', '2022-08-24 12:26:34'),
(164, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 05:57:48 PM</strong>.', '2022-08-24 12:27:48'),
(165, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 24-08-2022 05:57:48 PM</strong>.', '2022-08-24 12:27:48'),
(166, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 01-09-2022 06:19:20 PM</strong>.', '2022-09-01 12:49:20'),
(167, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 01-09-2022 06:19:20 PM</strong>.', '2022-09-01 12:49:20'),
(168, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 01-09-2022 06:22:57 PM</strong>.', '2022-09-01 12:52:57'),
(169, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 01-09-2022 06:22:57 PM</strong>.', '2022-09-01 12:52:57'),
(170, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 17-09-2022 02:14:10 PM</strong>.', '2022-09-17 08:44:10'),
(171, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 17-09-2022 02:14:10 PM</strong>.', '2022-09-17 08:44:10'),
(172, 33, 1, 1, 'newaccount', 'personal', 'Account created by <strong>Sagar Sharma</strong>', '2022-10-01 12:36:25'),
(173, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>tester tester</strong>.', '2022-10-01 12:36:25'),
(174, 34, 1, 1, 'newaccount', 'personal', 'Account created by <strong>Sagar Sharma</strong>', '2022-10-03 11:59:55'),
(175, 1, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>Sagar 2</strong>.', '2022-10-03 11:59:55'),
(176, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 18-10-2022 02:12:50 PM</strong>.', '2022-10-18 08:42:50'),
(177, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sagar attendance at 18-10-2022 02:12:50 PM</strong>.', '2022-10-18 08:42:50'),
(178, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>suni attendance at 18-10-2022 02:17:20 PM</strong>.', '2022-10-18 08:47:20'),
(179, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>suni attendance at 18-10-2022 02:17:20 PM</strong>.', '2022-10-18 08:47:20'),
(180, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>suni attendance at 18-10-2022 03:21:33 PM</strong>.', '2022-10-18 09:51:33'),
(181, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>suni attendance at 18-10-2022 03:21:33 PM</strong>.', '2022-10-18 09:51:33'),
(182, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>suni attendance at 18-10-2022 03:24:12 PM</strong>.', '2022-10-18 09:54:12'),
(183, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>suni attendance at 18-10-2022 03:24:12 PM</strong>.', '2022-10-18 09:54:12'),
(184, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>suni attendance at 18-10-2022 03:25:14 PM</strong>.', '2022-10-18 09:55:14'),
(185, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>suni attendance at 18-10-2022 03:25:14 PM</strong>.', '2022-10-18 09:55:14'),
(186, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>suni attendance at 18-10-2022 04:29:35 PM</strong>.', '2022-10-18 10:59:35'),
(187, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>suni attendance at 18-10-2022 04:29:35 PM</strong>.', '2022-10-18 10:59:35'),
(188, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>suni attendance at 18-10-2022 04:43:12 PM</strong>.', '2022-10-18 11:13:12'),
(189, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>suni attendance at 18-10-2022 04:43:12 PM</strong>.', '2022-10-18 11:13:12'),
(190, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sahil attendance at 29-10-2022 04:09:35 PM</strong>.', '2022-10-29 10:39:35'),
(191, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>Sahil attendance at 29-10-2022 04:09:35 PM</strong>.', '2022-10-29 10:39:35'),
(192, 23, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>suni attendance at 19-04-2023 03:03:49 PM</strong>.', '2023-04-19 09:33:49'),
(193, 1, 1, 1, 'update', 'school', 'Trainer - Hemanth () has resetted the \r\n      <strong>suni attendance at 19-04-2023 03:03:49 PM</strong>.', '2023-04-19 09:33:49'),
(194, 36, 1, 1, 'newaccount', 'personal', 'Account created by <strong>Pratham Sharma</strong>', '2023-05-24 18:00:36'),
(195, 23, 1, 1, 'newaccount', 'branch', 'New Student account created for <strong>test123 hello</strong>.', '2023-05-24 18:00:36');

-- --------------------------------------------------------

--
-- Table structure for table `onlineclasschapters`
--

CREATE TABLE `onlineclasschapters` (
  `id` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `class` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `indexing` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `onlineclasses`
--

CREATE TABLE `onlineclasses` (
  `id` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `status` enum('Unpublished','Published') NOT NULL DEFAULT 'Unpublished',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `paymentlinks`
--

CREATE TABLE `paymentlinks` (
  `id` int(11) NOT NULL,
  `platform` text NOT NULL,
  `course` int(11) NOT NULL,
  `paymentlink` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `amount` int(11) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `branch` int(11) NOT NULL,
  `school` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paymentlinks`
--

INSERT INTO `paymentlinks` (`id`, `platform`, `course`, `paymentlink`, `status`, `amount`, `lastupdate`, `branch`, `school`) VALUES
(1, 'Instamojo', 11, 'https://imjo.in/SW3YwP', 1, 7000, '2022-10-01 20:55:48', 1, 1),
(2, 'Instamojo', 12, 'https://imjo.in/WrTaex', 1, 7000, '2022-10-01 20:56:34', 1, 1),
(3, 'Instamojo', 13, 'https://imjo.in/yz9A6A', 1, 3500, '2022-10-01 20:57:10', 1, 1),
(5, 'Instamojo', 14, 'https://imjo.in/2fy5Tw', 1, 3500, '2022-10-01 21:08:46', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `student` int(11) NOT NULL,
  `invoice` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `method` varchar(64) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `school`, `branch`, `student`, `invoice`, `amount`, `method`, `created_at`) VALUES
(12, 1, 1, 24, 12, 1000, 'Cash', '2022-07-18 11:39:34'),
(25, 1, 1, 21, 9, 100, 'Cash', '2023-04-13 08:00:00'),
(29, 1, 1, 33, 27, 123, 'Cash', '2023-04-12 08:00:00'),
(30, 1, 1, 33, 27, 123, 'Cash', '2023-04-12 08:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `payslips`
--

CREATE TABLE `payslips` (
  `id` int(11) NOT NULL,
  `userid` int(10) NOT NULL,
  `date` int(11) NOT NULL DEFAULT 1,
  `month` text NOT NULL,
  `year` text NOT NULL,
  `salary` text NOT NULL,
  `damount` text NOT NULL DEFAULT '0',
  `dadjusted` text DEFAULT NULL,
  `famount` text NOT NULL,
  `pf` int(20) NOT NULL DEFAULT 0,
  `arear` int(20) DEFAULT 0,
  `incentive` text NOT NULL DEFAULT '0',
  `branch` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `pdays` text NOT NULL,
  `adays` text NOT NULL DEFAULT '0',
  `hdays` text NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT 0,
  `paymentdate` date DEFAULT NULL,
  `pmethod` enum('Cash','Bank','GPay','Paytm','PhonePay','Other') DEFAULT NULL,
  `incometax` int(20) NOT NULL DEFAULT 0,
  `ptax` int(20) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payslips`
--

INSERT INTO `payslips` (`id`, `userid`, `date`, `month`, `year`, `salary`, `damount`, `dadjusted`, `famount`, `pf`, `arear`, `incentive`, `branch`, `school`, `pdays`, `adays`, `hdays`, `status`, `paymentdate`, `pmethod`, `incometax`, `ptax`, `created_at`, `created_by`, `lastupdate`) VALUES
(58, 5, 1, '09', '2022', '18000', '1000', '5,', '17600', 0, 0, '900', 1, 1, '29.5', '0', '0.5', 0, NULL, NULL, 0, 0, '2022-11-03 20:42:38', 1, '2022-11-03 20:42:38');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(3) NOT NULL,
  `permission` varchar(39) DEFAULT NULL,
  `permissioncol` varchar(38) DEFAULT NULL,
  `filename` varchar(24) DEFAULT NULL,
  `startline` int(4) DEFAULT NULL,
  `endline` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `permission`, `permissioncol`, `filename`, `startline`, `endline`) VALUES
(1, 'Amdashboard@get', 'Amdashboardget', 'Amdashboard.php ', 17, 78),
(2, 'Amdashboard@fuelexpenses', 'Amdashboardfuelexpanses', 'Amdashboard.php ', 86, 193),
(3, 'Amdashboard@deletefuelexpenses', 'Amdashboarddeletefuelexpenses', 'Amdashboard.php ', 200, 234),
(4, 'Amdashboard@otherexpenses', 'Amdashboardotherexpenses', 'Amdashboard.php ', 242, 327),
(5, 'Amdashboard@deleteotherexpenses', 'Amdashboarddeleteotherexpenses', 'Amdashboard.php ', 334, 367),
(6, 'Amdashboard@servicerecords', 'Amdashboardservicerecords', 'Amdashboard.php ', 374, 477),
(7, 'Amdashboard@deleteservicerecords', 'Amdashboarddeleteservicerecords', 'Amdashboard.php ', 484, 499),
(8, 'Amdashboard@updateservicerecord', 'Amdashboardupdateservicerecord', 'Amdashboard.php ', 508, 544),
(9, 'Amdashboard@dropout', 'Amdashboarddropout', 'Amdashboard.php ', 551, 616),
(10, 'Amdashboard@deletedropout', 'Amdashboarddeletedropout', 'Amdashboard.php ', 623, 652),
(11, 'Amdashboard@updatexpenses', 'Amdashboardupdatexpenses', 'Amdashboard.php ', 659, 956),
(12, 'Attendance@get', 'Attendanceget', 'Attendance.php', 16, 126),
(13, 'Attendance@present', 'Attendancepresent', 'Attendance.php', 130, 169),
(14, 'Auth@get', 'Authget', 'Auth.php', 14, 29),
(15, 'Auth@signin', 'Authsignin', 'Auth.php', 37, 45),
(16, 'Auth@signup', 'Authsignup', 'Auth.php', 52, 94),
(17, 'Auth@forgot', 'Authforgot', 'Auth.php', 101, 104),
(18, 'Auth@resetview', 'Authresetview', 'Auth.php', 111, 115),
(19, 'Auth@reset', 'Authreset', 'Auth.php', 122, 126),
(20, 'Auth@signout', 'Authsignout', 'Auth.php', 133, 137),
(21, 'Branch@get', 'Branchget', 'Branch.php', 16, 34),
(22, 'Branch@create', 'Branchcreate', 'Branch.php', 42, 53),
(23, 'Branch@delete', 'Branchdelete', 'Branch.php', 61, 70),
(24, 'Branch@updateview', 'Branchupdateview', 'Branch.php', 77, 80),
(25, 'Branch@update', 'Branchupdate', 'Branch.php', 87, 99),
(26, 'Branch@sendemail', 'Branchsendemail', 'Branch.php', 107, 136),
(27, 'Branch@sendsms', 'Branchsendesms', 'Branch.php', 143, 218),
(28, 'Branch@switcher', 'Branchswitcher', 'Branch.php', 225, 233),
(29, 'Cancelled@get', 'Cancelledget', 'Cancelled.php', 16, 68),
(30, 'Classes@get', 'Classesget', 'Classes.php', 18, 81),
(31, 'Classsummary@get', 'Classsummaryget', 'Classsummary.php', 18, 63),
(32, 'Communication@get', 'Communicationget', 'Communication.php', 18, 35),
(33, 'Communication@sms', 'Communicationsms', 'Communication.php', 42, 149),
(34, 'Communication@email', 'Communicationemail', 'Communication.php', 156, 227),
(35, 'Communication@read', 'Communicationread', 'Communication.php', 236, 245),
(36, 'Communication@delete', 'Communicationdelete', 'Communication.php', 253, 262),
(37, 'Completed@get', 'Completedget', 'Completed.php', 16, 67),
(38, 'Controller@middleware', 'Controllermiddleware', 'Controller.php', 12, 18),
(39, 'Course@get', 'Courseget', 'Course.php', 16, 37),
(40, 'Course@create', 'Coursecreate', 'Course.php', 45, 80),
(41, 'Course@createonline', 'Coursecreateonline', 'Course.php', 88, 100),
(42, 'Course@delete', 'Coursedelete', 'Course.php', 107, 114),
(43, 'Course@deletecontent', 'Coursedeletecontent', 'Course.php', 121, 135),
(44, 'Course@loadlecture', 'Courseloadlecture', 'Course.php', 142, 160),
(45, 'Course@deletecurriculum', 'Coursedeletecurriculum', 'Course.php', 167, 175),
(46, 'Course@deleteuploads', 'Coursedeleteuploads', 'Course.php', 182, 187),
(47, 'Course@updateview', 'Courseupdateview', 'Course.php', 194, 204),
(48, 'Course@update', 'Courseupdate', 'Course.php', 211, 247),
(49, 'Course@editonlineclass', 'Courseeditonlineclass', 'Course.php', 254, 262),
(50, 'Course@publishclass', 'Coursepublishclass', 'Course.php', 269, 281),
(51, 'Course@preview', 'Coursepreview', 'Course.php', 290, 323),
(52, 'Course@curriculum', 'Coursecurriculum', 'Course.php', 332, 352),
(53, 'Course@learn', 'Courselearn', 'Course.php', 361, 386),
(54, 'Course@classstudents', 'Courseclassstudents', 'Course.php', 395, 408),
(55, 'Course@updatecontent', 'Courseupdatecontent', 'Course.php', 417, 487),
(56, 'Course@sections', 'Coursesections', 'Course.php', 494, 506),
(57, 'Dailyupdates@get', 'Dailyupdatesget', 'Dailyupdates.php', 17, 54),
(58, 'Dailyupdates@fuelexpenses', 'Dailyupdatesfuelexpenses', 'Dailyupdates.php', 61, 168),
(59, 'Dailyupdates@deletefuelexpenses', 'Dailyupdatesdeletefuelexpenses', 'Dailyupdates.php', 175, 209),
(60, 'Dailyupdates@otherexpenses', 'Dailyupdatesotherexpenses', 'Dailyupdates.php', 217, 302),
(61, 'Dailyupdates@deleteotherexpenses', 'Dailyupdatesdeleteotherexpenses', 'Dailyupdates.php', 309, 342),
(62, 'Dailyupdates@servicerecords', 'Dailyupdatesservicerecords', 'Dailyupdates.php', 349, 452),
(63, 'Dailyupdates@deleteservicerecords', 'Dailyupdatesdeleteservicerecords', 'Dailyupdates.php', 459, 474),
(64, 'Dailyupdates@updateservicerecord', 'Dailyupdatesupdateservicerecord', 'Dailyupdates.php', 483, 519),
(65, 'Dailyupdates@dropout', 'Dailyupdatesdropout', 'Dailyupdates.php', 526, 591),
(66, 'Dailyupdates@deletedropout', 'Dailyupdatesdeletedropout', 'Dailyupdates.php', 598, 627),
(67, 'Dailyupdates@updateexpenses', 'Dailyupdatesupdateexpenses', 'Dailyupdates.php', 634, 931),
(68, 'Dashboard@get', 'Dashboardget', 'Dashboard.php', 14, 39),
(69, 'Dashboard@totals', 'Dashboardtotals', 'Dashboard.php', 46, 64),
(70, 'Dashboard@previous', 'Dashboardprevious', 'Dashboard.php', 71, 95),
(71, 'Dashboard@current', 'Dashboardcurrent', 'Dashboard.php', 102, 124),
(72, 'Dashboard@growth', 'Dashboardgrowth', 'Dashboard.php', 131, 158),
(73, 'Dashboard@students', 'Dashboardstudents', 'Dashboard.php', 165, 183),
(74, 'Dashboard@expenses', 'Dashboardexpenses', 'Dashboard.php', 190, 208),
(75, 'Dashboard@invoices', 'Dashboardinvoices', 'Dashboard.php', 215, 235),
(76, 'Dashboard@notifications', 'Dashboardnotifications', 'Dashboard.php', 242, 250),
(77, 'Dashboard@courses', 'Dashboardcourses', 'Dashboard.php', 257, 269),
(78, 'Exam@create', 'Examcreate', 'Exam.php', 17, 30),
(79, 'Exam@update', 'Examupdate', 'Exam.php', 38, 46),
(80, 'Exam@delete', 'Examdelete', 'Exam.php', 53, 67),
(81, 'Exam@publish', 'Exampublish', 'Exam.php', 77, 89),
(82, 'Exam@builder', 'Exambuilder', 'Exam.php', 97, 117),
(83, 'Exam@takeexam', 'Examtakeexam', 'Exam.php', 125, 145),
(84, 'Exam@save', 'Examsave', 'Exam.php', 155, 211),
(85, 'Exam@updatequestions', 'Examupdatequestions', 'Exam.php', 220, 247),
(86, 'Exam@examstudents', 'Examexamstudents', 'Exam.php', 256, 266),
(87, 'Exam@sections', 'Examsections', 'Exam.php', 274, 280),
(88, 'Exam@get', 'Examget', 'Exam.php', 294, 314),
(89, 'Exam@deletecontent', 'Examdeletecontent', 'Exam.php', 321, 335),
(90, 'Exam@loadlecture', 'Examloadlecture', 'Exam.php', 342, 360),
(91, 'Exam@deleteuploads', 'Examdeleteuploads', 'Exam.php', 367, 372),
(92, 'Exam@updateview', 'Examupdateview', 'Exam.php', 379, 389),
(93, 'Exam@preview', 'Exampreview', 'Exam.php', 399, 421),
(94, 'Exam@curriculum', 'Examcurriculum', 'Exam.php', 430, 450),
(95, 'Exam@learn', 'Exam@learn', 'Exam.php', 459, 484),
(96, 'Exam@classstudents', 'Examclassstudents', 'Exam.php', 493, 506),
(97, 'Fleet@get', 'Fleetget', 'Fleet.php', 15, 38),
(98, 'Fleet@add', 'Fleetadd', 'Fleet.php', 45, 59),
(99, 'Fleet@delete', 'Fleetdelete', 'Fleet.php', 67, 70),
(100, 'Fleet@updateview', 'Fleetupdateview', 'Fleet.php', 77, 85),
(101, 'Fleet@update', 'Fleetupdate', 'Fleet.php', 92, 103),
(102, 'Fleetdashboard@get', 'Fleetdashboardget', 'Fleetdashboard.php', 14, 66),
(103, 'Fleetdashboard@totals', 'Fleetdashboardtotals', 'Fleetdashboard.php', 73, 91),
(104, 'Fleetdashboard@previous', 'Fleetdashboardprevious', 'Fleetdashboard.php', 98, 122),
(105, 'Fleetdashboard@current', 'Fleetdashboardcurrent', 'Fleetdashboard.php', 129, 151),
(106, 'Fleetdashboard@growth', 'Fleetdashboardgrowth', 'Fleetdashboard.php', 158, 185),
(107, 'Fleetdashboard@students', 'Fleetdashboardstudents', 'Fleetdashboard.php', 192, 210),
(108, 'Fleetdashboard@expenses', 'Fleetdashboardexpenses', 'Fleetdashboard.php', 217, 235),
(109, 'Fleetdashboard@invoices', 'Fleetdashboardinvoices', 'Fleetdashboard.php', 242, 262),
(110, 'Fleetdashboard@notifications', 'Fleetdashboardnotifications', 'Fleetdashboard.php', 269, 277),
(111, 'Fleetdashboard@courses', 'Fleetdashboardcourses', 'Fleetdashboard.php', 284, 296),
(112, 'Getchating@get', 'Getchating@get', 'Getchating.php', 18, 34),
(113, 'Getclass@get', 'Getclassget', 'Getclass.php', 18, 96),
(114, 'Getclass@get3', 'Getclassget3', 'Getclass.php', 98, 156),
(115, 'Getcommunication@get', 'Getcommunicationget', 'Getcommunication.php', 18, 35),
(116, 'Getfleetrecord@get', 'Getfleetrecordget', 'Getfleetrecord.php', 15, 118),
(117, 'Getfleetrecord@update', 'Getfleetrecordupdate', 'Getfleetrecord.php', 125, 301),
(118, 'Getfleetrecord@deletemaintainancerecord', 'Getfleetrecorddeletemaintainancerecord', 'Getfleetrecord.php', 308, 379),
(119, 'Instructor@get', 'Instructorget', 'Instructor.php', 14, 66),
(120, 'Instructor@create', 'Instructorcreate', 'Instructor.php', 74, 112),
(121, 'Invoice@get', 'Invoiceget', 'Invoice.php', 19, 57),
(122, 'Invoice@deletepayment', 'Invoicedeletepayment', 'Invoice.php', 64, 78),
(123, 'Invoice@viewpayments', 'Invoiceviewpayments', 'Invoice.php', 85, 88),
(124, 'Invoice@update', 'Invoiceupdate', 'Invoice.php', 95, 102),
(125, 'Invoice@updateview', 'Invoiceupdateview', 'Invoice.php', 109, 112),
(126, 'Invoice@delete', 'Invoicedelete', 'Invoice.php', 115, 128),
(127, 'Invoice@download', 'Invoicedownload', 'Invoice.php', 132, 147),
(128, 'Invoice@preview', 'Invoicepreview', 'Invoice.php', 154, 161),
(129, 'Invoice@share', 'Invoiceshare', 'Invoice.php', 164, 272),
(130, 'Issues@get', 'Issuesget', 'Issues.php', 16, 117),
(131, 'Issues@reportissue', 'Issuesreportissue', 'Issues.php', 125, 206),
(132, 'Issues@processing', 'Issuesprocessing', 'Issues.php', 212, 309),
(133, 'Issues@updatecomment', 'Issuesupdatecomment', 'Issues.php', 315, 422),
(134, 'Issues@updatebrief', 'Issuesupdatebrief', 'Issues.php', 428, 544),
(135, 'Issues@resolved', 'Issuesresolved', 'Issues.php', 550, 649),
(136, 'Issues@remove', 'Issuesremove', 'Issues.php', 655, 687),
(137, 'License@get', 'Licenseget', 'License.php', 18, 47),
(138, 'License@new', 'Licensenew', 'License.php', 55, 176),
(139, 'License@renew', 'Licenserenew', 'License.php', 183, 300),
(140, 'License@update', 'Licenseupdate', 'License.php', 307, 392),
(141, 'License@delete', 'Licensedelete', 'License.php', 399, 414),
(142, 'Marked@get', 'Markedget', 'Marked.php', 17, 31),
(143, 'Marked@reset', 'Markedreset', 'Marked.php', 38, 75),
(144, 'Marked@markpresent', 'Markedmarkpresent', 'Marked.php', 77, 334),
(145, 'Monthly@get', 'Monthlyget', 'Monthly.php', 14, 56),
(146, 'Monthly@totals', 'Monthlytotals', 'Monthly.php', 63, 130),
(147, 'Monthly@previous', 'Monthlyprevious', 'Monthly.php', 137, 165),
(148, 'Monthly@current', 'Monthlycurrent', 'Monthly.php', 172, 197),
(149, 'Monthly@growth', 'Monthlygrowth', 'Monthly.php', 204, 236),
(150, 'Monthly@students', 'Monthlystudents', 'Monthly.php', 243, 279),
(151, 'Monthly@expenses', 'Monthlyexpenses', 'Monthly.php', 286, 304),
(152, 'Monthly@invoices', 'Monthlyinvoices', 'Monthly.php', 311, 331),
(153, 'Monthly@notifications', 'Monthlynotifications', 'Monthly.php', 338, 346),
(154, 'Monthly@courses', 'Monthlycourses', 'Monthly.php', 353, 365),
(155, 'newfleetrecord@get', 'newfleetrecordget', 'newfleetrecord.php', 15, 69),
(156, 'newfleetrecord@addnew', 'newfleetrecordaddnew', 'newfleetrecord.php', 76, 481),
(157, 'newfleetrecord@delete', 'newfleetrecorddelete', 'newfleetrecord.php', 489, 492),
(158, 'newfleetrecord@updateview', 'newfleetrecordupdateview', 'newfleetrecord.php', 499, 507),
(159, 'newfleetrecord@update', 'newfleetrecordupdate', 'newfleetrecord.php', 514, 525),
(160, 'Newlicense@get', 'Newlicenseget', 'Newlicense.php', 16, 122),
(161, 'Newlicense@enroll', 'Newlicenseenroll', 'Newlicense.php', 130, 180),
(162, 'Newlicense@enrolled', 'Newlicenseenrolled', 'Newlicense.php', 186, 231),
(163, 'Newlicense@started', 'Newlicensestarted', 'Newlicense.php', 237, 282),
(164, 'Newlicense@payment', 'Newlicensepayment', 'Newlicense.php', 288, 333),
(165, 'Newlicense@processing', 'Newlicenseprocessing', 'Newlicense.php', 339, 384),
(166, 'Newlicense@learning', 'Newlicenselearning', 'Newlicense.php', 390, 435),
(167, 'Newlicense@permanent', 'Newlicensepermanent', 'Newlicense.php', 441, 486),
(168, 'Newlicense@completed', 'Newlicensecompleted', 'Newlicense.php', 492, 537),
(169, 'Newlicense@updatecomment', 'Newlicenseupdatecomment', 'Newlicense.php', 543, 575),
(170, 'Newlicense@cancaelled', 'Newlicensecancaelled', 'Newlicense.php', 581, 613),
(171, 'Notification@get', 'Notificationget', 'Notification.php', 14, 22),
(172, 'Notification@read', 'Notificationread', 'Notification.php', 29, 35),
(173, 'Notification@count', 'Notificationcount', 'Notification.php', 43, 52),
(174, 'Oldrecords@get', 'Oldrecordsget', 'Oldrecords.php', 18, 47),
(175, 'Ongoing@get', 'Ongoingget', 'Ongoing.php', 16, 30),
(176, 'Ongoing@reset', 'Ongoingreset', 'Ongoing.php', 37, 70),
(177, 'Ongoing@absent', 'Ongoingabsent', 'Ongoing.php', 72, 90),
(178, 'Payslip@get', 'Payslipget', 'Payslip.php', 19, 44),
(179, 'Payslip@download', 'Payslipdownload', 'Payslip.php', 51, 69),
(180, 'Payslip@sharepayslip', 'Payslipsharepayslip', 'Payslip.php', 76, 189),
(181, 'Payslip@payslipdownload', 'Payslippayslipdownload', 'Payslip.php', 196, 258),
(182, 'Payslip@preview', 'Payslippreview', 'Payslip.php', 265, 327),
(183, 'Payslip@numberTowords', 'PayslipnumberTowords', 'Payslip.php', 329, 435),
(184, 'Practicallessons@get', 'Practicallessonsget', 'Practicallessons.php', 16, 23),
(185, 'Practicallessons@create', 'Practicallessonscreate', 'Practicallessons.php', 31, 58),
(186, 'Practicallessons@update', 'Practicallessonsupdate', 'Practicallessons.php', 65, 92),
(187, 'Practicallessons@active', 'Practicallessonsactive', 'Practicallessons.php', 100, 119),
(188, 'Practicallessons@inactive', 'Practicallessonsinactive', 'Practicallessons.php', 127, 145),
(189, 'Practicallessons@delete', 'Practicallessonsdelete', 'Practicallessons.php', 153, 167),
(190, 'Practicallessons@addcourse', 'Practicallessonsaddcourse', 'Practicallessons.php', 174, 178),
(191, 'Profile@get', 'Profileget', 'Profile.php', 18, 152),
(192, 'Profile@update', 'Profileupdate', 'Profile.php', 159, 184),
(193, 'Profile@addaccountdetails', 'Profileaddaccountdetails', 'Profile.php', 191, 226),
(194, 'Profile@updateaccount', 'Profileupdateaccount', 'Profile.php', 233, 263),
(195, 'Profile@setongoing', 'Profilesetongoing', 'Profile.php', 271, 278),
(196, 'Profile@setwaiting', 'Profilesetwaiting', 'Profile.php', 286, 293),
(197, 'Profile@setcancelled', 'Profilesetcancelled', 'Profile.php', 301, 308),
(198, 'Profile@setcompleted', 'Profilesetcompleted', 'Profile.php', 316, 323),
(199, 'Profile@setdefaulter', 'Profilesetdefaulter', 'Profile.php', 331, 338),
(200, 'Profile@resetdefaulter', 'Profileresetdefaulter', 'Profile.php', 346, 353),
(201, 'Profile@delete', 'Profiledelete', 'Profile.php', 361, 369),
(202, 'Profile@sendemail', 'Profilesendemail', 'Profile.php', 377, 388),
(203, 'Profile@sendsms', 'Profilesendsms', 'Profile.php', 395, 437),
(204, 'Profile@addnote', 'Profileaddnote', 'Profile.php', 445, 454),
(205, 'Profile@deletenote', 'Profiledeletenote', 'Profile.php', 461, 464),
(206, 'Profile@readnote', 'Profilereadnote', 'Profile.php', 471, 474),
(207, 'Profile@updatenoteview', 'Profileupdatenoteview', 'Profile.php', 481, 484),
(208, 'Profile@updatenote', 'Profileupdatenote', 'Profile.php', 491, 497),
(209, 'Profile@uploadattachment', 'Profileuploadattachment', 'Profile.php', 504, 527),
(210, 'Profile@deleteattachment', 'Profiledeleteattachment', 'Profile.php', 534, 539),
(211, 'Profile@disconnectgoogle', 'Profiledisconnectgoogle', 'Profile.php', 546, 549),
(212, 'Profile@requestreview', 'Profilerequestreview', 'Profile.php', 551, 584),
(213, 'Profile@addadvance', 'Profileaddadvance', 'Profile.php', 591, 631),
(214, 'Profile@deleteadvance', 'Profiledeleteadvance', 'Profile.php', 638, 656),
(215, 'Profile@addincentive', 'Profileaddincentive', 'Profile.php', 663, 698),
(216, 'Profile@deleteincentive', 'Profiledeleteincentive', 'Profile.php', 705, 723),
(217, 'Profile@activateaccount', 'Profileactivateaccount', 'Profile.php', 730, 752),
(218, 'Profile@dactivateaccount', 'Profiledactivateaccount', 'Profile.php', 759, 781),
(219, 'Profile@generatepayslip', 'Profilegeneratepayslip', 'Profile.php', 788, 941),
(220, 'Profile@deletepayslip', 'Profiledeletepayslip', 'Profile.php', 948, 991),
(221, 'Profile@updatepayslip', 'Profileupdatepayslip', 'Profile.php', 998, 1045),
(222, 'Profile@addattendance', 'Profileaddattendance', 'Profile.php', 1052, 1087),
(223, 'Profile@updateattendance', 'Profileupdateattendance', 'Profile.php', 1094, 1125),
(224, 'Profile@deleteattendance', 'Profiledeleteattendance', 'Profile.php', 1132, 1154),
(225, 'Records@get', 'Recordsget', 'Records.php', 17, 187),
(226, 'Reschedule@get', 'Rescheduleget', 'Reschedule.php', 18, 39),
(227, 'Reschedule@validateDate', 'ReschedulevalidateDate', 'Reschedule.php', 48, 51),
(228, 'Reschedule@classes', 'Rescheduleclasses', 'Reschedule.php', 58, 195),
(229, 'Reschedule@liststudents', 'Rescheduleliststudents', 'Reschedule.php', 202, 252),
(230, 'Reschedule@updatetrainer', 'Rescheduleupdatetrainer', 'Reschedule.php', 259, 451),
(231, 'Schedule@get', 'Scheduleget', 'Schedule.php', 17, 46),
(232, 'Schedule@create', 'Schedulecreate', 'Schedule.php', 53, 309),
(233, 'Schedule@landaDate', 'SchedulelandaDate', 'Schedule.php', 317, 323),
(234, 'Schedule@fetch', 'Schedulefetch', 'Schedule.php', 331, 454),
(235, 'Schedule@delete', 'Scheduledelete', 'Schedule.php', 463, 556),
(236, 'Schedule@updateview', 'Scheduleupdateview', 'Schedule.php', 563, 571),
(237, 'Schedule@update', 'Scheduleupdate', 'Schedule.php', 578, 922),
(238, 'Schedule@smsnotification', 'Schedulesmsnotification', 'Schedule.php', 929, 958),
(239, 'Schedule@calendarSync', 'SchedulecalendarSync', 'Schedule.php', 965, 1002),
(240, 'ScheduleNotification@get', 'ScheduleNotificationget', 'ScheduleNotification.php', 18, 56),
(241, 'School@get', 'Schoolget', 'School.php', 18, 36),
(242, 'School@create', 'Schoolcreate', 'School.php', 43, 98),
(243, 'School@delete', 'Schooldelete', 'School.php', 106, 115),
(244, 'School@updateview', 'Schoolupdateview', 'School.php', 122, 125),
(245, 'School@update', 'Schoolupdate', 'School.php', 132, 142),
(246, 'School@sendemail', 'Schoolsendemail', 'School.php', 150, 179),
(247, 'School@sendsms', 'Schoolsendsms', 'School.php', 186, 260),
(248, 'Settings@get', 'Settingsget', 'Settings.php', 16, 23),
(249, 'Settings@getCurrencySymbol', 'SettingsgetCurrencySymbol', 'Settings.php', 25, 29),
(250, 'Settings@updateprofile', 'Settingsupdateprofile', 'Settings.php', 36, 74),
(251, 'Settings@updatcompany', 'Settingsupdatcompany', 'Settings.php', 81, 91),
(252, 'Settings@updatereminders', 'Settingsupdatereminders', 'Settings.php', 98, 132),
(253, 'Settings@updatepassword', 'Settingsupdatepassword', 'Settings.php', 139, 149),
(254, 'Settings@updatesystem', 'Settingsupdatesystem', 'Settings.php', 156, 209),
(255, 'Staff@get', 'Staffget', 'Staff.php', 14, 59),
(256, 'Staff@create', 'Staffcreate', 'Staff.php', 67, 106),
(257, 'Staffsummary@get', 'Staffsummaryget', 'Staffsummary.php', 17, 150),
(258, 'Student@get', 'Studentget', 'Student.php', 16, 156),
(259, 'Student@create', 'Studentcreate', 'Student.php', 164, 240),
(260, 'Student@addcourse', 'Studentaddcourse', 'Student.php', 247, 259),
(261, 'Student@enroll', 'Studentenroll', 'Student.php', 266, 289),
(262, 'Student@deleteenroll', 'Studentdeleteenroll', 'Student.php', 296, 299),
(263, 'Student@createinvoice', 'Studentcreateinvoice', 'Student.php', 306, 366),
(264, 'Today@get', 'Todayget', 'Today.php', 17, 47),
(265, 'Today@getdetails', 'Todaygetdetails', 'Today.php', 55, 95),
(266, 'Today@start', 'Todaystart', 'Today.php', 103, 218),
(267, 'Today@absent', 'Todayabsent', 'Today.php', 227, 363),
(268, 'Today@notify', 'Todaynotify', 'Today.php', 365, 440),
(269, 'Today@requestpayment', 'Todayrequestpayment', 'Today.php', 442, 507),
(270, 'Update@get', 'Updateget', 'Update.php', 16, 25),
(271, 'Update@scan', 'Updatescan', 'Update.php', 32, 42),
(272, 'Update@versions', 'Updateversions', 'Update.php', 49, 54),
(273, 'Update@update', 'Updateupdate', 'Update.php', 61, 74),
(274, 'Updates@get', 'Updatesget', 'Updates.php', 17, 39),
(275, 'Updates@fuelexpenses', 'Updatesfuelexpenses', 'Updates.php', 46, 150),
(276, 'Updates@otherexpenses', 'Updatesotherexpenses', 'Updates.php', 157, 228),
(277, 'Updates@dropout', 'Updatesdropout', 'Updates.php', 235, 298),
(278, 'Updates@updatecompany', 'Updatesupdatecompany', 'Updates.php', 305, 315),
(279, 'Updates@updatereminders', 'Updatesupdatereminders', 'Updates.php', 322, 356),
(280, 'Updates@updatepassword', 'Updatesupdatepassword', 'Updates.php', 363, 373),
(281, 'Updates@updatesystem', 'Updatesupdatesystem', 'Updates.php', 380, 433),
(282, 'Updatestudentaadhar@get', 'Updatestudentaadharget', 'Updatestudentaadhar.php', 17, 31),
(283, 'Updatestudentaadhar@update', 'Updatestudentaadharupdate', 'Updatestudentaadhar.php', 38, 157),
(284, 'Updatestudentprofile@get', 'Updatestudentprofileget', 'Updatestudentprofile.php', 17, 33),
(285, 'Updatestudentprofile@update', 'Updatestudentprofileupdate', 'Updatestudentprofile.php', 40, 167),
(286, 'waitinglist@get', 'waitinglistget', 'waitinglist.php', 16, 67),
(287, 'waitinglist@create', 'waitinglistcreate', 'waitinglist.php', 75, 131),
(288, 'waitinglist@addcourse', 'waitinglistaddcourse', 'waitinglist.php', 138, 142),
(289, 'waitinglist@enroll', 'waitinglistenroll', 'waitinglist.php', 149, 172),
(290, 'waitinglist@deleteenrollment', 'waitinglistdeleteenrollment', 'waitinglist.php', 179, 182),
(291, 'waitinglist@createinvoice', 'waitinglistcreateinvoice', 'waitinglist.php', 189, 247),
(292, 'Welcome@get', 'Welcomeget', 'Welcome.php', 18, 37),
(293, 'Welcome@iattend', 'Welcomeiattend', 'Welcome.php', 39, 262);

-- --------------------------------------------------------

--
-- Table structure for table `practicallessons`
--

CREATE TABLE `practicallessons` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `status` int(11) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `practicallessons`
--

INSERT INTO `practicallessons` (`id`, `name`, `description`, `status`, `lastupdate`) VALUES
(1, 'ABC', 'In this lesson we will learn about the functions and use of Accelerate, Break and Clutch.', 1, '2022-07-30 19:32:32'),
(2, 'General Information', 'In this lesson we will learn about the general functions of the car.', 1, '2022-07-30 20:16:52'),
(3, 'Lesson 3', 'Desc 3', 1, '2022-08-01 13:09:37');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `exam` int(11) NOT NULL,
  `question` varchar(256) NOT NULL,
  `answers` text NOT NULL,
  `correct` text NOT NULL,
  `indexing` int(11) NOT NULL,
  `required` enum('yes','no') NOT NULL,
  `type` enum('multiple','single') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reminders`
--

CREATE TABLE `reminders` (
  `id` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `subject` varchar(256) DEFAULT NULL,
  `days` int(11) NOT NULL,
  `message` text NOT NULL,
  `type` enum('class','payment') NOT NULL,
  `send_via` enum('email','sms') NOT NULL,
  `timing` enum('before_due','after_due') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `reminders`
--

INSERT INTO `reminders` (`id`, `school`, `subject`, `days`, `message`, `type`, `send_via`, `timing`) VALUES
(7, 1, '', 2, 'Hello [firstname],\r\n\r\nWe hope you are doing well.\r\nWe are  writing to remind you that your payment of Rs. [amountdue] is due on [duedate].\r\nPlease settle as soon as possible to avoid class interruption \r\n\r\nCheers!\r\nRCDS Team\r\n                                    ', 'payment', 'sms', 'before_due'),
(8, 1, 'Payment reminder', 1, 'Hello [firstname],\r\n\r\nWe hope you are doing well.\r\nWe are  writing to remind you that your payment of Rs. [amountdue] is due on [duedate].\r\nPlease settle as soon as possible to avoid class interruption \r\n\r\nCheers!\r\nRCDS Team\r\n                                    ', 'payment', 'email', 'before_due'),
(9, 1, 'RCDS - Class Remainder', 1, 'Hello [firstname],\r\n\r\nWe hope you are doing well.\r\nWe are writing to remind you that your class is scheduled on [classdate] at [classtime].\r\n\r\nWe are exited to take your Practical class.\r\n\r\nCheers!\r\nRCDS Team\r\n                                    ', 'class', 'email', 'before_due');

-- --------------------------------------------------------

--
-- Table structure for table `reportedissues`
--

CREATE TABLE `reportedissues` (
  `id` int(11) NOT NULL,
  `type` enum('Payment','Training','Trainer Behavior','Other') NOT NULL,
  `student` int(11) NOT NULL,
  `status` enum('New','Processing','Resolved') NOT NULL,
  `brief` text NOT NULL,
  `timeline` text NOT NULL,
  `reportedby` int(11) NOT NULL,
  `resolvedby` int(11) DEFAULT NULL,
  `resolvedon` text DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `createdat` text NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `scertificates`
--

CREATE TABLE `scertificates` (
  `sr` int(11) NOT NULL,
  `student` int(11) NOT NULL,
  `areference` text NOT NULL,
  `avatar` text NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `fathername` text NOT NULL,
  `aadhar` text NOT NULL,
  `learning` text NOT NULL,
  `caddress` text NOT NULL,
  `startdate` text NOT NULL,
  `enddate` text NOT NULL,
  `createdat` text NOT NULL,
  `createdby` text NOT NULL,
  `cdesignation` text NOT NULL,
  `comment` text DEFAULT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `lastudpate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `scertificates`
--

INSERT INTO `scertificates` (`sr`, `student`, `areference`, `avatar`, `fname`, `lname`, `fathername`, `aadhar`, `learning`, `caddress`, `startdate`, `enddate`, `createdat`, `createdby`, `cdesignation`, `comment`, `school`, `branch`, `lastudpate`) VALUES
(8, 30, 'MYDDQVI0G', 'XZdrCmvY4odUoursu4vWs2RBAyAbvIy1.jpg', 'Pratham', 'Sharma', 'tester2', '123456789012', '1234567890121', 'tester', '2022-07-31', '2023-11-03', '2023-10-04 10:40:24', 'Sagar Sharma', 'superadmin', '', 1, 1, '2023-10-04 05:10:24');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `start` varchar(255) NOT NULL,
  `end` varchar(255) NOT NULL,
  `course` int(11) NOT NULL,
  `student` int(11) NOT NULL,
  `instructor` int(11) NOT NULL,
  `class_type` enum('Practical','Theory') NOT NULL,
  `car` int(11) DEFAULT NULL,
  `status` enum('New','Complete','Missed') NOT NULL,
  `cstatus` int(11) NOT NULL DEFAULT 0,
  `student_google_id` varchar(64) DEFAULT NULL,
  `instructor_google_id` varchar(64) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `school`, `branch`, `start`, `end`, `course`, `student`, `instructor`, `class_type`, `car`, `status`, `cstatus`, `student_google_id`, `instructor_google_id`, `created_at`) VALUES
(1, 1, 1, '2023-09-30 00:00:00', '2023-09-30 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-09-30 07:56:45'),
(2, 1, 1, '2023-10-03 00:00:00', '2023-10-03 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(3, 1, 1, '2023-10-04 00:00:00', '2023-10-04 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(4, 1, 1, '2023-10-05 00:00:00', '2023-10-05 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(5, 1, 1, '2023-10-06 00:00:00', '2023-10-06 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(6, 1, 1, '2023-10-07 00:00:00', '2023-10-07 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(7, 1, 1, '2023-10-09 00:00:00', '2023-10-09 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(8, 1, 1, '2023-10-10 00:00:00', '2023-10-10 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(9, 1, 1, '2023-10-11 00:00:00', '2023-10-11 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(10, 1, 1, '2023-10-12 00:00:00', '2023-10-12 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(11, 1, 1, '2023-10-13 00:00:00', '2023-10-13 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(12, 1, 1, '2023-10-14 00:00:00', '2023-10-14 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(13, 1, 1, '2023-10-16 00:00:00', '2023-10-16 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(14, 1, 1, '2023-10-17 00:00:00', '2023-10-17 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(15, 1, 1, '2023-10-18 00:00:00', '2023-10-18 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(16, 1, 1, '2023-10-19 00:00:00', '2023-10-19 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(17, 1, 1, '2023-10-20 00:00:00', '2023-10-20 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(18, 1, 1, '2023-10-21 00:00:00', '2023-10-21 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(19, 1, 1, '2023-10-23 00:00:00', '2023-10-23 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(20, 1, 1, '2023-10-24 00:00:00', '2023-10-24 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(21, 1, 1, '2023-10-25 00:00:00', '2023-10-25 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(22, 1, 1, '2023-10-26 00:00:00', '2023-10-26 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(23, 1, 1, '2023-10-27 00:00:00', '2023-10-27 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(24, 1, 1, '2023-10-28 00:00:00', '2023-10-28 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(25, 1, 1, '2023-10-30 00:00:00', '2023-10-30 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(26, 1, 1, '2023-10-31 00:00:00', '2023-10-31 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(27, 1, 1, '2023-11-01 00:00:00', '2023-11-01 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(28, 1, 1, '2023-11-02 00:00:00', '2023-11-02 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50'),
(29, 1, 1, '2023-11-03 00:00:00', '2023-11-03 00:30:00', 11, 30, 5, 'Practical', 1, 'Complete', 0, NULL, NULL, '2023-10-03 13:27:50');

-- --------------------------------------------------------

--
-- Table structure for table `schoolmessages`
--

CREATE TABLE `schoolmessages` (
  `id` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `type` enum('sms','email') NOT NULL,
  `contact` varchar(64) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` longtext DEFAULT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Sent','Failed') NOT NULL DEFAULT 'Sent',
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `id` int(11) NOT NULL,
  `licence` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `currency` varchar(8) NOT NULL DEFAULT 'USD',
  `timezone` varchar(32) NOT NULL DEFAULT 'Africa/Nairobi',
  `status` enum('Active','Suspended') NOT NULL,
  `payment_reminders` enum('On','Off') NOT NULL DEFAULT 'On',
  `class_reminders` enum('On','Off') NOT NULL DEFAULT 'On',
  `multibooking` enum('Enabled','Disabled') NOT NULL DEFAULT 'Enabled',
  `class_sms_notifications` enum('Enabled','Disabled') NOT NULL DEFAULT 'Enabled',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`id`, `licence`, `name`, `email`, `phone`, `address`, `currency`, `timezone`, `status`, `payment_reminders`, `class_reminders`, `multibooking`, `class_sms_notifications`, `created_at`) VALUES
(1, '14/DTC/RTA/SNP/2022', 'Real Car Driving School - Sonipat', 'realcardrive@gmail.com', '+917419999195', 'Kuber Vatika, Near Rothak railway Flyover Sonipat', 'INR', 'Asia/Kolkata', 'Active', 'On', 'On', 'Enabled', 'Enabled', '2019-01-08 06:51:03');

-- --------------------------------------------------------

--
-- Table structure for table `sendnotifications`
--

CREATE TABLE `sendnotifications` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `message` text NOT NULL,
  `phone` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `createdby` int(11) NOT NULL,
  `createdat` text NOT NULL,
  `comment` text DEFAULT NULL,
  `executed_at` text DEFAULT NULL,
  `branch` int(11) NOT NULL,
  `school` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `servicerecords`
--

CREATE TABLE `servicerecords` (
  `id` int(11) NOT NULL,
  `car` int(11) NOT NULL,
  `date` text NOT NULL,
  `servicekm` text NOT NULL,
  `reading` text NOT NULL,
  `nextservicekm` text NOT NULL,
  `iskmreset` int(11) NOT NULL DEFAULT 0,
  `comments` text DEFAULT NULL,
  `recordby` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `servicerecords`
--

INSERT INTO `servicerecords` (`id`, `car`, `date`, `servicekm`, `reading`, `nextservicekm`, `iskmreset`, `comments`, `recordby`, `branch`, `school`, `lastupdate`) VALUES
(5, 3, '2023-07-17', 'fvo14Z8pwz3iSobM38paRTpgzF6PYYLC.png', '35000', '42000', 2, 'ZXJ3cndl', 1, 1, 1, '2023-09-20 07:35:20'),
(6, 3, '2023-04-11', 'OvhW0HgYDbAKOGwHgDsetkF6GJGUi4XQ.png', '20000', '30000', 2, NULL, 1, 1, 1, '2023-07-18 05:07:31'),
(7, 1, '2023-09-29', 'Zy2146nhhqiODLjHnHxomQkqCwRAAbb1.png', '22312', '32312', 2, 'ZHNmYXNkZnNk', 1, 1, 1, '2023-09-29 13:07:42');

-- --------------------------------------------------------

--
-- Table structure for table `staffattendance`
--

CREATE TABLE `staffattendance` (
  `sr` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `date` date NOT NULL,
  `attendance` enum('Present','Absent','Halfday','Leave','Compoff','Extra') NOT NULL,
  `marked` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `selfie` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `comment` text DEFAULT NULL,
  `islate` int(11) NOT NULL DEFAULT 0,
  `isregularized` int(11) NOT NULL DEFAULT 0,
  `regularizedby` text DEFAULT NULL,
  `regularizedcomment` text DEFAULT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `branch` int(11) NOT NULL,
  `school` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staffattendance`
--

INSERT INTO `staffattendance` (`sr`, `userid`, `date`, `attendance`, `marked`, `created_at`, `selfie`, `created_by`, `comment`, `islate`, `isregularized`, `regularizedby`, `regularizedcomment`, `lastupdate`, `branch`, `school`) VALUES
(7, 5, '2022-09-19', 'Halfday', 1, '2022-10-02 09:29:51', NULL, 1, '', 0, 0, NULL, NULL, '2022-11-03 20:42:38', 1, 1),
(17, 5, '2022-10-05', 'Present', 0, '2022-10-05 13:33:44', 'EYCmZcwbXTD3rKz4OvZCP6jyiMGOpXWt.png', 5, NULL, 1, 0, NULL, NULL, '2022-10-05 13:33:44', 1, 1),
(18, 6, '2022-10-05', 'Absent', 0, '2022-10-05 13:36:07', NULL, 11, NULL, 0, 0, NULL, NULL, '2022-10-05 13:36:07', 1, 1),
(19, 5, '2022-10-07', 'Absent', 0, '2022-10-07 14:04:04', NULL, 1, '', 0, 0, NULL, NULL, '2022-10-07 14:04:04', 1, 1),
(20, 5, '2022-10-11', 'Present', 0, '2022-10-11 13:50:21', 'qz5bcRQdztmRTenzgQTduWMJhpXAlpr3.png', 5, NULL, 1, 0, NULL, NULL, '2022-10-11 12:20:21', 1, 1),
(22, 5, '2022-10-15', 'Present', 0, '2022-10-14 21:28:07', '263GFYIDqNfiKSAb5weqmzNPrTlGaDS2.png', 5, NULL, 1, 0, NULL, NULL, '2022-10-14 19:58:07', 1, 1),
(23, 5, '2022-10-18', 'Present', 0, '2022-10-18 10:09:15', 'wck62lfc03YletETm65b2hF80WBb66kF.png', 5, NULL, 1, 0, NULL, NULL, '2022-10-18 08:39:15', 1, 1),
(24, 5, '2022-10-29', 'Present', 0, '2022-10-29 12:02:49', 'Qb0P90MCDJSSLSPXp9FCfs4YhYuIpUCs.png', 5, NULL, 1, 0, NULL, NULL, '2022-10-29 10:32:49', 1, 1),
(25, 5, '2022-11-07', 'Absent', 0, '2022-11-07 12:34:38', NULL, 11, NULL, 0, 0, NULL, NULL, '2022-11-07 11:04:38', 1, 1),
(26, 11, '2022-11-07', 'Present', 0, '2022-11-07 11:04:38', 'yD5qZJ1CHWXW7XexoOcTI7w7D5GunKJi.png', 5, NULL, 1, 0, NULL, NULL, '2022-11-07 11:04:38', 1, 1),
(27, 11, '2022-11-09', 'Present', 0, '2022-11-09 15:55:31', 'oGbJ5x1tdpMsxgXDMWMPg10LdoEPbmqO.png', 11, NULL, 1, 0, NULL, NULL, '2022-11-09 15:55:31', 1, 1),
(30, 23, '2023-01-10', 'Present', 0, '2023-01-10 11:40:23', 'lRVhcmENOxkJj0TOgmqM7w6m4Rt20im9.png', 23, NULL, 0, 0, NULL, NULL, '2023-01-10 10:10:23', 1, 1),
(32, 6, '2023-01-10', 'Present', 0, '2023-01-10 11:44:23', 'WSj2Fg3zEuJ38UxeFoI9ordzhH7J2GPi.png', 6, NULL, 0, 0, NULL, NULL, '2023-01-10 10:14:23', 1, 1),
(33, 5, '2023-03-14', 'Present', 0, '2023-03-14 13:55:37', 'fOo7BwUhpkzjgky5FaKJ4PCo7G6zz9J4.png', 5, NULL, 1, 0, NULL, NULL, '2023-03-14 12:25:37', 1, 1),
(34, 5, '2023-03-20', 'Present', 0, '2023-03-20 10:07:20', 'aqEy3yHHgUCITyKv3NkNd02mXfoWzQl6.png', 5, NULL, 1, 0, NULL, NULL, '2023-03-20 08:37:20', 1, 1),
(35, 5, '2023-03-21', 'Present', 0, '2023-03-21 10:07:36', 'QEyxiGyh0lhcOzXbdZ3bsvCZomdl2CS4.png', 5, NULL, 1, 0, NULL, NULL, '2023-03-21 08:37:36', 1, 1),
(36, 11, '2023-04-06', 'Present', 0, '2023-04-06 06:28:50', 'r0k5jeAXjbqlg5MM3lgoQeC525LX5xC1.png', 11, NULL, 1, 0, NULL, NULL, '2023-04-06 06:28:50', 1, 1),
(37, 5, '2023-04-11', 'Present', 0, '2023-04-11 16:29:05', '3XwJv4yiCwboC9l7fpsvngP1JcZr2RCL.png', 5, NULL, 1, 0, NULL, NULL, '2023-04-11 14:59:05', 1, 1),
(38, 5, '2023-04-19', 'Present', 0, '2023-04-19 09:26:22', '5C8eL8TAQLbB0pxEbA3R7dKVISAAbQ3O.png', 5, NULL, 1, 0, NULL, NULL, '2023-04-19 07:56:22', 1, 1),
(39, 5, '2023-05-13', 'Present', 0, '2023-05-12 20:03:37', 'yUg8wCbWH0ByVyqfWa81VThj6xLcA0YD.png', 5, NULL, 0, 0, NULL, NULL, '2023-05-12 18:33:37', 1, 1),
(40, 5, '2023-05-20', 'Present', 0, '2023-05-20 13:32:57', 'm2qqO3yUmLZMxVRXflLYRVW2ar29gCOd.png', 5, NULL, 1, 0, NULL, NULL, '2023-05-20 12:02:57', 1, 1),
(43, 5, '2023-06-10', 'Present', 0, '2023-06-10 01:20:08', 'MmnufkCE9nCkGRmNbOBvtbpQtb0NJN53.png', 5, NULL, 1, 0, NULL, NULL, '2023-06-10 01:20:08', 1, 1),
(44, 5, '2023-08-05', 'Present', 0, '2023-08-05 09:43:46', 'tnCbQq4LNeIoBj3z1BqA2mswACMbtrWH.png', 5, NULL, 1, 0, NULL, NULL, '2023-08-05 08:13:46', 1, 1),
(45, 37, '2023-08-22', 'Present', 0, '2023-08-21 20:46:31', 'oRAQlzqKz9sV8Nlt6RqI53MS3BLPrZ5N.png', 37, NULL, 0, 0, NULL, NULL, '2023-08-21 19:16:31', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `studentexamresults`
--

CREATE TABLE `studentexamresults` (
  `id` int(11) NOT NULL,
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `exam` int(11) NOT NULL,
  `question` varchar(256) NOT NULL,
  `answer` text NOT NULL,
  `correct` enum('yes','no') NOT NULL,
  `indexing` int(11) NOT NULL,
  `student` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `timeline`
--

CREATE TABLE `timeline` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `activity` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `timeline`
--

INSERT INTO `timeline` (`id`, `user`, `activity`, `created_at`) VALUES
(36, 21, 'Account created by <strong>Sagar Sharma</strong>', '2022-07-17 09:05:21'),
(37, 21, 'Enrolled to <strong>Beginner</strong> course.', '2022-07-17 09:05:40'),
(38, 21, 'Enrolled to <strong>Beginner</strong> course.', '2022-07-17 09:07:04'),
(39, 21, 'Enrolled to <strong>Beginner</strong> course.', '2022-07-17 09:09:34'),
(40, 21, 'Enrolled to <strong>Beginner</strong> course.', '2022-07-17 09:09:57'),
(41, 21, 'Enrolled to <strong>Beginner</strong> course.', '2022-07-17 09:16:04'),
(42, 22, 'Account created by <strong>Sagar Sharma</strong>', '2022-07-18 10:20:56'),
(43, 23, 'Account created by <strong>Sagar Sharma</strong>', '2022-07-18 11:30:41'),
(44, 23, 'Enrolled to <strong>Beginner</strong> course.', '2022-07-18 11:31:56'),
(45, 24, 'Account created by <strong>Sagar Sharma</strong>', '2022-07-18 11:36:22'),
(46, 24, 'Enrolled to <strong>Beginner</strong> course.', '2022-07-18 11:36:22'),
(47, 24, 'Enrolled to <strong>Intermediate</strong> course.', '2022-07-18 11:39:34'),
(48, 25, 'Account created by <strong>Sagar Sharma</strong>', '2022-07-20 11:14:17'),
(49, 30, 'Enrolled to <strong>Beginner</strong> course.', '2022-07-31 18:11:28'),
(50, 22, 'Enrolled to <strong>Beginner</strong> course.', '2022-08-23 18:23:18'),
(51, 32, 'Account created by <strong>Sagar Sharma</strong>', '2022-08-24 12:26:34'),
(52, 32, 'Enrolled to <strong>Beginner</strong> course.', '2022-08-24 12:26:34'),
(53, 21, 'Completed a Practical class for <strong>Beginner</strong> course.', '2022-09-13 12:46:04'),
(54, 21, 'Completed a Practical class for <strong>Beginner</strong> course.', '2022-09-13 12:48:03'),
(55, 21, 'Completed a Practical class for <strong>Beginner</strong> course.', '2022-09-13 19:17:35'),
(56, 21, 'Enrolled to <strong>Beginner</strong> course.', '2022-09-21 05:19:28'),
(57, 21, 'Enrolled to <strong>Beginner</strong> course.', '2022-09-21 09:31:54'),
(58, 22, 'Enrolled to <strong>Beginner</strong> course.', '2022-09-21 09:33:55'),
(59, 32, 'Enrolled to <strong>Beginner</strong> course.', '2022-09-24 18:35:33'),
(60, 32, 'Enrolled to <strong>Beginner</strong> course.', '2022-09-24 18:38:13'),
(61, 32, 'Enrolled to <strong>Beginner</strong> course.', '2022-09-24 18:59:11'),
(62, 33, 'Account created by <strong>Sagar Sharma</strong>', '2022-10-01 12:36:25'),
(63, 33, 'Enrolled to <strong>Beginner</strong> course.', '2022-10-01 12:36:51'),
(64, 22, 'Enrolled to <strong>Beginner</strong> course.', '2022-10-03 09:55:08'),
(65, 34, 'Account created by <strong>Sagar Sharma</strong>', '2022-10-03 11:59:55'),
(66, 32, 'Enrolled to <strong>Beginner</strong> course.', '2022-10-18 08:45:21'),
(67, 33, 'Enrolled to <strong>Beginner - Fast Track</strong> course.', '2023-01-04 17:31:56'),
(68, 33, 'Enrolled to <strong>Beginner - Fast Track</strong> course.', '2023-01-04 17:35:47'),
(69, 33, 'Enrolled to <strong>Beginner - Fast Track</strong> course.', '2023-01-04 18:15:43'),
(70, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-03-21 08:43:39'),
(71, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-03-21 08:47:45'),
(72, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-03-21 10:03:55'),
(73, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-03-21 10:14:07'),
(74, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-04-06 08:45:24'),
(75, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-04-06 08:46:40'),
(76, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-04-06 08:51:08'),
(77, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-04-06 08:54:07'),
(78, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-05-12 18:32:02'),
(79, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-05-12 18:32:19'),
(80, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-05-12 18:34:52'),
(81, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-05-12 18:40:56'),
(82, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-05-15 16:28:18'),
(83, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-05-15 16:48:13'),
(84, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-05-15 16:48:28'),
(85, 33, 'Completed a Practical class for <strong>Beginner - Fast Track</strong> course.', '2023-05-15 16:52:03'),
(86, 36, 'Account created by <strong>Pratham Sharma</strong>', '2023-05-24 18:00:36'),
(87, 36, 'Enrolled to <strong>Beginner</strong> course.', '2023-05-24 18:58:22'),
(88, 30, 'Completed a Practical class for <strong>Beginner</strong> course.', '2023-09-30 07:56:45'),
(89, 30, 'Completed a Practical class for <strong>Beginner</strong> course.', '2023-10-03 13:27:50');

-- --------------------------------------------------------

--
-- Table structure for table `timezones`
--

CREATE TABLE `timezones` (
  `id` int(11) NOT NULL,
  `name` varchar(31) NOT NULL,
  `zone` varchar(272) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `timezones`
--

INSERT INTO `timezones` (`id`, `name`, `zone`) VALUES
(1, '(UTC-11:00) Pacific/Pago_Pago', 'Pacific/Pago_Pago'),
(2, '(UTC-11:00) Pacific/Niue', 'Pacific/Niue'),
(3, '(UTC-11:00) Pacific/Midway', 'Pacific/Midway'),
(4, '(UTC-10:00) Pacific/Tahiti', 'Pacific/Tahiti'),
(5, '(UTC-10:00) America/Adak', 'America/Adak'),
(6, '(UTC-10:00) Pacific/Rarotonga', 'Pacific/Rarotonga'),
(7, '(UTC-10:00) Pacific/Honolulu', 'Pacific/Honolulu'),
(8, '(UTC-09:30) Pacific/Marquesas', 'Pacific/Marquesas'),
(9, '(UTC-09:00) Pacific/Gambier', 'Pacific/Gambier'),
(10, '(UTC-09:00) America/Sitka', 'America/Sitka'),
(11, '(UTC-09:00) America/Anchorage', 'America/Anchorage'),
(12, '(UTC-09:00) America/Yakutat', 'America/Yakutat'),
(13, '(UTC-09:00) America/Metlakatla', 'America/Metlakatla'),
(14, '(UTC-09:00) America/Juneau', 'America/Juneau'),
(15, '(UTC-09:00) America/Nome', 'America/Nome'),
(16, '(UTC-08:00) Pacific/Pitcairn', 'Pacific/Pitcairn'),
(17, '(UTC-08:00) America/Tijuana', 'America/Tijuana'),
(18, '(UTC-08:00) America/Vancouver', 'America/Vancouver'),
(19, '(UTC-08:00) America/Los_Angeles', 'America/Los_Angeles'),
(20, '(UTC-08:00) America/Whitehorse', 'America/Whitehorse'),
(21, '(UTC-08:00) America/Dawson', 'America/Dawson'),
(22, '(UTC-07:00) America/Cambridge_B', 'America/Cambridge_Bay'),
(23, '(UTC-07:00) America/Mazatlan', 'America/Mazatlan'),
(24, '(UTC-07:00) America/Boise', 'America/Boise'),
(25, '(UTC-07:00) America/Creston', 'America/Creston'),
(26, '(UTC-07:00) America/Yellowknife', 'America/Yellowknife'),
(27, '(UTC-07:00) America/Phoenix', 'America/Phoenix'),
(28, '(UTC-07:00) America/Chihuahua', 'America/Chihuahua'),
(29, '(UTC-07:00) America/Dawson_Cree', 'America/Dawson_Creek'),
(30, '(UTC-07:00) America/Inuvik', 'America/Inuvik'),
(31, '(UTC-07:00) America/Ojinaga', 'America/Ojinaga'),
(32, '(UTC-07:00) America/Denver', 'America/Denver'),
(33, '(UTC-07:00) America/Edmonton', 'America/Edmonton'),
(34, '(UTC-07:00) America/Hermosillo', 'America/Hermosillo'),
(35, '(UTC-07:00) America/Fort_Nelson', 'America/Fort_Nelson'),
(36, '(UTC-06:00) America/El_Salvador', 'America/El_Salvador'),
(37, '(UTC-06:00) America/Indiana/Tel', 'America/Indiana/Tell_City'),
(38, '(UTC-06:00) America/Costa_Rica', 'America/Costa_Rica'),
(39, '(UTC-06:00) America/Indiana/Kno', 'America/Indiana/Knox'),
(40, '(UTC-06:00) America/Bahia_Bande', 'America/Bahia_Banderas'),
(41, '(UTC-06:00) America/Guatemala', 'America/Guatemala'),
(42, '(UTC-06:00) America/Belize', 'America/Belize'),
(43, '(UTC-06:00) America/Managua', 'America/Managua'),
(44, '(UTC-06:00) America/Swift_Curre', 'America/Swift_Current'),
(45, '(UTC-06:00) America/Mexico_City', 'America/Mexico_City'),
(46, '(UTC-06:00) America/Resolute', 'America/Resolute'),
(47, '(UTC-06:00) America/Regina', 'America/Regina'),
(48, '(UTC-06:00) America/Rankin_Inle', 'America/Rankin_Inlet'),
(49, '(UTC-06:00) America/Rainy_River', 'America/Rainy_River'),
(50, '(UTC-06:00) America/North_Dakot', 'America/North_Dakota/New_Salem'),
(51, '(UTC-06:00) America/North_Dakot', 'America/North_Dakota/Center'),
(52, '(UTC-06:00) America/North_Dakot', 'America/North_Dakota/Beulah'),
(53, '(UTC-06:00) America/Tegucigalpa', 'America/Tegucigalpa'),
(54, '(UTC-06:00) America/Monterrey', 'America/Monterrey'),
(55, '(UTC-06:00) Pacific/Galapagos', 'Pacific/Galapagos'),
(56, '(UTC-06:00) America/Chicago', 'America/Chicago'),
(57, '(UTC-06:00) America/Merida', 'America/Merida'),
(58, '(UTC-06:00) America/Winnipeg', 'America/Winnipeg'),
(59, '(UTC-06:00) America/Menominee', 'America/Menominee'),
(60, '(UTC-06:00) America/Matamoros', 'America/Matamoros'),
(61, '(UTC-05:00) America/Iqaluit', 'America/Iqaluit'),
(62, '(UTC-05:00) America/Rio_Branco', 'America/Rio_Branco'),
(63, '(UTC-05:00) America/Lima', 'America/Lima'),
(64, '(UTC-05:00) America/Kentucky/Mo', 'America/Kentucky/Monticello'),
(65, '(UTC-05:00) America/Kentucky/Lo', 'America/Kentucky/Louisville'),
(66, '(UTC-05:00) America/Cayman', 'America/Cayman'),
(67, '(UTC-05:00) America/Pangnirtung', 'America/Pangnirtung'),
(68, '(UTC-05:00) America/Panama', 'America/Panama'),
(69, '(UTC-05:00) America/Jamaica', 'America/Jamaica'),
(70, '(UTC-05:00) America/Detroit', 'America/Detroit'),
(71, '(UTC-05:00) America/Indiana/Win', 'America/Indiana/Winamac'),
(72, '(UTC-05:00) America/Eirunepe', 'America/Eirunepe'),
(73, '(UTC-05:00) America/Indiana/Vin', 'America/Indiana/Vincennes'),
(74, '(UTC-05:00) America/New_York', 'America/New_York'),
(75, '(UTC-05:00) America/Grand_Turk', 'America/Grand_Turk'),
(76, '(UTC-05:00) America/Nassau', 'America/Nassau'),
(77, '(UTC-05:00) America/Guayaquil', 'America/Guayaquil'),
(78, '(UTC-05:00) America/Havana', 'America/Havana'),
(79, '(UTC-05:00) America/Indiana/Ind', 'America/Indiana/Indianapolis'),
(80, '(UTC-05:00) America/Indiana/Mar', 'America/Indiana/Marengo'),
(81, '(UTC-05:00) America/Indiana/Pet', 'America/Indiana/Petersburg'),
(82, '(UTC-05:00) America/Indiana/Vev', 'America/Indiana/Vevay'),
(83, '(UTC-05:00) America/Nipigon', 'America/Nipigon'),
(84, '(UTC-05:00) America/Port-au-Pri', 'America/Port-au-Prince'),
(85, '(UTC-05:00) America/Thunder_Bay', 'America/Thunder_Bay'),
(86, '(UTC-05:00) America/Cancun', 'America/Cancun'),
(87, '(UTC-05:00) America/Bogota', 'America/Bogota'),
(88, '(UTC-05:00) Pacific/Easter', 'Pacific/Easter'),
(89, '(UTC-05:00) America/Toronto', 'America/Toronto'),
(90, '(UTC-05:00) America/Atikokan', 'America/Atikokan'),
(91, '(UTC-04:00) America/Marigot', 'America/Marigot'),
(92, '(UTC-04:00) America/St_Barthele', 'America/St_Barthelemy'),
(93, '(UTC-04:00) America/St_Kitts', 'America/St_Kitts'),
(94, '(UTC-04:00) America/St_Lucia', 'America/St_Lucia'),
(95, '(UTC-04:00) America/La_Paz', 'America/La_Paz'),
(96, '(UTC-04:00) America/St_Thomas', 'America/St_Thomas'),
(97, '(UTC-04:00) America/St_Vincent', 'America/St_Vincent'),
(98, '(UTC-04:00) America/Lower_Princ', 'America/Lower_Princes'),
(99, '(UTC-04:00) America/Thule', 'America/Thule'),
(100, '(UTC-04:00) America/Manaus', 'America/Manaus'),
(101, '(UTC-04:00) America/Caracas', 'America/Caracas'),
(102, '(UTC-04:00) America/Martinique', 'America/Martinique'),
(103, '(UTC-04:00) America/Antigua', 'America/Antigua'),
(104, '(UTC-04:00) America/Tortola', 'America/Tortola'),
(105, '(UTC-04:00) America/Moncton', 'America/Moncton'),
(106, '(UTC-04:00) America/Montserrat', 'America/Montserrat'),
(107, '(UTC-04:00) Atlantic/Bermuda', 'Atlantic/Bermuda'),
(108, '(UTC-04:00) America/Santo_Domin', 'America/Santo_Domingo'),
(109, '(UTC-04:00) America/Port_of_Spa', 'America/Port_of_Spain'),
(110, '(UTC-04:00) America/Porto_Velho', 'America/Porto_Velho'),
(111, '(UTC-04:00) America/Puerto_Rico', 'America/Puerto_Rico'),
(112, '(UTC-04:00) America/Anguilla', 'America/Anguilla'),
(113, '(UTC-04:00) America/Kralendijk', 'America/Kralendijk'),
(114, '(UTC-04:00) America/Halifax', 'America/Halifax'),
(115, '(UTC-04:00) America/Curacao', 'America/Curacao'),
(116, '(UTC-04:00) America/Barbados', 'America/Barbados'),
(117, '(UTC-04:00) America/Glace_Bay', 'America/Glace_Bay'),
(118, '(UTC-04:00) America/Goose_Bay', 'America/Goose_Bay'),
(119, '(UTC-04:00) America/Grenada', 'America/Grenada'),
(120, '(UTC-04:00) America/Guadeloupe', 'America/Guadeloupe'),
(121, '(UTC-04:00) America/Dominica', 'America/Dominica'),
(122, '(UTC-04:00) America/Blanc-Sablo', 'America/Blanc-Sablon'),
(123, '(UTC-04:00) America/Aruba', 'America/Aruba'),
(124, '(UTC-04:00) America/Guyana', 'America/Guyana'),
(125, '(UTC-04:00) America/Boa_Vista', 'America/Boa_Vista'),
(126, '(UTC-03:30) America/St_Johns', 'America/St_Johns'),
(127, '(UTC-03:00) America/Paramaribo', 'America/Paramaribo'),
(128, '(UTC-03:00) Atlantic/Stanley', 'Atlantic/Stanley'),
(129, '(UTC-03:00) America/Cuiaba', 'America/Cuiaba'),
(130, '(UTC-03:00) America/Santiago', 'America/Santiago'),
(131, '(UTC-03:00) America/Belem', 'America/Belem'),
(132, '(UTC-03:00) America/Miquelon', 'America/Miquelon'),
(133, '(UTC-03:00) America/Campo_Grand', 'America/Campo_Grande'),
(134, '(UTC-03:00) America/Argentina/S', 'America/Argentina/Salta'),
(135, '(UTC-03:00) America/Punta_Arena', 'America/Punta_Arenas'),
(136, '(UTC-03:00) Antarctica/Palmer', 'Antarctica/Palmer'),
(137, '(UTC-03:00) America/Recife', 'America/Recife'),
(138, '(UTC-03:00) America/Bahia', 'America/Bahia'),
(139, '(UTC-03:00) America/Montevideo', 'America/Montevideo'),
(140, '(UTC-03:00) Antarctica/Rothera', 'Antarctica/Rothera'),
(141, '(UTC-03:00) America/Asuncion', 'America/Asuncion'),
(142, '(UTC-03:00) America/Argentina/S', 'America/Argentina/San_Juan'),
(143, '(UTC-03:00) America/Argentina/R', 'America/Argentina/Rio_Gallegos'),
(144, '(UTC-03:00) America/Argentina/M', 'America/Argentina/Mendoza'),
(145, '(UTC-03:00) America/Argentina/L', 'America/Argentina/La_Rioja'),
(146, '(UTC-03:00) America/Argentina/J', 'America/Argentina/Jujuy'),
(147, '(UTC-03:00) America/Argentina/C', 'America/Argentina/Cordoba'),
(148, '(UTC-03:00) America/Argentina/C', 'America/Argentina/Catamarca'),
(149, '(UTC-03:00) America/Argentina/B', 'America/Argentina/Buenos_Aires'),
(150, '(UTC-03:00) America/Araguaina', 'America/Araguaina'),
(151, '(UTC-03:00) America/Argentina/U', 'America/Argentina/Ushuaia'),
(152, '(UTC-03:00) America/Santarem', 'America/Santarem'),
(153, '(UTC-03:00) America/Cayenne', 'America/Cayenne'),
(154, '(UTC-03:00) America/Argentina/S', 'America/Argentina/San_Luis'),
(155, '(UTC-03:00) America/Fortaleza', 'America/Fortaleza'),
(156, '(UTC-03:00) America/Maceio', 'America/Maceio'),
(157, '(UTC-03:00) America/Godthab', 'America/Godthab'),
(158, '(UTC-03:00) America/Argentina/T', 'America/Argentina/Tucuman'),
(159, '(UTC-02:00) America/Noronha', 'America/Noronha'),
(160, '(UTC-02:00) America/Sao_Paulo', 'America/Sao_Paulo'),
(161, '(UTC-02:00) Atlantic/South_Geor', 'Atlantic/South_Georgia'),
(162, '(UTC-01:00) Atlantic/Azores', 'Atlantic/Azores'),
(163, '(UTC-01:00) Atlantic/Cape_Verde', 'Atlantic/Cape_Verde'),
(164, '(UTC-01:00) America/Scoresbysun', 'America/Scoresbysund'),
(165, '(UTC+00:00) Atlantic/St_Helena', 'Atlantic/St_Helena'),
(166, '(UTC+00:00) Africa/Accra', 'Africa/Accra'),
(167, '(UTC+00:00) Atlantic/Reykjavik', 'Atlantic/Reykjavik'),
(168, '(UTC+00:00) Antarctica/Troll', 'Antarctica/Troll'),
(169, '(UTC+00:00) Atlantic/Faroe', 'Atlantic/Faroe'),
(170, '(UTC+00:00) Europe/London', 'Europe/London'),
(171, '(UTC+00:00) Europe/Lisbon', 'Europe/Lisbon'),
(172, '(UTC+00:00) Atlantic/Canary', 'Atlantic/Canary'),
(173, '(UTC+00:00) Europe/Jersey', 'Europe/Jersey'),
(174, '(UTC+00:00) Europe/Isle_of_Man', 'Europe/Isle_of_Man'),
(175, '(UTC+00:00) Europe/Guernsey', 'Europe/Guernsey'),
(176, '(UTC+00:00) Atlantic/Madeira', 'Atlantic/Madeira'),
(177, '(UTC+00:00) Africa/Abidjan', 'Africa/Abidjan'),
(178, '(UTC+00:00) Europe/Dublin', 'Europe/Dublin'),
(179, '(UTC+00:00) Africa/Monrovia', 'Africa/Monrovia'),
(180, '(UTC+00:00) America/Danmarkshav', 'America/Danmarkshavn'),
(181, '(UTC+00:00) Africa/El_Aaiun', 'Africa/El_Aaiun'),
(182, '(UTC+00:00) Africa/Freetown', 'Africa/Freetown'),
(183, '(UTC+00:00) Africa/Dakar', 'Africa/Dakar'),
(184, '(UTC+00:00) Africa/Conakry', 'Africa/Conakry'),
(185, '(UTC+00:00) Africa/Bissau', 'Africa/Bissau'),
(186, '(UTC+00:00) Africa/Lome', 'Africa/Lome'),
(187, '(UTC+00:00) Africa/Banjul', 'Africa/Banjul'),
(188, '(UTC+00:00) Africa/Bamako', 'Africa/Bamako'),
(189, '(UTC+00:00) Africa/Casablanca', 'Africa/Casablanca'),
(190, '(UTC+00:00) Africa/Nouakchott', 'Africa/Nouakchott'),
(191, '(UTC+00:00) Africa/Ouagadougou', 'Africa/Ouagadougou'),
(192, '(UTC+00:00) Africa/Sao_Tome', 'Africa/Sao_Tome'),
(193, '(UTC+01:00) Europe/Rome', 'Europe/Rome'),
(194, '(UTC+01:00) Europe/Budapest', 'Europe/Budapest'),
(195, '(UTC+01:00) Europe/San_Marino', 'Europe/San_Marino'),
(196, '(UTC+01:00) Europe/Sarajevo', 'Europe/Sarajevo'),
(197, '(UTC+01:00) Europe/Skopje', 'Europe/Skopje'),
(198, '(UTC+01:00) Europe/Stockholm', 'Europe/Stockholm'),
(199, '(UTC+01:00) Europe/Belgrade', 'Europe/Belgrade'),
(200, '(UTC+01:00) Europe/Podgorica', 'Europe/Podgorica'),
(201, '(UTC+01:00) Europe/Tirane', 'Europe/Tirane'),
(202, '(UTC+01:00) Europe/Vaduz', 'Europe/Vaduz'),
(203, '(UTC+01:00) Europe/Vatican', 'Europe/Vatican'),
(204, '(UTC+01:00) Europe/Busingen', 'Europe/Busingen'),
(205, '(UTC+01:00) Europe/Vienna', 'Europe/Vienna'),
(206, '(UTC+01:00) Europe/Copenhagen', 'Europe/Copenhagen'),
(207, '(UTC+01:00) Europe/Warsaw', 'Europe/Warsaw'),
(208, '(UTC+01:00) Europe/Prague', 'Europe/Prague'),
(209, '(UTC+01:00) Europe/Monaco', 'Europe/Monaco'),
(210, '(UTC+01:00) Europe/Paris', 'Europe/Paris'),
(211, '(UTC+01:00) Europe/Bratislava', 'Europe/Bratislava'),
(212, '(UTC+01:00) Europe/Amsterdam', 'Europe/Amsterdam'),
(213, '(UTC+01:00) Africa/Algiers', 'Africa/Algiers'),
(214, '(UTC+01:00) Europe/Berlin', 'Europe/Berlin'),
(215, '(UTC+01:00) Europe/Ljubljana', 'Europe/Ljubljana'),
(216, '(UTC+01:00) Africa/Bangui', 'Africa/Bangui'),
(217, '(UTC+01:00) Europe/Luxembourg', 'Europe/Luxembourg'),
(218, '(UTC+01:00) Africa/Brazzaville', 'Africa/Brazzaville'),
(219, '(UTC+01:00) Europe/Oslo', 'Europe/Oslo'),
(220, '(UTC+01:00) Europe/Zurich', 'Europe/Zurich'),
(221, '(UTC+01:00) Africa/Ceuta', 'Africa/Ceuta'),
(222, '(UTC+01:00) Europe/Brussels', 'Europe/Brussels'),
(223, '(UTC+01:00) Europe/Madrid', 'Europe/Madrid'),
(224, '(UTC+01:00) Europe/Malta', 'Europe/Malta'),
(225, '(UTC+01:00) Europe/Andorra', 'Europe/Andorra'),
(226, '(UTC+01:00) Europe/Zagreb', 'Europe/Zagreb'),
(227, '(UTC+01:00) Europe/Gibraltar', 'Europe/Gibraltar'),
(228, '(UTC+01:00) Africa/Ndjamena', 'Africa/Ndjamena'),
(229, '(UTC+01:00) Africa/Libreville', 'Africa/Libreville'),
(230, '(UTC+01:00) Africa/Malabo', 'Africa/Malabo'),
(231, '(UTC+01:00) Africa/Tunis', 'Africa/Tunis'),
(232, '(UTC+01:00) Africa/Kinshasa', 'Africa/Kinshasa'),
(233, '(UTC+01:00) Africa/Luanda', 'Africa/Luanda'),
(234, '(UTC+01:00) Africa/Porto-Novo', 'Africa/Porto-Novo'),
(235, '(UTC+01:00) Africa/Niamey', 'Africa/Niamey'),
(236, '(UTC+01:00) Africa/Douala', 'Africa/Douala'),
(237, '(UTC+01:00) Africa/Lagos', 'Africa/Lagos'),
(238, '(UTC+02:00) Africa/Maputo', 'Africa/Maputo'),
(239, '(UTC+02:00) Asia/Nicosia', 'Asia/Nicosia'),
(240, '(UTC+02:00) Africa/Lusaka', 'Africa/Lusaka'),
(241, '(UTC+02:00) Europe/Tallinn', 'Europe/Tallinn'),
(242, '(UTC+02:00) Africa/Lubumbashi', 'Africa/Lubumbashi'),
(243, '(UTC+02:00) Europe/Sofia', 'Europe/Sofia'),
(244, '(UTC+02:00) Europe/Vilnius', 'Europe/Vilnius'),
(245, '(UTC+02:00) Africa/Blantyre', 'Africa/Blantyre'),
(246, '(UTC+02:00) Africa/Bujumbura', 'Africa/Bujumbura'),
(247, '(UTC+02:00) Africa/Cairo', 'Africa/Cairo'),
(248, '(UTC+02:00) Africa/Kigali', 'Africa/Kigali'),
(249, '(UTC+02:00) Africa/Khartoum', 'Africa/Khartoum'),
(250, '(UTC+02:00) Asia/Amman', 'Asia/Amman'),
(251, '(UTC+02:00) Europe/Riga', 'Europe/Riga'),
(252, '(UTC+02:00) Europe/Mariehamn', 'Europe/Mariehamn'),
(253, '(UTC+02:00) Africa/Gaborone', 'Africa/Gaborone'),
(254, '(UTC+02:00) Europe/Uzhgorod', 'Europe/Uzhgorod'),
(255, '(UTC+02:00) Europe/Kiev', 'Europe/Kiev'),
(256, '(UTC+02:00) Africa/Johannesburg', 'Africa/Johannesburg'),
(257, '(UTC+02:00) Asia/Jerusalem', 'Asia/Jerusalem'),
(258, '(UTC+02:00) Asia/Damascus', 'Asia/Damascus'),
(259, '(UTC+02:00) Africa/Windhoek', 'Africa/Windhoek'),
(260, '(UTC+02:00) Europe/Chisinau', 'Europe/Chisinau'),
(261, '(UTC+02:00) Africa/Tripoli', 'Africa/Tripoli'),
(262, '(UTC+02:00) Asia/Famagusta', 'Asia/Famagusta'),
(263, '(UTC+02:00) Asia/Gaza', 'Asia/Gaza'),
(264, '(UTC+02:00) Asia/Hebron', 'Asia/Hebron'),
(265, '(UTC+02:00) Europe/Bucharest', 'Europe/Bucharest'),
(266, '(UTC+02:00) Europe/Athens', 'Europe/Athens'),
(267, '(UTC+02:00) Africa/Harare', 'Africa/Harare'),
(268, '(UTC+02:00) Europe/Zaporozhye', 'Europe/Zaporozhye'),
(269, '(UTC+02:00) Africa/Mbabane', 'Africa/Mbabane'),
(270, '(UTC+02:00) Europe/Helsinki', 'Europe/Helsinki'),
(271, '(UTC+02:00) Africa/Maseru', 'Africa/Maseru'),
(272, '(UTC+02:00) Asia/Beirut', 'Asia/Beirut'),
(273, '(UTC+02:00) Europe/Kaliningrad', 'Europe/Kaliningrad'),
(274, '(UTC+03:00) Africa/Mogadishu', 'Africa/Mogadishu'),
(275, '(UTC+03:00) Europe/Kirov', 'Europe/Kirov'),
(276, '(UTC+03:00) Africa/Addis_Ababa', 'Africa/Addis_Ababa'),
(277, '(UTC+03:00) Africa/Kampala', 'Africa/Kampala'),
(278, '(UTC+03:00) Europe/Istanbul', 'Europe/Istanbul'),
(279, '(UTC+03:00) Africa/Asmara', 'Africa/Asmara'),
(280, '(UTC+03:00) Africa/Juba', 'Africa/Juba'),
(281, '(UTC+03:00) Europe/Minsk', 'Europe/Minsk'),
(282, '(UTC+03:00) Antarctica/Syowa', 'Antarctica/Syowa'),
(283, '(UTC+03:00) Africa/Nairobi', 'Africa/Nairobi'),
(284, '(UTC+03:00) Indian/Mayotte', 'Indian/Mayotte'),
(285, '(UTC+03:00) Europe/Moscow', 'Europe/Moscow'),
(286, '(UTC+03:00) Asia/Riyadh', 'Asia/Riyadh'),
(287, '(UTC+03:00) Indian/Comoro', 'Indian/Comoro'),
(288, '(UTC+03:00) Indian/Antananarivo', 'Indian/Antananarivo'),
(289, '(UTC+03:00) Africa/Dar_es_Salaa', 'Africa/Dar_es_Salaam'),
(290, '(UTC+03:00) Africa/Djibouti', 'Africa/Djibouti'),
(291, '(UTC+03:00) Europe/Volgograd', 'Europe/Volgograd'),
(292, '(UTC+03:00) Asia/Kuwait', 'Asia/Kuwait'),
(293, '(UTC+03:00) Asia/Aden', 'Asia/Aden'),
(294, '(UTC+03:00) Asia/Baghdad', 'Asia/Baghdad'),
(295, '(UTC+03:00) Asia/Qatar', 'Asia/Qatar'),
(296, '(UTC+03:00) Europe/Simferopol', 'Europe/Simferopol'),
(297, '(UTC+03:00) Asia/Bahrain', 'Asia/Bahrain'),
(298, '(UTC+03:30) Asia/Tehran', 'Asia/Tehran'),
(299, '(UTC+04:00) Europe/Saratov', 'Europe/Saratov'),
(300, '(UTC+04:00) Asia/Baku', 'Asia/Baku'),
(301, '(UTC+04:00) Indian/Reunion', 'Indian/Reunion'),
(302, '(UTC+04:00) Asia/Tbilisi', 'Asia/Tbilisi'),
(303, '(UTC+04:00) Europe/Samara', 'Europe/Samara'),
(304, '(UTC+04:00) Asia/Yerevan', 'Asia/Yerevan'),
(305, '(UTC+04:00) Asia/Muscat', 'Asia/Muscat'),
(306, '(UTC+04:00) Europe/Ulyanovsk', 'Europe/Ulyanovsk'),
(307, '(UTC+04:00) Indian/Mahe', 'Indian/Mahe'),
(308, '(UTC+04:00) Asia/Dubai', 'Asia/Dubai'),
(309, '(UTC+04:00) Indian/Mauritius', 'Indian/Mauritius'),
(310, '(UTC+04:00) Europe/Astrakhan', 'Europe/Astrakhan'),
(311, '(UTC+04:30) Asia/Kabul', 'Asia/Kabul'),
(312, '(UTC+05:00) Indian/Kerguelen', 'Indian/Kerguelen'),
(313, '(UTC+05:00) Asia/Dushanbe', 'Asia/Dushanbe'),
(314, '(UTC+05:00) Indian/Maldives', 'Indian/Maldives'),
(315, '(UTC+05:00) Asia/Tashkent', 'Asia/Tashkent'),
(316, '(UTC+05:00) Asia/Karachi', 'Asia/Karachi'),
(317, '(UTC+05:00) Asia/Samarkand', 'Asia/Samarkand'),
(318, '(UTC+05:00) Asia/Yekaterinburg', 'Asia/Yekaterinburg'),
(319, '(UTC+05:00) Asia/Aqtau', 'Asia/Aqtau'),
(320, '(UTC+05:00) Antarctica/Mawson', 'Antarctica/Mawson'),
(321, '(UTC+05:00) Asia/Oral', 'Asia/Oral'),
(322, '(UTC+05:00) Asia/Atyrau', 'Asia/Atyrau'),
(323, '(UTC+05:00) Asia/Ashgabat', 'Asia/Ashgabat'),
(324, '(UTC+05:00) Asia/Aqtobe', 'Asia/Aqtobe'),
(325, '(UTC+05:30) Asia/Kolkata', 'Asia/Kolkata'),
(326, '(UTC+05:30) Asia/Colombo', 'Asia/Colombo'),
(327, '(UTC+05:45) Asia/Kathmandu', 'Asia/Kathmandu'),
(328, '(UTC+06:00) Indian/Chagos', 'Indian/Chagos'),
(329, '(UTC+06:00) Asia/Almaty', 'Asia/Almaty'),
(330, '(UTC+06:00) Asia/Urumqi', 'Asia/Urumqi'),
(331, '(UTC+06:00) Asia/Bishkek', 'Asia/Bishkek'),
(332, '(UTC+06:00) Asia/Qyzylorda', 'Asia/Qyzylorda'),
(333, '(UTC+06:00) Antarctica/Vostok', 'Antarctica/Vostok'),
(334, '(UTC+06:00) Asia/Dhaka', 'Asia/Dhaka'),
(335, '(UTC+06:00) Asia/Omsk', 'Asia/Omsk'),
(336, '(UTC+06:00) Asia/Thimphu', 'Asia/Thimphu'),
(337, '(UTC+06:30) Indian/Cocos', 'Indian/Cocos'),
(338, '(UTC+06:30) Asia/Yangon', 'Asia/Yangon'),
(339, '(UTC+07:00) Asia/Pontianak', 'Asia/Pontianak'),
(340, '(UTC+07:00) Asia/Phnom_Penh', 'Asia/Phnom_Penh'),
(341, '(UTC+07:00) Indian/Christmas', 'Indian/Christmas'),
(342, '(UTC+07:00) Asia/Novokuznetsk', 'Asia/Novokuznetsk'),
(343, '(UTC+07:00) Asia/Jakarta', 'Asia/Jakarta'),
(344, '(UTC+07:00) Asia/Hovd', 'Asia/Hovd'),
(345, '(UTC+07:00) Asia/Ho_Chi_Minh', 'Asia/Ho_Chi_Minh'),
(346, '(UTC+07:00) Asia/Bangkok', 'Asia/Bangkok'),
(347, '(UTC+07:00) Asia/Krasnoyarsk', 'Asia/Krasnoyarsk'),
(348, '(UTC+07:00) Asia/Novosibirsk', 'Asia/Novosibirsk'),
(349, '(UTC+07:00) Asia/Tomsk', 'Asia/Tomsk'),
(350, '(UTC+07:00) Asia/Vientiane', 'Asia/Vientiane'),
(351, '(UTC+07:00) Antarctica/Davis', 'Antarctica/Davis'),
(352, '(UTC+07:00) Asia/Barnaul', 'Asia/Barnaul'),
(353, '(UTC+08:00) Asia/Irkutsk', 'Asia/Irkutsk'),
(354, '(UTC+08:00) Asia/Hong_Kong', 'Asia/Hong_Kong'),
(355, '(UTC+08:00) Asia/Kuala_Lumpur', 'Asia/Kuala_Lumpur'),
(356, '(UTC+08:00) Asia/Kuching', 'Asia/Kuching'),
(357, '(UTC+08:00) Asia/Macau', 'Asia/Macau'),
(358, '(UTC+08:00) Australia/Perth', 'Australia/Perth'),
(359, '(UTC+08:00) Asia/Makassar', 'Asia/Makassar'),
(360, '(UTC+08:00) Asia/Manila', 'Asia/Manila'),
(361, '(UTC+08:00) Asia/Ulaanbaatar', 'Asia/Ulaanbaatar'),
(362, '(UTC+08:00) Asia/Singapore', 'Asia/Singapore'),
(363, '(UTC+08:00) Asia/Taipei', 'Asia/Taipei'),
(364, '(UTC+08:00) Asia/Choibalsan', 'Asia/Choibalsan'),
(365, '(UTC+08:00) Asia/Brunei', 'Asia/Brunei'),
(366, '(UTC+08:00) Asia/Shanghai', 'Asia/Shanghai'),
(367, '(UTC+08:30) Asia/Pyongyang', 'Asia/Pyongyang'),
(368, '(UTC+08:45) Australia/Eucla', 'Australia/Eucla'),
(369, '(UTC+09:00) Asia/Dili', 'Asia/Dili'),
(370, '(UTC+09:00) Asia/Chita', 'Asia/Chita'),
(371, '(UTC+09:00) Asia/Khandyga', 'Asia/Khandyga'),
(372, '(UTC+09:00) Asia/Jayapura', 'Asia/Jayapura'),
(373, '(UTC+09:00) Asia/Seoul', 'Asia/Seoul'),
(374, '(UTC+09:00) Pacific/Palau', 'Pacific/Palau'),
(375, '(UTC+09:00) Asia/Tokyo', 'Asia/Tokyo'),
(376, '(UTC+09:00) Asia/Yakutsk', 'Asia/Yakutsk'),
(377, '(UTC+09:30) Australia/Darwin', 'Australia/Darwin'),
(378, '(UTC+10:00) Asia/Ust-Nera', 'Asia/Ust-Nera'),
(379, '(UTC+10:00) Pacific/Saipan', 'Pacific/Saipan'),
(380, '(UTC+10:00) Pacific/Guam', 'Pacific/Guam'),
(381, '(UTC+10:00) Antarctica/DumontDU', 'Antarctica/DumontDUrville'),
(382, '(UTC+10:00) Asia/Vladivostok', 'Asia/Vladivostok'),
(383, '(UTC+10:00) Australia/Lindeman', 'Australia/Lindeman'),
(384, '(UTC+10:00) Australia/Brisbane', 'Australia/Brisbane'),
(385, '(UTC+10:00) Pacific/Port_Moresb', 'Pacific/Port_Moresby'),
(386, '(UTC+10:00) Pacific/Chuuk', 'Pacific/Chuuk'),
(387, '(UTC+10:30) Australia/Adelaide', 'Australia/Adelaide'),
(388, '(UTC+10:30) Australia/Broken_Hi', 'Australia/Broken_Hill'),
(389, '(UTC+11:00) Pacific/Guadalcanal', 'Pacific/Guadalcanal'),
(390, '(UTC+11:00) Antarctica/Casey', 'Antarctica/Casey'),
(391, '(UTC+11:00) Antarctica/Macquari', 'Antarctica/Macquarie'),
(392, '(UTC+11:00) Pacific/Kosrae', 'Pacific/Kosrae'),
(393, '(UTC+11:00) Pacific/Norfolk', 'Pacific/Norfolk'),
(394, '(UTC+11:00) Pacific/Noumea', 'Pacific/Noumea'),
(395, '(UTC+11:00) Pacific/Pohnpei', 'Pacific/Pohnpei'),
(396, '(UTC+11:00) Australia/Sydney', 'Australia/Sydney'),
(397, '(UTC+11:00) Pacific/Efate', 'Pacific/Efate'),
(398, '(UTC+11:00) Australia/Melbourne', 'Australia/Melbourne'),
(399, '(UTC+11:00) Australia/Lord_Howe', 'Australia/Lord_Howe'),
(400, '(UTC+11:00) Australia/Hobart', 'Australia/Hobart'),
(401, '(UTC+11:00) Australia/Currie', 'Australia/Currie'),
(402, '(UTC+11:00) Asia/Srednekolymsk', 'Asia/Srednekolymsk'),
(403, '(UTC+11:00) Pacific/Bougainvill', 'Pacific/Bougainville'),
(404, '(UTC+11:00) Asia/Sakhalin', 'Asia/Sakhalin'),
(405, '(UTC+11:00) Asia/Magadan', 'Asia/Magadan'),
(406, '(UTC+12:00) Pacific/Funafuti', 'Pacific/Funafuti'),
(407, '(UTC+12:00) Asia/Kamchatka', 'Asia/Kamchatka'),
(408, '(UTC+12:00) Pacific/Wake', 'Pacific/Wake'),
(409, '(UTC+12:00) Pacific/Tarawa', 'Pacific/Tarawa'),
(410, '(UTC+12:00) Pacific/Wallis', 'Pacific/Wallis'),
(411, '(UTC+12:00) Pacific/Fiji', 'Pacific/Fiji'),
(412, '(UTC+12:00) Pacific/Nauru', 'Pacific/Nauru'),
(413, '(UTC+12:00) Asia/Anadyr', 'Asia/Anadyr'),
(414, '(UTC+12:00) Pacific/Majuro', 'Pacific/Majuro'),
(415, '(UTC+12:00) Pacific/Kwajalein', 'Pacific/Kwajalein'),
(416, '(UTC+13:00) Antarctica/McMurdo', 'Antarctica/McMurdo'),
(417, '(UTC+13:00) Pacific/Enderbury', 'Pacific/Enderbury'),
(418, '(UTC+13:00) Pacific/Tongatapu', 'Pacific/Tongatapu'),
(419, '(UTC+13:00) Pacific/Fakaofo', 'Pacific/Fakaofo'),
(420, '(UTC+13:00) Pacific/Auckland', 'Pacific/Auckland'),
(421, '(UTC+13:45) Pacific/Chatham', 'Pacific/Chatham'),
(422, '(UTC+14:00) Pacific/Apia', 'Pacific/Apia'),
(423, '(UTC+14:00) Pacific/Kiritimati', 'Pacific/Kiritimati');

-- --------------------------------------------------------

--
-- Table structure for table `usermessages`
--

CREATE TABLE `usermessages` (
  `id` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `type` enum('whatsapp','sms','email') NOT NULL,
  `contact` varchar(64) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` longtext DEFAULT NULL,
  `scheduled_at` text DEFAULT NULL,
  `sent_at` text DEFAULT current_timestamp(),
  `sent_by` int(11) DEFAULT NULL,
  `status` enum('Pending','Sent','Failed') NOT NULL DEFAULT 'Pending',
  `school` int(11) NOT NULL,
  `branch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `usermessages`
--

INSERT INTO `usermessages` (`id`, `receiver`, `type`, `contact`, `subject`, `message`, `scheduled_at`, `sent_at`, `sent_by`, `status`, `school`, `branch`) VALUES
(1, 36, 'whatsapp', '7419999195', NULL, 'Hello! test123, your Practical class for Beginner course which was scheduled on 05 August 2023 at 12:00 AM to 12:30 AM has been cancelled.\n\nIf you have any query, Please Contact our manager Mr. Pratham Sharma at Ph: 7419999195\n\nRegards,\nRCDS - Real Car Driving School', '2023-08-11 22:26:30', '2023-08-11 20:56:30', 1, 'Sent', 1, 1),
(2, 36, 'sms', '7419999195', NULL, 'Hello! test123, a Practical class for your Beginner course has been scheduled on 11 August 2023 at 12:00 AM to 12:30 AM with Mr. Hemanth Verma Ph: 7419999195\n\nIf you have any query, Please contact our manager Mr. Pratham Sharma at Ph: 7419999195\n\nRegards,\nRCDS - Real Car Driving School', NULL, '2023-08-11 20:56:51', NULL, 'Failed', 1, 1),
(3, 23, 'whatsapp', '+917419999195', 'Class Update', 'Dear Pratham,\n\nGreetings from RCDS. We would like to inform you that *test123 hello* will be *Present* for the class which is scheduled at *12:00 AM* today.\n\nRegards,\nRCDS - Real Car Driving School', '11-08-2023 22:40:43', '2023-08-11 21:10:43', 1, 'Sent', 1, 1),
(4, 33, 'sms', '9034179580', NULL, 'Hello! tester, a Practical class for your Beginner - Fast Track course has been scheduled on 12 August 2023 at 12:00 AM to 12:30 AM with Mr. Hemanth Verma Ph: 7419999195\n\nIf you have any query, Please contact our manager Mr. Pratham Sharma at Ph: 7419999195\n\nRegards,\nRCDS - Real Car Driving School', NULL, '2023-08-11 22:36:04', NULL, 'Failed', 1, 1),
(5, 23, 'whatsapp', '+917419999195', 'Class Update', 'Dear Pratham,\n\nGreetings from RCDS. We would like to inform you that *test123 hello* will be *Present* for the class which is scheduled at *12:00 AM* today.\n\nRegards,\nRCDS - Real Car Driving School', '12-08-2023 00:15:44', '2023-08-11 22:45:44', 1, 'Sent', 1, 1),
(6, 36, 'sms', '7419999195', NULL, 'Hello! test123, a Practical class for your Beginner course has been scheduled on 21 August 2023 at 12:00 AM to 12:30 AM with Mr. Hemanth Verma Ph: 7419999195\n\nIf you have any query, Please contact our manager Mr. Pratham Sharma at Ph: 7419999195\n\nRegards,\nRCDS - Real Car Driving School', NULL, '2023-08-21 20:04:47', NULL, 'Failed', 1, 1),
(7, 23, 'whatsapp', '+917419999195', 'Class Update', 'Dear Pratham,\n\nGreetings from RCDS. We would like to inform you that *test123 hello* will be *Absent* for the class which is scheduled at *12:00 AM* today.\n\nRegards,\nRCDS - Real Car Driving School', '21-08-2023 21:37:14', '2023-08-21 20:07:14', 1, 'Sent', 1, 1),
(8, 23, 'whatsapp', '+917419999195', 'Class Update', 'Dear Pratham,\n\nGreetings from RCDS. We would like to inform you that *test123 hello* will be *Present* for the class which is scheduled at *12:00 AM* today.\n\nRegards,\nRCDS - Real Car Driving School', '22-08-2023 00:41:51', '2023-08-21 23:11:51', 1, 'Sent', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `userpermission`
--

CREATE TABLE `userpermission` (
  `id` int(1) NOT NULL,
  `Amdashboardget` int(1) DEFAULT NULL,
  `Amdashboardfuelexpanses` int(1) DEFAULT NULL,
  `Amdashboarddeletefuelexpenses` int(1) DEFAULT NULL,
  `Amdashboardotherexpenses` int(1) DEFAULT NULL,
  `Amdashboarddeleteotherexpenses` int(1) DEFAULT NULL,
  `Amdashboardservicerecords` int(1) DEFAULT NULL,
  `Amdashboarddeleteservicerecords` int(1) DEFAULT NULL,
  `Amdashboardupdateservicerecord` int(1) DEFAULT NULL,
  `Amdashboarddropout` int(1) DEFAULT NULL,
  `Amdashboarddeletedropout` int(1) DEFAULT NULL,
  `Amdashboardupdatexpenses` int(1) DEFAULT NULL,
  `Attendanceget` int(1) DEFAULT NULL,
  `Attendancepresent` int(1) DEFAULT NULL,
  `Authget` int(1) DEFAULT NULL,
  `Authsignin` int(1) DEFAULT NULL,
  `Authsignup` int(1) DEFAULT NULL,
  `Authforgot` int(1) DEFAULT NULL,
  `Authresetview` int(1) DEFAULT NULL,
  `Authreset` int(1) DEFAULT NULL,
  `Authsignout` int(1) DEFAULT NULL,
  `Branchget` int(1) DEFAULT NULL,
  `Branchcreate` int(1) DEFAULT NULL,
  `Branchdelete` int(1) DEFAULT NULL,
  `Branchupdateview` int(1) DEFAULT NULL,
  `Branchupdate` int(1) DEFAULT NULL,
  `Branchsendemail` int(1) DEFAULT NULL,
  `Branchsendesms` int(1) DEFAULT NULL,
  `Branchswitcher` int(1) DEFAULT NULL,
  `Cancelledget` int(1) DEFAULT NULL,
  `Classesget` int(1) DEFAULT NULL,
  `Classsummaryget` int(1) DEFAULT NULL,
  `Communicationget` int(1) DEFAULT NULL,
  `Communicationsms` int(1) DEFAULT NULL,
  `Communicationemail` int(1) DEFAULT NULL,
  `Communicationread` int(1) DEFAULT NULL,
  `Communicationdelete` int(1) DEFAULT NULL,
  `Completedget` int(1) DEFAULT NULL,
  `Controllermiddleware` int(1) DEFAULT NULL,
  `Courseget` int(1) DEFAULT NULL,
  `Coursecreate` int(1) DEFAULT NULL,
  `Coursecreateonline` int(1) DEFAULT NULL,
  `Coursedelete` int(1) DEFAULT NULL,
  `Coursedeletecontent` int(1) DEFAULT NULL,
  `Courseloadlecture` int(1) DEFAULT NULL,
  `Coursedeletecurriculum` int(1) DEFAULT NULL,
  `Coursedeleteuploads` int(1) DEFAULT NULL,
  `Courseupdateview` int(1) DEFAULT NULL,
  `Courseupdate` int(1) DEFAULT NULL,
  `Courseeditonlineclass` int(1) DEFAULT NULL,
  `Coursepublishclass` int(1) DEFAULT NULL,
  `Coursepreview` int(1) DEFAULT NULL,
  `Coursecurriculum` int(1) DEFAULT NULL,
  `Courselearn` int(1) DEFAULT NULL,
  `Courseclassstudents` int(1) DEFAULT NULL,
  `Courseupdatecontent` int(1) DEFAULT NULL,
  `Coursesections` int(1) DEFAULT NULL,
  `Dailyupdatesget` int(1) DEFAULT NULL,
  `Dailyupdatesfuelexpenses` int(1) DEFAULT NULL,
  `Dailyupdatesdeletefuelexpenses` int(1) DEFAULT NULL,
  `Dailyupdatesotherexpenses` int(1) DEFAULT NULL,
  `Dailyupdatesdeleteotherexpenses` int(1) DEFAULT NULL,
  `Dailyupdatesservicerecords` int(1) DEFAULT NULL,
  `Dailyupdatesdeleteservicerecords` int(1) DEFAULT NULL,
  `Dailyupdatesupdateservicerecord` int(1) DEFAULT NULL,
  `Dailyupdatesdropout` int(1) DEFAULT NULL,
  `Dailyupdatesdeletedropout` int(1) DEFAULT NULL,
  `Dailyupdatesupdateexpenses` int(1) DEFAULT NULL,
  `Dashboardget` int(1) DEFAULT NULL,
  `Dashboardtotals` int(1) DEFAULT NULL,
  `Dashboardprevious` int(1) DEFAULT NULL,
  `Dashboardcurrent` int(1) DEFAULT NULL,
  `Dashboardgrowth` int(1) DEFAULT NULL,
  `Dashboardstudents` int(1) DEFAULT NULL,
  `Dashboardexpenses` int(1) DEFAULT NULL,
  `Dashboardinvoices` int(1) DEFAULT NULL,
  `Dashboardnotifications` int(1) DEFAULT NULL,
  `Dashboardcourses` int(1) DEFAULT NULL,
  `Examcreate` int(1) DEFAULT NULL,
  `Examupdate` int(1) DEFAULT NULL,
  `Examdelete` int(1) DEFAULT NULL,
  `Exampublish` int(1) DEFAULT NULL,
  `Exambuilder` int(1) DEFAULT NULL,
  `Examtakeexam` int(1) DEFAULT NULL,
  `Examsave` int(1) DEFAULT NULL,
  `Examupdatequestions` int(1) DEFAULT NULL,
  `Examexamstudents` int(1) DEFAULT NULL,
  `Examsections` int(1) DEFAULT NULL,
  `Examget` int(1) DEFAULT NULL,
  `Examdeletecontent` int(1) DEFAULT NULL,
  `Examloadlecture` int(1) DEFAULT NULL,
  `Examdeleteuploads` int(1) DEFAULT NULL,
  `Examupdateview` int(1) DEFAULT NULL,
  `Exampreview` int(1) DEFAULT NULL,
  `Examcurriculum` int(1) DEFAULT NULL,
  `Exam@learn` int(1) DEFAULT NULL,
  `Examclassstudents` int(1) DEFAULT NULL,
  `Fleetget` int(1) DEFAULT NULL,
  `Fleetadd` int(1) DEFAULT NULL,
  `Fleetdelete` int(1) DEFAULT NULL,
  `Fleetupdateview` int(1) DEFAULT NULL,
  `Fleetupdate` int(1) DEFAULT NULL,
  `Fleetdashboardget` int(1) DEFAULT NULL,
  `Fleetdashboardtotals` int(1) DEFAULT NULL,
  `Fleetdashboardprevious` int(1) DEFAULT NULL,
  `Fleetdashboardcurrent` int(1) DEFAULT NULL,
  `Fleetdashboardgrowth` int(1) DEFAULT NULL,
  `Fleetdashboardstudents` int(1) DEFAULT NULL,
  `Fleetdashboardexpenses` int(1) DEFAULT NULL,
  `Fleetdashboardinvoices` int(1) DEFAULT NULL,
  `Fleetdashboardnotifications` int(1) DEFAULT NULL,
  `Fleetdashboardcourses` int(1) DEFAULT NULL,
  `Getchating@get` int(1) DEFAULT NULL,
  `Getclassget` int(1) DEFAULT NULL,
  `Getclassget3` int(1) DEFAULT NULL,
  `Getcommunicationget` int(1) DEFAULT NULL,
  `Getfleetrecordget` int(1) DEFAULT NULL,
  `Getfleetrecordupdate` int(1) DEFAULT NULL,
  `Getfleetrecorddeletemaintainancerecord` int(1) DEFAULT NULL,
  `Instructorget` int(1) DEFAULT NULL,
  `Instructorcreate` int(1) DEFAULT NULL,
  `Invoiceget` int(1) DEFAULT NULL,
  `Invoicedeletepayment` int(1) DEFAULT NULL,
  `Invoiceviewpayments` int(1) DEFAULT NULL,
  `Invoiceupdate` int(1) DEFAULT NULL,
  `Invoiceupdateview` int(1) DEFAULT NULL,
  `Invoicedelete` int(1) DEFAULT NULL,
  `Invoicedownload` int(1) DEFAULT NULL,
  `Invoicepreview` int(1) DEFAULT NULL,
  `Invoiceshare` int(1) DEFAULT NULL,
  `Issuesget` int(1) DEFAULT NULL,
  `Issuesreportissue` int(1) DEFAULT NULL,
  `Issuesprocessing` int(1) DEFAULT NULL,
  `Issuesupdatecomment` int(1) DEFAULT NULL,
  `Issuesupdatebrief` int(1) DEFAULT NULL,
  `Issuesresolved` int(1) DEFAULT NULL,
  `Issuesremove` int(1) DEFAULT NULL,
  `Licenseget` int(1) DEFAULT NULL,
  `Licensenew` int(1) DEFAULT NULL,
  `Licenserenew` int(1) DEFAULT NULL,
  `Licenseupdate` int(1) DEFAULT NULL,
  `Licensedelete` int(1) DEFAULT NULL,
  `Markedget` int(1) DEFAULT NULL,
  `Markedreset` int(1) DEFAULT NULL,
  `Markedmarkpresent` int(1) DEFAULT NULL,
  `Monthlyget` int(1) DEFAULT NULL,
  `Monthlytotals` int(1) DEFAULT NULL,
  `Monthlyprevious` int(1) DEFAULT NULL,
  `Monthlycurrent` int(1) DEFAULT NULL,
  `Monthlygrowth` int(1) DEFAULT NULL,
  `Monthlystudents` int(1) DEFAULT NULL,
  `Monthlyexpenses` int(1) DEFAULT NULL,
  `Monthlyinvoices` int(1) DEFAULT NULL,
  `Monthlynotifications` int(1) DEFAULT NULL,
  `Monthlycourses` int(1) DEFAULT NULL,
  `newfleetrecordget` int(1) DEFAULT NULL,
  `newfleetrecordaddnew` int(1) DEFAULT NULL,
  `newfleetrecorddelete` int(1) DEFAULT NULL,
  `newfleetrecordupdateview` int(1) DEFAULT NULL,
  `newfleetrecordupdate` int(1) DEFAULT NULL,
  `Newlicenseget` int(1) DEFAULT NULL,
  `Newlicenseenroll` int(1) DEFAULT NULL,
  `Newlicenseenrolled` int(1) DEFAULT NULL,
  `Newlicensestarted` int(1) DEFAULT NULL,
  `Newlicensepayment` int(1) DEFAULT NULL,
  `Newlicenseprocessing` int(1) DEFAULT NULL,
  `Newlicenselearning` int(1) DEFAULT NULL,
  `Newlicensepermanent` int(1) DEFAULT NULL,
  `Newlicensecompleted` int(1) DEFAULT NULL,
  `Newlicenseupdatecomment` int(1) DEFAULT NULL,
  `Newlicensecancaelled` int(1) DEFAULT NULL,
  `Notificationget` int(1) DEFAULT NULL,
  `Notificationread` int(1) DEFAULT NULL,
  `Notificationcount` int(1) DEFAULT NULL,
  `Oldrecordsget` int(1) DEFAULT NULL,
  `Ongoingget` int(1) DEFAULT NULL,
  `Ongoingreset` int(1) DEFAULT NULL,
  `Ongoingabsent` int(1) DEFAULT NULL,
  `Payslipget` int(1) DEFAULT NULL,
  `Payslipdownload` int(1) DEFAULT NULL,
  `Payslipsharepayslip` int(1) DEFAULT NULL,
  `Payslippayslipdownload` int(1) DEFAULT NULL,
  `Payslippreview` int(1) DEFAULT NULL,
  `PayslipnumberTowords` int(1) DEFAULT NULL,
  `Practicallessonsget` int(1) DEFAULT NULL,
  `Practicallessonscreate` int(1) DEFAULT NULL,
  `Practicallessonsupdate` int(1) DEFAULT NULL,
  `Practicallessonsactive` int(1) DEFAULT NULL,
  `Practicallessonsinactive` int(1) DEFAULT NULL,
  `Practicallessonsdelete` int(1) DEFAULT NULL,
  `Practicallessonsaddcourse` int(1) DEFAULT NULL,
  `Profileget` int(1) DEFAULT NULL,
  `Profileupdate` int(1) DEFAULT NULL,
  `Profileaddaccountdetails` int(1) DEFAULT NULL,
  `Profileupdateaccount` int(1) DEFAULT NULL,
  `Profilesetongoing` int(1) DEFAULT NULL,
  `Profilesetwaiting` int(1) DEFAULT NULL,
  `Profilesetcancelled` int(1) DEFAULT NULL,
  `Profilesetcompleted` int(1) DEFAULT NULL,
  `Profilesetdefaulter` int(1) DEFAULT NULL,
  `Profileresetdefaulter` int(1) DEFAULT NULL,
  `Profiledelete` int(1) DEFAULT NULL,
  `Profilesendemail` int(1) DEFAULT NULL,
  `Profilesendsms` int(1) DEFAULT NULL,
  `Profileaddnote` int(1) DEFAULT NULL,
  `Profiledeletenote` int(1) DEFAULT NULL,
  `Profilereadnote` int(1) DEFAULT NULL,
  `Profileupdatenoteview` int(1) DEFAULT NULL,
  `Profileupdatenote` int(1) DEFAULT NULL,
  `Profileuploadattachment` int(1) DEFAULT NULL,
  `Profiledeleteattachment` int(1) DEFAULT NULL,
  `Profiledisconnectgoogle` int(1) DEFAULT NULL,
  `Profilerequestreview` int(1) DEFAULT NULL,
  `Profileaddadvance` int(1) DEFAULT NULL,
  `Profiledeleteadvance` int(1) DEFAULT NULL,
  `Profileaddincentive` int(1) DEFAULT NULL,
  `Profiledeleteincentive` int(1) DEFAULT NULL,
  `Profileactivateaccount` int(1) DEFAULT NULL,
  `Profiledactivateaccount` int(1) DEFAULT NULL,
  `Profilegeneratepayslip` int(1) DEFAULT NULL,
  `Profiledeletepayslip` int(1) DEFAULT NULL,
  `Profileupdatepayslip` int(1) DEFAULT NULL,
  `Profileaddattendance` int(1) DEFAULT NULL,
  `Profileupdateattendance` int(1) DEFAULT NULL,
  `Profiledeleteattendance` int(1) DEFAULT NULL,
  `Recordsget` int(1) DEFAULT NULL,
  `Rescheduleget` int(1) DEFAULT NULL,
  `ReschedulevalidateDate` int(1) DEFAULT NULL,
  `Rescheduleclasses` int(1) DEFAULT NULL,
  `Rescheduleliststudents` int(1) DEFAULT NULL,
  `Rescheduleupdatetrainer` int(1) DEFAULT NULL,
  `Scheduleget` int(1) DEFAULT NULL,
  `Schedulecreate` int(1) DEFAULT NULL,
  `SchedulelandaDate` int(1) DEFAULT NULL,
  `Schedulefetch` int(1) DEFAULT NULL,
  `Scheduledelete` int(1) DEFAULT NULL,
  `Scheduleupdateview` int(1) DEFAULT NULL,
  `Scheduleupdate` int(1) DEFAULT NULL,
  `Schedulesmsnotification` int(1) DEFAULT NULL,
  `SchedulecalendarSync` int(1) DEFAULT NULL,
  `ScheduleNotificationget` int(1) DEFAULT NULL,
  `Schoolget` int(1) DEFAULT NULL,
  `Schoolcreate` int(1) DEFAULT NULL,
  `Schooldelete` int(1) DEFAULT NULL,
  `Schoolupdateview` int(1) DEFAULT NULL,
  `Schoolupdate` int(1) DEFAULT NULL,
  `Schoolsendemail` int(1) DEFAULT NULL,
  `Schoolsendsms` int(1) DEFAULT NULL,
  `Settingsget` int(1) DEFAULT NULL,
  `SettingsgetCurrencySymbol` int(1) DEFAULT NULL,
  `Settingsupdateprofile` int(1) DEFAULT NULL,
  `Settingsupdatcompany` int(1) DEFAULT NULL,
  `Settingsupdatereminders` int(1) DEFAULT NULL,
  `Settingsupdatepassword` int(1) DEFAULT NULL,
  `Settingsupdatesystem` int(1) DEFAULT NULL,
  `Staffget` int(1) DEFAULT NULL,
  `Staffcreate` int(1) DEFAULT NULL,
  `Staffsummaryget` int(1) DEFAULT NULL,
  `Studentget` int(1) DEFAULT NULL,
  `Studentcreate` int(1) DEFAULT NULL,
  `Studentaddcourse` int(1) DEFAULT NULL,
  `Studentenroll` int(1) DEFAULT NULL,
  `Studentdeleteenroll` int(1) DEFAULT NULL,
  `Studentcreateinvoice` int(1) DEFAULT NULL,
  `Todayget` int(1) DEFAULT NULL,
  `Todaygetdetails` int(1) DEFAULT NULL,
  `Todaystart` int(1) DEFAULT NULL,
  `Todayabsent` int(1) DEFAULT NULL,
  `Todaynotify` int(1) DEFAULT NULL,
  `Todayrequestpayment` int(1) DEFAULT NULL,
  `Updateget` int(1) DEFAULT NULL,
  `Updatescan` int(1) DEFAULT NULL,
  `Updateversions` int(1) DEFAULT NULL,
  `Updateupdate` int(1) DEFAULT NULL,
  `Updatesget` int(1) DEFAULT NULL,
  `Updatesfuelexpenses` int(1) DEFAULT NULL,
  `Updatesotherexpenses` int(1) DEFAULT NULL,
  `Updatesdropout` int(1) DEFAULT NULL,
  `Updatesupdatecompany` int(1) DEFAULT NULL,
  `Updatesupdatereminders` int(1) DEFAULT NULL,
  `Updatesupdatepassword` int(1) DEFAULT NULL,
  `Updatesupdatesystem` int(1) DEFAULT NULL,
  `Updatestudentaadharget` int(1) DEFAULT NULL,
  `Updatestudentaadharupdate` int(1) DEFAULT NULL,
  `Updatestudentprofileget` int(1) DEFAULT NULL,
  `Updatestudentprofileupdate` int(1) DEFAULT NULL,
  `waitinglistget` int(1) DEFAULT NULL,
  `waitinglistcreate` int(1) DEFAULT NULL,
  `waitinglistaddcourse` int(1) DEFAULT NULL,
  `waitinglistenroll` int(1) DEFAULT NULL,
  `waitinglistdeleteenrollment` int(1) DEFAULT NULL,
  `waitinglistcreateinvoice` int(1) DEFAULT NULL,
  `Welcomeget` int(1) DEFAULT NULL,
  `Welcomeiattend` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `userpermission`
--

INSERT INTO `userpermission` (`id`, `Amdashboardget`, `Amdashboardfuelexpanses`, `Amdashboarddeletefuelexpenses`, `Amdashboardotherexpenses`, `Amdashboarddeleteotherexpenses`, `Amdashboardservicerecords`, `Amdashboarddeleteservicerecords`, `Amdashboardupdateservicerecord`, `Amdashboarddropout`, `Amdashboarddeletedropout`, `Amdashboardupdatexpenses`, `Attendanceget`, `Attendancepresent`, `Authget`, `Authsignin`, `Authsignup`, `Authforgot`, `Authresetview`, `Authreset`, `Authsignout`, `Branchget`, `Branchcreate`, `Branchdelete`, `Branchupdateview`, `Branchupdate`, `Branchsendemail`, `Branchsendesms`, `Branchswitcher`, `Cancelledget`, `Classesget`, `Classsummaryget`, `Communicationget`, `Communicationsms`, `Communicationemail`, `Communicationread`, `Communicationdelete`, `Completedget`, `Controllermiddleware`, `Courseget`, `Coursecreate`, `Coursecreateonline`, `Coursedelete`, `Coursedeletecontent`, `Courseloadlecture`, `Coursedeletecurriculum`, `Coursedeleteuploads`, `Courseupdateview`, `Courseupdate`, `Courseeditonlineclass`, `Coursepublishclass`, `Coursepreview`, `Coursecurriculum`, `Courselearn`, `Courseclassstudents`, `Courseupdatecontent`, `Coursesections`, `Dailyupdatesget`, `Dailyupdatesfuelexpenses`, `Dailyupdatesdeletefuelexpenses`, `Dailyupdatesotherexpenses`, `Dailyupdatesdeleteotherexpenses`, `Dailyupdatesservicerecords`, `Dailyupdatesdeleteservicerecords`, `Dailyupdatesupdateservicerecord`, `Dailyupdatesdropout`, `Dailyupdatesdeletedropout`, `Dailyupdatesupdateexpenses`, `Dashboardget`, `Dashboardtotals`, `Dashboardprevious`, `Dashboardcurrent`, `Dashboardgrowth`, `Dashboardstudents`, `Dashboardexpenses`, `Dashboardinvoices`, `Dashboardnotifications`, `Dashboardcourses`, `Examcreate`, `Examupdate`, `Examdelete`, `Exampublish`, `Exambuilder`, `Examtakeexam`, `Examsave`, `Examupdatequestions`, `Examexamstudents`, `Examsections`, `Examget`, `Examdeletecontent`, `Examloadlecture`, `Examdeleteuploads`, `Examupdateview`, `Exampreview`, `Examcurriculum`, `Exam@learn`, `Examclassstudents`, `Fleetget`, `Fleetadd`, `Fleetdelete`, `Fleetupdateview`, `Fleetupdate`, `Fleetdashboardget`, `Fleetdashboardtotals`, `Fleetdashboardprevious`, `Fleetdashboardcurrent`, `Fleetdashboardgrowth`, `Fleetdashboardstudents`, `Fleetdashboardexpenses`, `Fleetdashboardinvoices`, `Fleetdashboardnotifications`, `Fleetdashboardcourses`, `Getchating@get`, `Getclassget`, `Getclassget3`, `Getcommunicationget`, `Getfleetrecordget`, `Getfleetrecordupdate`, `Getfleetrecorddeletemaintainancerecord`, `Instructorget`, `Instructorcreate`, `Invoiceget`, `Invoicedeletepayment`, `Invoiceviewpayments`, `Invoiceupdate`, `Invoiceupdateview`, `Invoicedelete`, `Invoicedownload`, `Invoicepreview`, `Invoiceshare`, `Issuesget`, `Issuesreportissue`, `Issuesprocessing`, `Issuesupdatecomment`, `Issuesupdatebrief`, `Issuesresolved`, `Issuesremove`, `Licenseget`, `Licensenew`, `Licenserenew`, `Licenseupdate`, `Licensedelete`, `Markedget`, `Markedreset`, `Markedmarkpresent`, `Monthlyget`, `Monthlytotals`, `Monthlyprevious`, `Monthlycurrent`, `Monthlygrowth`, `Monthlystudents`, `Monthlyexpenses`, `Monthlyinvoices`, `Monthlynotifications`, `Monthlycourses`, `newfleetrecordget`, `newfleetrecordaddnew`, `newfleetrecorddelete`, `newfleetrecordupdateview`, `newfleetrecordupdate`, `Newlicenseget`, `Newlicenseenroll`, `Newlicenseenrolled`, `Newlicensestarted`, `Newlicensepayment`, `Newlicenseprocessing`, `Newlicenselearning`, `Newlicensepermanent`, `Newlicensecompleted`, `Newlicenseupdatecomment`, `Newlicensecancaelled`, `Notificationget`, `Notificationread`, `Notificationcount`, `Oldrecordsget`, `Ongoingget`, `Ongoingreset`, `Ongoingabsent`, `Payslipget`, `Payslipdownload`, `Payslipsharepayslip`, `Payslippayslipdownload`, `Payslippreview`, `PayslipnumberTowords`, `Practicallessonsget`, `Practicallessonscreate`, `Practicallessonsupdate`, `Practicallessonsactive`, `Practicallessonsinactive`, `Practicallessonsdelete`, `Practicallessonsaddcourse`, `Profileget`, `Profileupdate`, `Profileaddaccountdetails`, `Profileupdateaccount`, `Profilesetongoing`, `Profilesetwaiting`, `Profilesetcancelled`, `Profilesetcompleted`, `Profilesetdefaulter`, `Profileresetdefaulter`, `Profiledelete`, `Profilesendemail`, `Profilesendsms`, `Profileaddnote`, `Profiledeletenote`, `Profilereadnote`, `Profileupdatenoteview`, `Profileupdatenote`, `Profileuploadattachment`, `Profiledeleteattachment`, `Profiledisconnectgoogle`, `Profilerequestreview`, `Profileaddadvance`, `Profiledeleteadvance`, `Profileaddincentive`, `Profiledeleteincentive`, `Profileactivateaccount`, `Profiledactivateaccount`, `Profilegeneratepayslip`, `Profiledeletepayslip`, `Profileupdatepayslip`, `Profileaddattendance`, `Profileupdateattendance`, `Profiledeleteattendance`, `Recordsget`, `Rescheduleget`, `ReschedulevalidateDate`, `Rescheduleclasses`, `Rescheduleliststudents`, `Rescheduleupdatetrainer`, `Scheduleget`, `Schedulecreate`, `SchedulelandaDate`, `Schedulefetch`, `Scheduledelete`, `Scheduleupdateview`, `Scheduleupdate`, `Schedulesmsnotification`, `SchedulecalendarSync`, `ScheduleNotificationget`, `Schoolget`, `Schoolcreate`, `Schooldelete`, `Schoolupdateview`, `Schoolupdate`, `Schoolsendemail`, `Schoolsendsms`, `Settingsget`, `SettingsgetCurrencySymbol`, `Settingsupdateprofile`, `Settingsupdatcompany`, `Settingsupdatereminders`, `Settingsupdatepassword`, `Settingsupdatesystem`, `Staffget`, `Staffcreate`, `Staffsummaryget`, `Studentget`, `Studentcreate`, `Studentaddcourse`, `Studentenroll`, `Studentdeleteenroll`, `Studentcreateinvoice`, `Todayget`, `Todaygetdetails`, `Todaystart`, `Todayabsent`, `Todaynotify`, `Todayrequestpayment`, `Updateget`, `Updatescan`, `Updateversions`, `Updateupdate`, `Updatesget`, `Updatesfuelexpenses`, `Updatesotherexpenses`, `Updatesdropout`, `Updatesupdatecompany`, `Updatesupdatereminders`, `Updatesupdatepassword`, `Updatesupdatesystem`, `Updatestudentaadharget`, `Updatestudentaadharupdate`, `Updatestudentprofileget`, `Updatestudentprofileupdate`, `waitinglistget`, `waitinglistcreate`, `waitinglistaddcourse`, `waitinglistenroll`, `waitinglistdeleteenrollment`, `waitinglistcreateinvoice`, `Welcomeget`, `Welcomeiattend`) VALUES
(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(16) NOT NULL,
  `lname` varchar(16) NOT NULL,
  `fathername` text DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `phone` varchar(16) DEFAULT NULL,
  `alternatephone` varchar(16) DEFAULT NULL,
  `learning` text DEFAULT NULL,
  `alearning` text DEFAULT NULL,
  `driving` text DEFAULT NULL,
  `adriving` text DEFAULT NULL,
  `aadhar` varchar(256) DEFAULT NULL,
  `aadharfront` varchar(256) DEFAULT NULL,
  `aadharback` varchar(256) DEFAULT NULL,
  `address` varchar(256) DEFAULT NULL,
  `drivinglicense` int(11) DEFAULT NULL,
  `car` int(11) DEFAULT NULL,
  `location` text DEFAULT NULL,
  `password` varchar(256) NOT NULL,
  `defaulter` int(11) NOT NULL DEFAULT 1,
  `avatar` varchar(256) DEFAULT NULL,
  `token` varchar(256) DEFAULT NULL,
  `school` int(11) DEFAULT NULL,
  `branch` int(11) DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `role` enum('admin','staff','superadmin','instructor','student') NOT NULL,
  `position` varchar(40) DEFAULT NULL,
  `permissions` varchar(100) DEFAULT NULL,
  `status` enum('Active','Suspended','Inactive') NOT NULL DEFAULT 'Active',
  `lastnotification` datetime DEFAULT NULL,
  `lang` varchar(32) NOT NULL DEFAULT 'en_US',
  `google_access_token` varchar(600) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `isWaiting` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `fathername`, `email`, `gender`, `date_of_birth`, `phone`, `alternatephone`, `learning`, `alearning`, `driving`, `adriving`, `aadhar`, `aadharfront`, `aadharback`, `address`, `drivinglicense`, `car`, `location`, `password`, `defaulter`, `avatar`, `token`, `school`, `branch`, `course`, `role`, `position`, `permissions`, `status`, `lastnotification`, `lang`, `google_access_token`, `created_at`, `isWaiting`) VALUES
(1, 'Sagar', 'Sharma', NULL, 'sagar.offsec@gmail.com', 'Male', '1999-08-06', '+91-7419999195', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Kuber Vatika, Near Rothak railway Flyover Sonipat', NULL, NULL, NULL, '4b77d2bd1a52aaaaf118084aa8bd4e3d6128d98a35a89acb48bd416918efbb6d', 1, 'mLhOtrVIeHhMRxa73eNnoPWpCjV5wsrS.png', '0BX6iQXdnwXEgKKMKCFLMZoSpwFvnTHQ', 1, 1, NULL, 'superadmin', NULL, '', 'Active', '2023-11-15 06:14:16', 'en_US', NULL, '2019-01-26 06:04:26', 0),
(5, 'Hemanth', 'Verma', NULL, 'vl43ck+3@gmail.com', 'Male', '1970-01-01', '+917419999195', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '4b77d2bd1a52aaaaf118084aa8bd4e3d6128d98a35a89acb48bd416918efbb6d', 1, NULL, NULL, 1, 1, NULL, 'instructor', NULL, 'read_write', 'Active', '2022-08-30 14:55:11', 'en_US', NULL, '2022-07-21 07:03:19', 0),
(6, 'Lalit', 'Soni', NULL, 'vl43ck+4@gmail.com', 'Male', '1970-01-01', '+917419999195', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '4b77d2bd1a52aaaaf118084aa8bd4e3d6128d98a35a89acb48bd416918efbb6d', 1, NULL, NULL, 1, 1, NULL, 'instructor', NULL, 'read_write', 'Active', NULL, 'en_US', NULL, '2022-07-21 07:02:32', 0),
(7, 'Manoj', 'Kaushik', NULL, 'vl43ck+2@gmail.com', 'Male', '1971-01-01', '+917419999195', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test2', NULL, NULL, NULL, '4b77d2bd1a52aaaaf118084aa8bd4e3d6128d98a35a89acb48bd416918efbb6d', 1, NULL, NULL, 1, 1, NULL, 'instructor', NULL, 'read_write', 'Active', NULL, 'en_US', NULL, '2022-07-21 07:07:24', 0),
(11, 'Sahil', 'Vashisth', NULL, 'vl43ck@gmail.com', 'Male', '1970-01-01', '+917419999195', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '4b77d2bd1a52aaaaf118084aa8bd4e3d6128d98a35a89acb48bd416918efbb6d', 1, NULL, NULL, 1, 1, NULL, 'instructor', 'multi', 'read_write', 'Active', NULL, 'en_US', NULL, '2022-07-21 07:08:13', 0),
(21, 'Sagar', 'Sharma', NULL, 'sagarvashisth6899@gmail.com', 'Male', '1999-08-06', '7419999195', '', NULL, NULL, NULL, NULL, '123456789011', 'JTQh62oeoq28rMscOJUWeZImHaS1Gubw.png', 'm31gioehC9ffgizYtLRDtZVfLTc2CehL.png', 'tester', NULL, NULL, 'https://goo.gl/maps/oWzzECUeDWv18pB56', '4b77d2bd1a52aaaaf118084aa8bd4e3d6128d98a35a89acb48bd416918efbb6d', 0, 'FjhGvOE8iMFnWz92d066YyqADCv4oV1L.png', NULL, 1, 1, NULL, 'student', NULL, '', 'Active', NULL, 'en_US', NULL, '2022-07-17 09:05:21', 0),
(22, 'Sahil', 'Vashisth', NULL, 'tester@em2ail.com', 'Male', NULL, '+917419999195', NULL, NULL, NULL, NULL, NULL, '123456789012', 'vQF77wHvll8gVKW2wvOCZfsiPICR0oKX.png', '9UkkkffUGV6C6YKokt42nI5r1Ud3JlqF.png', NULL, NULL, NULL, 'https://goo.gl/maps/oWzzECUeDWv18pB56', '639913c036b337fcd3e316db3f3d5398b565fd629e1e40876fe9717ec313d5a5', 0, 'fxZDSPcqvCZPUELpthraNyyAfxvmCgNV.png', NULL, 1, 1, NULL, 'student', NULL, '', 'Active', NULL, 'en_US', NULL, '2022-07-18 10:20:56', 0),
(23, 'Pratham', 'Sharma', NULL, 'manager@realcardriving.com', 'Male', NULL, '+917419999195', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4b77d2bd1a52aaaaf118084aa8bd4e3d6128d98a35a89acb48bd416918efbb6d', 1, NULL, NULL, 1, 1, NULL, 'staff', 'manager', 'read_write_delete', 'Active', '2022-10-12 23:30:30', 'en_US', NULL, '2022-07-18 11:30:41', 0),
(24, 'Sagar2ew', 'Sag', NULL, 'sagar@testewmail.com', 'Male', NULL, '+917419999195', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'https://goo.gl/maps/oWzzECUeDWv18pB56', '3c892e971f2adfca0fe71b1eb5878dcee66594a25f19c4ad0a211e40f43d46a3', 1, NULL, 'e2rz1LPcBLtvEM61KC1Y2TSU9SGxTN6r', 1, 1, NULL, 'student', NULL, '', 'Active', NULL, 'en_US', NULL, '2022-07-18 11:36:22', 2),
(25, 'Sagar2', 'Sag', NULL, 'queeen@example.com', 'Male', NULL, '+917419999195', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'https://goo.gl/maps/oWzzECUeDWv18pB56', '4b77d2bd1a52aaaaf118084aa8bd4e3d6128d98a35a89acb48bd416918efbb6d', 1, NULL, NULL, 1, 1, NULL, 'student', NULL, '', 'Active', '2022-07-27 16:46:20', 'en_US', NULL, '2022-07-20 11:14:17', 1),
(30, 'Pratham', 'Sharma', 'tester2', 'vl43ck+6@gmail.com', 'Male', '2000-02-01', '+917419999195', '', '1234567890121', 'TY5eqtvdTbQi2vs9o7nECb1idJrHrOGE.png', '', 'Ijv7Cfapn1C01YaA63IxqdgHK8pswJXm.png', '123456789012', 'Rhqfp0GEAKKxlPej9w81oIslDbDpRV9e.png', 'dD2XhxdsznQ4kNnebZqDDeMXfuZJY4kO.png', 'tester', 1, 1, '', '4b77d2bd1a52aaaaf118084aa8bd4e3d6128d98a35a89acb48bd416918efbb6d', 1, 'XZdrCmvY4odUoursu4vWs2RBAyAbvIy1.jpg', NULL, 1, 1, NULL, 'student', '', '', 'Active', '2022-07-21 12:10:57', 'en_US', NULL, '2022-07-21 08:09:22', 3),
(32, 'suni', 'master', NULL, 'tester@gmail.com', 'Male', NULL, '7419999195', '', NULL, NULL, NULL, NULL, '123456789012', 'bQk7N7irjJbdxiXsnUUGwU68zp6E0Mzk.png', 'COP5liGnKytLs8krHu10pSQDq6Kdabix.png', 'tetser', NULL, NULL, 'tester', '7427a82355496fb860ea8705903a345527f539b81cc5459ca4f98ff24b38d462', 0, 'VJllJWTFWqbusAAEfEfccJSsfqakO0cG.png', 'XZ4bdx9HaFM0YYt7b2A5Ya0xP14VIyDv', 1, 1, NULL, 'student', NULL, '', 'Active', NULL, 'en_US', NULL, '2022-08-24 12:26:34', 0),
(33, 'tester', 'tester', NULL, 'tester123', 'Male', '1970-01-01', '9034179580', '', NULL, NULL, NULL, NULL, '123456789012', 'eSuMRARl50ONsISgiV25k2uLWgjWKbMR.png', 'vdt77Tf80vmFhWBYH23Ay66BcOD71etN.png', 'teter', 1, 1, '', 'e1a2e53e96a5ad150567e251c6cc80d5de426a521840cf2a25f636c379e2efb0', 0, 'O36gybdqlZ4ikVlULxz9jLa62z8W0Cuy.png', NULL, 1, 1, NULL, 'student', NULL, '', 'Active', NULL, 'en_US', NULL, '2022-10-01 12:36:25', 0),
(34, 'Sagar', '2', NULL, 'tester213', 'Male', NULL, '21312312', '3123123', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'tester', NULL, NULL, 'tester', '98fe0af18db07bcd6e963fd830a4cf9179311f765131cb9fe03a1881fd0d0455', 1, NULL, NULL, 1, 1, NULL, 'student', NULL, '', 'Active', NULL, 'en_US', NULL, '2022-10-03 11:59:55', 0),
(35, 'Dev', '1', NULL, 'staff1@realcardriving.com', 'Male', NULL, '7419999195', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '4b77d2bd1a52aaaaf118084aa8bd4e3d6128d98a35a89acb48bd416918efbb6d', 1, NULL, NULL, 1, 1, NULL, 'staff', NULL, 'read_write', 'Active', NULL, 'en_US', NULL, '2022-10-14 19:34:44', 0),
(36, 'test123', 'hello', '', 'iuadgah', 'Male', '1970-01-01', '7419999195', '', 'HR10/0006524/2023', 'A49Svt0FxtdK9vD2T7Ua2ZxGq1gKH8sE.png', '', NULL, '123456789013', 'uncPwH1VjO5MlCoDN7otkjJ0AIhy4WyS.png', 'gCKODvg9xZPy71lNqKoIXFKZCA7OJ5h0.png', 'tester', 1, 3, '', '6c5ccb9a0dce8611effe073d03b966ec4821c26bb44e8778bf03441a9eccc8a6', 0, 'cIpzuCH9I9lONHqZNO3SMXUA4jfpIIsP.png', NULL, 1, 1, NULL, 'student', NULL, '', 'Active', NULL, 'en_US', NULL, '2023-05-24 18:00:36', 0),
(37, 'Grijesh', 'Pandey', NULL, 'amanager@realcardriving.com', 'Male', '1970-01-01', '+917419999195', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '4b77d2bd1a52aaaaf118084aa8bd4e3d6128d98a35a89acb48bd416918efbb6d', 1, NULL, NULL, 1, 1, NULL, 'staff', 'amanager', 'read_write_delete', 'Active', '2023-05-27 21:20:29', 'en_US', NULL, '2022-07-18 11:30:41', 0);

-- --------------------------------------------------------

--
-- Table structure for table `whatsappservermail`
--

CREATE TABLE `whatsappservermail` (
  `id` int(11) NOT NULL,
  `lastupdate` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `whatsappservermail`
--

INSERT INTO `whatsappservermail` (`id`, `lastupdate`) VALUES
(1, '2023-08-05 10:44:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accountdetails`
--
ALTER TABLE `accountdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `advance`
--
ALTER TABLE `advance`
  ADD PRIMARY KEY (`sr`);

--
-- Indexes for table `attachments`
--
ALTER TABLE `attachments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uploadedby` (`uploaded_by`),
  ADD KEY `attachment_for` (`attachment_for`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`sr`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `schoolid` (`school`);

--
-- Indexes for table `branchmessages`
--
ALTER TABLE `branchmessages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `receiver` (`receiver`),
  ADD KEY `school` (`school`),
  ADD KEY `branch` (`branch`);

--
-- Indexes for table `classescompleted`
--
ALTER TABLE `classescompleted`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classremainder`
--
ALTER TABLE `classremainder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courseinstructor`
--
ALTER TABLE `courseinstructor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `instructor` (`instructor`),
  ADD KEY `course` (`course`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `school` (`school`),
  ADD KEY `branch` (`branch`);

--
-- Indexes for table `coursesenrolled`
--
ALTER TABLE `coursesenrolled`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student` (`student`),
  ADD KEY `school` (`school`),
  ADD KEY `branch` (`branch`),
  ADD KEY `course` (`course`);

--
-- Indexes for table `currencies`
--
ALTER TABLE `currencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dropreading`
--
ALTER TABLE `dropreading`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branch` (`branch`),
  ADD KEY `school` (`school`),
  ADD KEY `course` (`course`);

--
-- Indexes for table `examsreports`
--
ALTER TABLE `examsreports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `class` (`exam`),
  ADD KEY `course` (`course`),
  ADD KEY `school` (`school`),
  ADD KEY `branch` (`branch`),
  ADD KEY `student` (`student`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fleet`
--
ALTER TABLE `fleet`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branch` (`branch`),
  ADD KEY `school` (`school`);

--
-- Indexes for table `fleetchecks`
--
ALTER TABLE `fleetchecks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fleetmaintainancerecords`
--
ALTER TABLE `fleetmaintainancerecords`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fuel`
--
ALTER TABLE `fuel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `incentive`
--
ALTER TABLE `incentive`
  ADD PRIMARY KEY (`sr`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branch` (`branch`),
  ADD KEY `school` (`school`),
  ADD KEY `student` (`student`);

--
-- Indexes for table `lectureprogress`
--
ALTER TABLE `lectureprogress`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chapter` (`chapter`),
  ADD KEY `class` (`class`),
  ADD KEY `school` (`school`),
  ADD KEY `branch` (`branch`),
  ADD KEY `course` (`course`),
  ADD KEY `lecture` (`lecture`),
  ADD KEY `student` (`student`);

--
-- Indexes for table `lectures`
--
ALTER TABLE `lectures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chapter` (`chapter`),
  ADD KEY `class` (`class`),
  ADD KEY `school` (`school`),
  ADD KEY `branch` (`branch`),
  ADD KEY `course` (`course`);

--
-- Indexes for table `license`
--
ALTER TABLE `license`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newdrivinglicense`
--
ALTER TABLE `newdrivinglicense`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `postby` (`note_by`),
  ADD KEY `note_for` (`note_for`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `school` (`school`),
  ADD KEY `branch` (`branch`),
  ADD KEY `user` (`user`);

--
-- Indexes for table `onlineclasschapters`
--
ALTER TABLE `onlineclasschapters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `class` (`class`),
  ADD KEY `course` (`course`),
  ADD KEY `school` (`school`),
  ADD KEY `branch` (`branch`);

--
-- Indexes for table `onlineclasses`
--
ALTER TABLE `onlineclasses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branch` (`branch`),
  ADD KEY `school` (`school`),
  ADD KEY `course` (`course`);

--
-- Indexes for table `paymentlinks`
--
ALTER TABLE `paymentlinks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice` (`invoice`),
  ADD KEY `branch` (`branch`),
  ADD KEY `school` (`school`),
  ADD KEY `payments_ibfk_4` (`student`);

--
-- Indexes for table `payslips`
--
ALTER TABLE `payslips`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `practicallessons`
--
ALTER TABLE `practicallessons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `class` (`exam`),
  ADD KEY `course` (`course`),
  ADD KEY `school` (`school`),
  ADD KEY `branch` (`branch`);

--
-- Indexes for table `reminders`
--
ALTER TABLE `reminders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company` (`school`);

--
-- Indexes for table `reportedissues`
--
ALTER TABLE `reportedissues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scertificates`
--
ALTER TABLE `scertificates`
  ADD PRIMARY KEY (`sr`),
  ADD UNIQUE KEY `sr` (`sr`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branch` (`branch`),
  ADD KEY `instructor` (`instructor`),
  ADD KEY `school` (`school`),
  ADD KEY `course` (`course`),
  ADD KEY `student` (`student`),
  ADD KEY `car` (`car`);

--
-- Indexes for table `schoolmessages`
--
ALTER TABLE `schoolmessages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `receiver` (`receiver`),
  ADD KEY `school` (`school`),
  ADD KEY `branch` (`branch`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `servicerecords`
--
ALTER TABLE `servicerecords`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staffattendance`
--
ALTER TABLE `staffattendance`
  ADD PRIMARY KEY (`sr`);

--
-- Indexes for table `studentexamresults`
--
ALTER TABLE `studentexamresults`
  ADD PRIMARY KEY (`id`),
  ADD KEY `class` (`exam`),
  ADD KEY `course` (`course`),
  ADD KEY `school` (`school`),
  ADD KEY `branch` (`branch`),
  ADD KEY `student` (`student`);

--
-- Indexes for table `timeline`
--
ALTER TABLE `timeline`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user` (`user`);

--
-- Indexes for table `timezones`
--
ALTER TABLE `timezones`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usermessages`
--
ALTER TABLE `usermessages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `receiver` (`receiver`),
  ADD KEY `school` (`school`),
  ADD KEY `branch` (`branch`);

--
-- Indexes for table `userpermission`
--
ALTER TABLE `userpermission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `company` (`school`),
  ADD KEY `branch` (`branch`);

--
-- Indexes for table `whatsappservermail`
--
ALTER TABLE `whatsappservermail`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advance`
--
ALTER TABLE `advance`
  MODIFY `sr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `attachments`
--
ALTER TABLE `attachments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `sr` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `branchmessages`
--
ALTER TABLE `branchmessages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `classescompleted`
--
ALTER TABLE `classescompleted`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `classremainder`
--
ALTER TABLE `classremainder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=247;

--
-- AUTO_INCREMENT for table `courseinstructor`
--
ALTER TABLE `courseinstructor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `coursesenrolled`
--
ALTER TABLE `coursesenrolled`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `currencies`
--
ALTER TABLE `currencies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;

--
-- AUTO_INCREMENT for table `dropreading`
--
ALTER TABLE `dropreading`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `examsreports`
--
ALTER TABLE `examsreports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `fleet`
--
ALTER TABLE `fleet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fleetchecks`
--
ALTER TABLE `fleetchecks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `fleetmaintainancerecords`
--
ALTER TABLE `fleetmaintainancerecords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `fuel`
--
ALTER TABLE `fuel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `incentive`
--
ALTER TABLE `incentive`
  MODIFY `sr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `lectureprogress`
--
ALTER TABLE `lectureprogress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `lectures`
--
ALTER TABLE `lectures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `license`
--
ALTER TABLE `license`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `newdrivinglicense`
--
ALTER TABLE `newdrivinglicense`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=196;

--
-- AUTO_INCREMENT for table `onlineclasschapters`
--
ALTER TABLE `onlineclasschapters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `onlineclasses`
--
ALTER TABLE `onlineclasses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `paymentlinks`
--
ALTER TABLE `paymentlinks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `payslips`
--
ALTER TABLE `payslips`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `practicallessons`
--
ALTER TABLE `practicallessons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `reminders`
--
ALTER TABLE `reminders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `reportedissues`
--
ALTER TABLE `reportedissues`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scertificates`
--
ALTER TABLE `scertificates`
  MODIFY `sr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `schoolmessages`
--
ALTER TABLE `schoolmessages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `servicerecords`
--
ALTER TABLE `servicerecords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `staffattendance`
--
ALTER TABLE `staffattendance`
  MODIFY `sr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `studentexamresults`
--
ALTER TABLE `studentexamresults`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `timeline`
--
ALTER TABLE `timeline`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `timezones`
--
ALTER TABLE `timezones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=424;

--
-- AUTO_INCREMENT for table `usermessages`
--
ALTER TABLE `usermessages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `whatsappservermail`
--
ALTER TABLE `whatsappservermail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attachments`
--
ALTER TABLE `attachments`
  ADD CONSTRAINT `attachments_ibfk_1` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `attachments_ibfk_2` FOREIGN KEY (`attachment_for`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `branches`
--
ALTER TABLE `branches`
  ADD CONSTRAINT `branches_ibfk_1` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `branchmessages`
--
ALTER TABLE `branchmessages`
  ADD CONSTRAINT `branchmessages_ibfk_1` FOREIGN KEY (`receiver`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `branchmessages_ibfk_2` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `branchmessages_ibfk_3` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `courseinstructor`
--
ALTER TABLE `courseinstructor`
  ADD CONSTRAINT `courseinstructor_ibfk_1` FOREIGN KEY (`course`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `courseinstructor_ibfk_2` FOREIGN KEY (`instructor`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `courses_ibfk_2` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `coursesenrolled`
--
ALTER TABLE `coursesenrolled`
  ADD CONSTRAINT `coursesenrolled_ibfk_1` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `coursesenrolled_ibfk_2` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `coursesenrolled_ibfk_3` FOREIGN KEY (`course`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `student` FOREIGN KEY (`student`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `exams`
--
ALTER TABLE `exams`
  ADD CONSTRAINT `exams_ibfk_1` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `exams_ibfk_2` FOREIGN KEY (`course`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `exams_ibfk_3` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `examsreports`
--
ALTER TABLE `examsreports`
  ADD CONSTRAINT `examsreports_ibfk_1` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `examsreports_ibfk_2` FOREIGN KEY (`course`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `examsreports_ibfk_3` FOREIGN KEY (`exam`) REFERENCES `exams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `examsreports_ibfk_4` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `examsreports_ibfk_5` FOREIGN KEY (`student`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `fleet`
--
ALTER TABLE `fleet`
  ADD CONSTRAINT `fleet_ibfk_1` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fleet_ibfk_2` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `invoices_ibfk_2` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `invoices_ibfk_3` FOREIGN KEY (`student`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lectureprogress`
--
ALTER TABLE `lectureprogress`
  ADD CONSTRAINT `lectureprogress_ibfk_1` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lectureprogress_ibfk_2` FOREIGN KEY (`chapter`) REFERENCES `onlineclasschapters` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lectureprogress_ibfk_3` FOREIGN KEY (`class`) REFERENCES `onlineclasses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lectureprogress_ibfk_4` FOREIGN KEY (`lecture`) REFERENCES `lectures` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lectureprogress_ibfk_5` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lectureprogress_ibfk_6` FOREIGN KEY (`student`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lectureprogress_ibfk_7` FOREIGN KEY (`course`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lectures`
--
ALTER TABLE `lectures`
  ADD CONSTRAINT `lectures_ibfk_1` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lectures_ibfk_2` FOREIGN KEY (`chapter`) REFERENCES `onlineclasschapters` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lectures_ibfk_3` FOREIGN KEY (`class`) REFERENCES `onlineclasses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lectures_ibfk_4` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lectures_ibfk_5` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lectures_ibfk_6` FOREIGN KEY (`course`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notes`
--
ALTER TABLE `notes`
  ADD CONSTRAINT `notes_ibfk_1` FOREIGN KEY (`note_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `notes_ibfk_2` FOREIGN KEY (`note_for`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_3` FOREIGN KEY (`user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `onlineclasschapters`
--
ALTER TABLE `onlineclasschapters`
  ADD CONSTRAINT `onlineclasschapters_ibfk_1` FOREIGN KEY (`class`) REFERENCES `onlineclasses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `onlineclasschapters_ibfk_2` FOREIGN KEY (`course`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `onlineclasschapters_ibfk_3` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `onlineclasschapters_ibfk_4` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `onlineclasses`
--
ALTER TABLE `onlineclasses`
  ADD CONSTRAINT `onlineclasses_ibfk_1` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `onlineclasses_ibfk_2` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `onlineclasses_ibfk_3` FOREIGN KEY (`course`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`invoice`) REFERENCES `invoices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `payments_ibfk_4` FOREIGN KEY (`student`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `questions_ibfk_2` FOREIGN KEY (`course`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `questions_ibfk_3` FOREIGN KEY (`exam`) REFERENCES `exams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `questions_ibfk_4` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reminders`
--
ALTER TABLE `reminders`
  ADD CONSTRAINT `reminders_ibfk_1` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `schedules_ibfk_2` FOREIGN KEY (`instructor`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `schedules_ibfk_3` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `schedules_ibfk_4` FOREIGN KEY (`course`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `schedules_ibfk_5` FOREIGN KEY (`student`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `schedules_ibfk_6` FOREIGN KEY (`car`) REFERENCES `fleet` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Constraints for table `schoolmessages`
--
ALTER TABLE `schoolmessages`
  ADD CONSTRAINT `schoolmessages_ibfk_1` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `schoolmessages_ibfk_2` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `schoolmessages_ibfk_3` FOREIGN KEY (`receiver`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `studentexamresults`
--
ALTER TABLE `studentexamresults`
  ADD CONSTRAINT `studentexamresults_ibfk_1` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `studentexamresults_ibfk_2` FOREIGN KEY (`course`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `studentexamresults_ibfk_3` FOREIGN KEY (`exam`) REFERENCES `exams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `studentexamresults_ibfk_4` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `studentexamresults_ibfk_5` FOREIGN KEY (`student`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `timeline`
--
ALTER TABLE `timeline`
  ADD CONSTRAINT `timeline_ibfk_1` FOREIGN KEY (`user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `usermessages`
--
ALTER TABLE `usermessages`
  ADD CONSTRAINT `usermessages_ibfk_1` FOREIGN KEY (`receiver`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `usermessages_ibfk_2` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `usermessages_ibfk_3` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`branch`) REFERENCES `branches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`school`) REFERENCES `schools` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
