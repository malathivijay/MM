<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\Database;
use Simcify\File;
use Simcify\Sms;
use Simcify\Mail;
use Simcify\FS;

class License{

    /**
     * Get students view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user = Auth::user();
        if ($user->role != 'superadmin') {
            return view('errors/404');
        }
        
        $license = Database::table('license')->where(array('status' => 1))->get();

        foreach ($license as $licenses) {
            $udpate = Database::table('users')->where('id', $licenses->updateby)->first();
            $licenses->updatedby = $udpate->fname." ".$udpate->lname;

            $data = str_replace(array('-','_'),array('+','/'),$licenses->comment);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $licenses->comment = base64_decode($data);

            $data = str_replace(array('-','_'),array('+','/'),$licenses->number);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $licenses->number = base64_decode($data);

        }

        return view('license', compact("user", "license"));
    }
  
    
    /**
     * Add New License
     * 
     * @return Json
     */
    public function new() {
        $user = Auth::user();
        if ($user->role != 'superadmin') {
            return view('errors/404');
        }

        $target_file = basename($_FILES["attachment"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        // Check if image file is a actual image or fake image
            if(isset($_REQUEST["attachment"])) {
                $check = getimagesize($_FILES["attachment"]["tmp_name"]);
                if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
                } else {
                echo "File is not an image.";
                $uploadOk = 0;
                }
            }
            
            // Check file size
            if ($_FILES["attachment"]["size"] > 5000000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }
            
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "pdf" &&$imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }
            
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                return response()->json(responder("error", "HMM!", "Something went wrong. Someting Wrong with the file. Please check described deatils for file.","reload()"));
            }

        //validating inputs

        $data = array(
            "updateby" => $user->id,
            "branch" => $user->branch,
            "school" => $user->school
        );

        $upload = File::upload(
            $_FILES['attachment'], 
            "attachments"
            ,array(
                "source" => "form"
                 )
        );

        if($upload['status'] == 'success'){
            $data ['file']= $upload['info']['name'];
        }

        foreach (input()->post as $field) {
            if ($field->index == "name") {
                
                $data['name']= escape($field->value);
                
                continue;
            }
            if ($field->index == "csrf-token") {
                continue;
            }
            if ($field->index == "number") {
                if($field->value!=""){
                    $number = base64_encode($field->value);
                    $number = str_replace(array('+','/','='),array('-','_',''),$number);
                    $data['number']= $number;
            }
                continue;
            }
            if ($field->index == "type") {
                
                $data['type']= escape($field->value);
                
                continue;
            }
            if ($field->index == "sdate") {
                
                $data['start']= escape($field->value);
                
                continue;
            }
            if ($field->index == "edate") {
                
                $data['end']= escape($field->value);
                
                continue;
            }
            if ($field->index == "alertdays") {
                
                $data['alertdays']= escape($field->value);
                
                continue;
            }
            if ($field->index == "comment") {
                if($field->value!=""){
                    $comment = base64_encode($field->value);
                    $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
                    $data['comment']= $comment;
            }
                continue;
            }
        }

        Database::table('license')->insert($data);

        $status = Database::table('license')->where('file', $data['file'])->first();

        if(!empty($status)){        
            return response()->json(responder("success", "Record Added!", "New License Record Successfully Added.", "reload()"));
        }else{
            return response()->json(responder("error", "HMM!", "Something went wrong. Not able to Save Details","reload()"));
        }
        
    }

    /**
     * Renew License
     * 
     * @return Json
     */
    public function renew() {
        $user = Auth::user();
        if ($user->role != 'superadmin') {
            return view('errors/404');
        }

        $target_file = basename($_FILES["attachment"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        // Check if image file is a actual image or fake image
            if(isset($_REQUEST["attachment"])) {
                $check = getimagesize($_FILES["attachment"]["tmp_name"]);
                if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
                } else {
                echo "File is not an image.";
                $uploadOk = 0;
                }
            }
            
            // Check file size
            if ($_FILES["attachment"]["size"] > 5000000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }
            
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "pdf" &&$imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }
            
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                return response()->json(responder("error", "HMM!", "Something went wrong. Someting Wrong with the file. Please check described deatils for file.","reload()"));
            }

        //validating inputs

        $licenseid = escape(input('licenseid'));
        $name = escape(input('name'));
        $type = escape(input('type'));
        $alertdays = escape(input('alertdays'));
        $getoldrecord = Database::table('license')->where('id', $licenseid)->first();

        if ($getoldrecord->id=="") {
            return response()->json(responder("error", "HMM!", "Invalid Data Provided.","reload()"));
        }

        $data = array(
            "name" => $getoldrecord->name,
            "type" => $getoldrecord->type,
            "alertdays" => $getoldrecord->alertdays,
            "updateby" => $user->id,
            "branch" => $getoldrecord->branch,
            "school" => $getoldrecord->school
        );

        $upload = File::upload(
            $_FILES['attachment'], 
            "attachments"
            ,array(
                "source" => "form"
                 )
        );

        if($upload['status'] == 'success'){
            $data ['file']= $upload['info']['name'];
        }

        foreach (input()->post as $field) {
            if ($field->index == "csrf-token") {
                continue;
            }
            if ($field->index == "number") {
                if($field->value!=""){
                    $number = base64_encode($field->value);
                    $number = str_replace(array('+','/','='),array('-','_',''),$number);
                    $data['number']= $number;
            }
                continue;
            }
            if ($field->index == "sdate") {
                
                $data['start']= escape($field->value);
                
                continue;
            }
            if ($field->index == "edate") {
                
                $data['end']= escape($field->value);
                
                continue;
            }
            if ($field->index == "comment") {
                if($field->value!=""){
                    $comment = base64_encode($field->value);
                    $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
                    $data['comment']= $comment;
            }
                continue;
            }
        }

        Database::table('license')->insert($data);
        Database::table("license")->where("id", $getoldrecord->id)->update(array("status" => 0));

        $status = Database::table('license')->where('file', $data['file'])->first();

        if(!empty($status)){        
            return response()->json(responder("success", "Record Added!", "New License Record Successfully Added.", "reload()"));
        }else{
            return response()->json(responder("error", "HMM!", "Something went wrong. Not able to Save Details","reload()"));
        }
        
    }
    
    /**
     * Update License
     * 
     * @return Json
     */
    public function update() {
        $user = Auth::user();
        if ($user->role != 'superadmin') {
            return view('errors/404');
        }

        $licenseid = escape(input('licenseid'));
        $oldstatus = Database::table('license')->where('id', $licenseid)->first();

        if(empty($oldstatus)){
            return response()->json(responder("error", "HMM!", "Something went wrong. Invalid License ID.","reload()"));
        }

        //validating inputs

        $data = array(
            "updateby" => $user->id,
            "branch" => $user->branch,
            "school" => $user->school
        );

        foreach (input()->post as $field) {
            if ($field->index == "name") {
                
                $data['name']= escape($field->value);
                
                continue;
            }
            if ($field->index == "csrf-token") {
                continue;
            }
            if ($field->index == "number") {
                if($field->value!=""){
                    $number = base64_encode($field->value);
                    $number = str_replace(array('+','/','='),array('-','_',''),$number);
                    $data['number']= $number;
            }
                continue;
            }
            if ($field->index == "type") {
                
                $data['type']= escape($field->value);
                
                continue;
            }
            if ($field->index == "sdate") {
                
                $data['start']= escape($field->value);
                
                continue;
            }
            if ($field->index == "edate") {
                
                $data['end']= escape($field->value);
                
                continue;
            }
            if ($field->index == "alertdays") {
                
                $data['alertdays']= escape($field->value);
                
                continue;
            }
            if ($field->index == "comment") {
                if($field->value!=""){
                    $comment = base64_encode($field->value);
                    $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
                    $data['comment']= $comment;
            }
                continue;
            }
        }

        
        Database::table('license')->where('id',$licenseid)->update($data);

        $status = Database::table('license')->where('id', $licenseid)->first();

        
        if($oldstatus['lastupdate']!=$status['lastupdate']){        
            return response()->json(responder("success", "Record Updated!", "License Record Successfully Updated.", "reload()"));
        }else{
            return response()->json(responder("error", "HMM!", "Something went wrong. Not able to Update Details.","reload()"));
        }
        
    }

    /**
     * Delete License
     * 
     * @return Json
     */
    public function delete() {
        $user = Auth::user();
        if ($user->role != 'superadmin') {
            return view('errors/404');
        }

        $licenseid = escape(input('licenseid'));
        Database::table('license')->where("id", $licenseid)->delete();

        $result=Database::table('license')->where("id", $licenseid)->first();
        if(empty($result)){        
            return response()->json(responder("success", "Record Deleted!", "License Record Successfully Deleted.", "reload()"));
        }else{
            return response()->json(responder("error", "HMM!", "Something went wrong. Not able to Delete Record.","reload()"));
        }
    }

}
