<?php
namespace Simcify\Controllers;

use Simcify\Database;
use Simcify\Landa;
use Simcify\Auth;
use Simcify\Mail;

class Cancelled{

    /**
     * Get Students view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        if (isset($_GET['search']) OR isset($_GET['gender'])) {
            if (!empty($_GET['gender']) && !empty($_GET['search'])) {
                $students = Database::table('users')->where(array(
                    'role' => 'student',
                    'school' => $user->school,
                    'gender' => escape($_GET['gender']),
                    'isWaiting' => 2
                ))->orWhere("fname", "LIKE", "%" . escape($_GET['search']) . "%")->where(array(
                    'role' => 'student',
                    'branch' => $user->branch,
                    'isWaiting' => 2
                ))->orderBy('id', false)->get();
            } elseif (!empty($_GET['gender'])) {
                $students = Database::table('users')->where(array(
                    'role' => 'student',
                    'school' => $user->school,
                    'gender' => escape($_GET['gender']),
                    'isWaiting' => 2
                ))->orderBy('id', false)->get();
            } elseif (!empty($_GET['search'])) {
                $students = Database::table('users')->where(array(
                    'role' => 'student',
                    'school' => $user->school,
                    'isWaiting' => 2
                ))->where("fname", "LIKE", "%" . escape($_GET['search']) . "%")->orderBy('id', false)->get();
            } else {
                $students = Database::table('staffs')->where(array(
                    'role' => 'student',
                    'school' => $user->school,
                    'isWaiting' => 2
                ))->orderBy('id', false)->get();
            }
        } else {
            $students = Database::table('users')->where(array(
                'role' => 'student',
                'school' => $user->school,
                'isWaiting' => 2
            ))->orderBy('id', false)->get();
        }

        foreach ($students as $student) {
            $student->courses = Database::table('coursesenrolled')->where('student', $student->id)->count("id", "total")[0]->total;
            $student->completed = Database::table('schedules')->where('student', $student->id)->where('status', "Complete")->count("id", "total")[0]->total;
        }
        $courses = Database::table('courses')->where('school',$user->school)->where('status',"Available")->get();
        
        return view('cancelled', compact("user", "students", "courses"));
    }

}
