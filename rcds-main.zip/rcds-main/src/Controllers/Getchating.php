<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\Database;
use Simcify\File;
use Simcify\Sms;
use Simcify\Mail;
use Simcify\FS;

class Getchating{

    /**
     * Get profile view
     * 
     * @return \Pecee\Http\Response
     */
    public function get($userid) {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin') {
            return view('errors/404');
        }
        
        $profile = Database::table('users')->where('branch',$user->branch)->where('school',$user->school)->where('phone','LIKE','%'.$userid.'%')->first();

        if($profile->fname!=""){
        
        $getchat = Sms::getchat("91".$userid);

        return view('getchating', compact("user","profile","getchat"));
        }else{
            return view('errors/404');
        }
    }

}
