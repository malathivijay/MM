<?php
namespace Simcify\Controllers;

use Simcify\Database;
use Simcify\Landa;
use Simcify\Auth;

class Ongoing{

    /**
     * Get Attendance view
     * 
     * @return \Pecee\Http\Response
     */

    public function get() {
      $user = Auth::user();
      if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
        return view('errors/404');
      }
      $date = date("Y-m-d");
      $cdate = date("Y-m-d");
      $ongoing = Database::table('users')->leftJoin('attendance','users.id','attendance.id')->leftJoin('invoices','users.id','invoices.student')->rightJoin('schedules','users.id','schedules.student')->where("users`.`branch", $user->branch)->where("users`.`role","student")->where("users`.`isWaiting",0)->where("attendance`.`date", $date)->where("attendance`.`isstarted", 1)->where("schedules`.`start", "LIKE", "%" . $date . "%")->orderBy('users.id', false)->get("`users.fname`", "`users.lname`", "`users.avatar`", "`users.email`", "`users.address`","`attendance.id`", "`attendance.status`", "`attendance.isstarted`", "`attendance.lastupdate`", "`attendance.date`","`invoices.amount`","`invoices.amountpaid`","`schedules.instructor`","`schedules.id` as scheduleid");

      $isFound = "";
      $instructors = Database::table("users")->get();
      $courses = Database::table("courses")->get();

      return view('ongoing', compact("ongoing","user","invoices","date","cdate","instructors","isFound","courses"));
    }
    
    /**
     * Update Attendance
     * 
     * @return Json
     */
    public function reset() {
      $user = Auth::user();
      $data2 = array(
        "status" => "New"
      );
      $sdate = date("Y-m-d");
      Database::table("schedules")->where("id", input("scheduleid"))->where("student", input('studentid'))->where("school", $user->school)->where("branch", $user->branch)->where("start", "LIKE", "%" . $sdate . "%")->update($data2);

      $getupdate = Database::table("schedules")->where("id", input("scheduleid"))->where("student", input('studentid'))->where("school", $user->school)->where("branch", $user->branch)->where("start", "LIKE", "%" . $sdate . "%")->first();

      if($getupdate->status=="New"){

      $data = array(
        "status" => 0,
        "isstarted" => 0
      );

      Database::table("attendance")->where("id", $getupdate->student)->where('date', $sdate)->update($data);
      $instructor = Database::table("users")->where("id", $getupdate->instructor)->first();
      $manager = Database::table("users")->where("branch", $getupdate->branch)->where("school", $getupdate->school)->where("position", "manager")->first();
      $superadmin = Database::table("users")->where("role", "superadmin")->first();
      $fleet = Database::table("fleet")->where("instructor", $getupdate->instructor)->first();
      $fleetname = substr($fleet->phone,-4);
      $student = Database::table("users")->where("id", $getupdate->student)->first();
      $notification = 'Trainer - '.$instructor->fname.' ('.$fleetname.') has resetted the 
      <strong>'.$student->fname.' attendance at '.date("d-m-Y h:i:s A").'</strong>.';
      Landa::notify($notification, $manager->id, "update", "school");
      Landa::notify($notification, $superadmin->id, "update", "school");
      return response()->json(responder("success", "Attendance Marked", "Student Marked as Present Successfully", "reload()"));
      }
      else{
        return response()->json(responder("error", "Hmm!", "Something went wrong please try again."));
      }
    }

    public function absent() {
      $data = array(
          "status" => 1
      );
      $data2 = array(
        "status" => "Missed"
      );
      $sdate = escape(input('date'));
      $cdate = date("Y-m-d");

      if($sdate<=$cdate){
      Database::table("attendance")->where("id", input("userid"))->where('date', $sdate)->update($data);
      Database::table("schedules")->where("id", input("scheduleid"))->where("start", "LIKE", "%" . $sdate . "%")->update($data2);
      return response()->json(responder("success", "Attendance Marked", "Student Marked as Absent Successfully", "reload()"));
      }
      else{
        return response()->json(responder("error", "Hmm!", "Something went wrong please try again."));
      }
    }

}
