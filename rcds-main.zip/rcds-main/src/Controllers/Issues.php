<?php
namespace Simcify\Controllers;

use Simcify\Database;
use Simcify\Landa;
use Simcify\Auth;
use Simcify\Mail;

class Issues{

    /**
     * Get students view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $error = 1;
        if ($user->role == 'staff') {
            if ($user->position == 'amanager') {
                $error = 0;
            }elseif($user->position = 'manager') {
                $error = 0;
            }
        }

        if($user->role == 'staff' && $errro==1){
            return view('errors/404');
        }
        $date = date("Y-m-d");

        if (!isset($_GET['view'])) {
            $getstatus = "New";
        }elseif (isset($_GET['view']) && $_GET['view'] == "Processing") {
            $getstatus = "Processing";
        }elseif (isset($_GET['view']) && $_GET['view'] == "Resolved") {
            $getstatus = "Resolved";
        }else{
            $getstatus = "New";
        }


        $goings = Database::table('reportedissues')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
        ))->get();

        $New = 0;
        $Processing = 0;
        $Resolved = 0;

        foreach ($goings as $going) {
            if($going->status=="New") {
                $New += 1;
            }elseif($going->status=="Processing") {
                $Processing += 1;
            }elseif($going->status=="Resolved") {
                $Resolved += 1;
            }
        }

        $New = "(".$New.")";
        $Processing = "(".$Processing.")";
        $Resolved = "(".$Resolved.")";

        $students = Database::table('reportedissues')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'status' => $getstatus
        ))->orderBy('createdat', false)->get();
        

        foreach ($students as $student) {

            $studentinfo = Database::table("users")->where("id", $student->student)->first();
            $student->name = $studentinfo->fname." ".$studentinfo->lname;

            $data = str_replace(array('-','_'),array('+','/'),$student->brief);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $str = base64_decode($data);

            $student->brief = wordwrap($str,15,"<br>\n");
            $student->brief2 = $str;

            $data = str_replace(array('-','_'),array('+','/'),$student->timeline);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $student->timeline = base64_decode($data);

            $gettimeline = explode(";", $student->timeline);
            $student->timeline = "";
            for($i=0;$i<count($gettimeline)-1;$i++) {
                $student->timeline .= "<li class='feed-item'>".$gettimeline[$i]."</li>";
            }

            $data = str_replace(array('-','_'),array('+','/'),$student->comment);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $student->comment = base64_decode($data);

            $resolvedby = Database::table("users")->where("id", $student->resolvedby)->first();
            $student->resolvedby = $resolvedby->fname." ".$resolvedby->lname."<br>on ".$student->resolvedon;
            
        }

        return view('issues', compact("user", "students","New","Processing","Resolved"));
    }
  
    
    /**
     * Record New Issue
     * 
     * @return Json
     */
    public function reportissue() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $error = 1;
        if ($user->role == 'staff') {
            if ($user->position == 'amanager') {
                $error = 0;
            }elseif($user->position = 'manager') {
                $error = 0;
            }
        }

        if($user->role == 'staff' && $errro==1){
            return view('errors/404');
        }

        $itype = escape(input('iType'));
        $iBrief = escape(input('iBrief'));
        $userid = escape(input('userid'));

        $student = Database::table('users')->where('id',$userid)->where('school',$user->school)->where('branch',$user->branch)->where('role','student')->first();

        if(!empty($student)){

            $data = array(
                "type" => $itype,
                "student" => $student->id,
                "status" => "New",
                "brief" => $iBrief,
                "timeline" => "Issue Created on ".date("d-m-Y").";",
                "reportedby" => $user->id,
                "school" => $user->school,
                "branch" => $user->branch,
                "createdat" => date("d-m-Y")
            );

            $comment = base64_encode($data['timeline']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['timeline'] = $comment;

            $comment = base64_encode($data['brief']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['brief'] = $comment;

            Database::table('reportedissues')->insert($data);

            $getUser = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", $user->id)->first();
            $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

            $message = "Dear ".$manager->fname." ".$manager->lname.",\nGreetings from RCDS!\n\nNew issues has been reported with below details. Kindly review and resolve it asap.\n\n*Student:* ".$student->fname." ".$student->lname." (".$student->phone.")\n*Issue Type:* ".$data['type']."\n*Issue Status:* ".$data['status']."\n*Reported By:* ".$getUser->fname." ".$getUser->lname." (".$getUser->phone.")\n\n*Issue Brief:* ".$iBrief."\n\nRCDS - Real Car Driving School.";

            if(strlen($manager->phone)>10){
                $mphone = substr($manager->phone,-10);
              }
              else{
                $mphone = $manager->phone;
              }

              if (!empty($mphone)) {

                Database::table("usermessages")->insert(array(
                  "receiver" => $manager->id, 
                  "type" => "whatsapp", 
                  "contact" => $mphone,
                  "Subject" => "New Issue",
                  "message" => $message,
                  "scheduled_at" => date("d-m-Y H:i:s"),
                  "sent_by" => $user->id,
                  "school" => $manager->school, 
                  "branch" => $manager->branch, 
                  "status" => "Pending"
                ));
                }

            return response()->json(responder("success", "Issue Reported!", "New issue has been reported successfully.", "reload()"));
        }else{
          return response()->json(responder("error", "Hmm!", "No record found for the selected student.", "reload()"));
        }
        
    }

    /**
     * Move student to processing
    *
    */
    public function processing(){
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $error = 1;
        if ($user->role == 'staff') {
            if ($user->position == 'amanager') {
                $error = 0;
            }elseif($user->position = 'manager') {
                $error = 0;
            }
        }

        if($user->role == 'staff' && $errro==1){
            return view('errors/404');
        }
        $studentid = escape(input('studentid'));
        $issueid = escape(input('issueid'));
        $student = Database::table('reportedissues')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $issueid
        ))->first();

        if(!empty($student)){

            $data = str_replace(array('-','_'),array('+','/'),$student->timeline);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $student->timeline = base64_decode($data);

            $data = array(
                "status" => "Processing",
                "timeline" => $student->timeline."Moved to Processing on ".date("d-m-Y").";"
            );

            $comment = base64_encode($data['timeline']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['timeline'] = $comment;

            Database::table("reportedissues")->where('id', $issueid)->update($data);

            $checkEnrollment = Database::table("reportedissues")->where("student", $student->student)->where("id", $issueid)->where("status", "Processing")->first();

            if(!empty($checkEnrollment)){

                //updatemanager

                $data = str_replace(array('-','_'),array('+','/'),$checkEnrollment->brief);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $checkEnrollment->brief = base64_decode($data);
                
                $getUser = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", $user->id)->first();
                $reportedby = Database::table("users")->where("branch", $checkEnrollment->branch)->where("school", $checkEnrollment->school)->where("id", $checkEnrollment->reportedby)->first();
                $studentDetails = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", $student->student)->first();
                $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

                $message = "Dear ".$manager->fname." ".$manager->lname.",\nGreetings from RCDS!\n\nBelow issues has been moved to *Processing* by *".$getUser->fname." ".$getUser->lname."* (".$getUser->phone."). Kindly review the below.\n\n*Student:* ".$studentDetails->fname." ".$studentDetails->lname." (".$studentDetails->phone.")\n*Issue Type:* ".$checkEnrollment->type."\n*Issue Status:* ".$checkEnrollment->status."\n*Reported By:* ".$reportedby->fname." ".$reportedby->lname." (".$reportedby->phone.")\n\n*Issue Brief:* ".$checkEnrollment->brief."\n\nRCDS - Real Car Driving School.";

                if(strlen($manager->phone)>10){
                    $mphone = substr($manager->phone,-10);
                }
                else{
                    $mphone = $manager->phone;
                }

                if (!empty($mphone)) {

                    Database::table("usermessages")->insert(array(
                    "receiver" => $manager->id, 
                    "type" => "whatsapp", 
                    "contact" => $mphone,
                    "Subject" => "New Issue",
                    "message" => $message,
                    "scheduled_at" => date("d-m-Y H:i:s"),
                    "sent_by" => $user->id,
                    "school" => $manager->school, 
                    "branch" => $manager->branch, 
                    "status" => "Pending"
                    ));
                    }

                return response()->json(responder("success", "Done!", "Issue has been moved to Processing.", "reload()"));
            }else{
                return response()->json(responder("error", "Hmm!", "Someting went wrong.", "reload()"));
            }
        }else{
            return response()->json(responder("error", "Hmm!", "No record found.", "reload()"));
        }

    }

    /**
    * Move student to Udpate Comments
    *
    */
    public function updatecomment(){
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $error = 1;
        if ($user->role == 'staff') {
            if ($user->position == 'amanager') {
                $error = 0;
            }elseif($user->position = 'manager') {
                $error = 0;
            }
        }

        if($user->role == 'staff' && $errro==1){
            return view('errors/404');
        }
        $studentid = escape(input('studentid'));
        $issueid = escape(input('issueid'));
        $student = Database::table('reportedissues')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $issueid
        ))->first();

        if($user->role != 'superadmin' && $user->role != 'admin'){
            if($student->status == "Resolved"){
                return response()->json(responder("error", "Hmm!", "You are not allowed to update the resolved issues comments. Please contact Superadmin or Admin.", "reload()"));
            }
        }

        if(!empty($student)){

            $data = str_replace(array('-','_'),array('+','/'),$student->timeline);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $student->timeline = base64_decode($data);

            $data = array(
                "comment" => escape(input('comment')),
                "timeline" => $student->timeline."Comment udpated on ".date("d-m-Y").";"
            );

            $comment = base64_encode($data['comment']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['comment'] = $comment;

            $comment = base64_encode($data['timeline']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['timeline'] = $comment;

            Database::table("reportedissues")->where('id', $issueid)->update($data);

            $checkEnrollment = Database::table("reportedissues")->where("student", $student->student)->where("id", $issueid)->where("comment", $data['comment'])->first();

            if(!empty($checkEnrollment)){

                //updatemanager

                $data = str_replace(array('-','_'),array('+','/'),$checkEnrollment->brief);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $checkEnrollment->brief = base64_decode($data);
                
                $getUser = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", $user->id)->first();
                $reportedby = Database::table("users")->where("branch", $checkEnrollment->branch)->where("school", $checkEnrollment->school)->where("id", $checkEnrollment->reportedby)->first();
                $studentDetails = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", $student->student)->first();
                $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

                $message = "Dear ".$manager->fname." ".$manager->lname.",\nGreetings from RCDS!\n\nBelow issues has an updated *Comment* by *".$getUser->fname." ".$getUser->lname."* (".$getUser->phone."). Kindly review the below.\n\n*Student:* ".$studentDetails->fname." ".$studentDetails->lname." (".$studentDetails->phone.")\n*Issue Type:* ".$checkEnrollment->type."\n*Issue Status:* ".$checkEnrollment->status."\n*Reported By:* ".$reportedby->fname." ".$reportedby->lname." (".$reportedby->phone.")\n\n*Issue Brief:* ".$checkEnrollment->brief."\n\n*Comment:* ".escape(input('comment'))."\n\nRCDS - Real Car Driving School.";

                if(strlen($manager->phone)>10){
                    $mphone = substr($manager->phone,-10);
                }
                else{
                    $mphone = $manager->phone;
                }

                if (!empty($mphone)) {

                    Database::table("usermessages")->insert(array(
                    "receiver" => $manager->id, 
                    "type" => "whatsapp", 
                    "contact" => $mphone,
                    "Subject" => "New Comment",
                    "message" => $message,
                    "scheduled_at" => date("d-m-Y H:i:s"),
                    "sent_by" => $user->id,
                    "school" => $manager->school, 
                    "branch" => $manager->branch, 
                    "status" => "Pending"
                    ));
                    }

                return response()->json(responder("success", "Done!", "Comment has been updated for the issue.", "reload()"));
            }else{
                return response()->json(responder("error", "Hmm!", "Someting went wrong.", "reload()"));
            }
        }else{
            return response()->json(responder("error", "Hmm!", "No record found.", "reload()"));
        }

    }

    /**
    * Update Issue Brief
    *
    */
    public function updatebrief(){
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $error = 1;
        if ($user->role == 'staff') {
            if ($user->position == 'amanager') {
                $error = 0;
            }elseif($user->position = 'manager') {
                $error = 0;
            }
        }

        if($user->role == 'staff' && $errro==1){
            return view('errors/404');
        }
        $studentid = escape(input('studentid'));
        $issueid = escape(input('issueid'));
        $student = Database::table('reportedissues')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $issueid
        ))->first();

        if($user->role != 'superadmin' && $user->role != 'admin'){
            if($student->status == "Resolved"){
                return response()->json(responder("error", "Hmm!", "You are not allowed to update the resolved issues brief. Please contact Superadmin or Admin.", "reload()"));
            }
        }

        if(!empty($student)){

            $data = str_replace(array('-','_'),array('+','/'),$student->brief);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $oldbrief = base64_decode($data);

            $data = str_replace(array('-','_'),array('+','/'),$student->timeline);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $student->timeline = base64_decode($data);

            $brief = str_replace(array('<br>','\n'),array(' ',' '),escape(input('brief')));

            $data = array(
                "brief" => $brief,
                "timeline" => $student->timeline."Issue brief udpated on ".date("d-m-Y").";"
            );

            $comment = base64_encode($data['brief']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['brief'] = $comment;

            $comment = base64_encode($data['timeline']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['timeline'] = $comment;

            Database::table("reportedissues")->where('id', $issueid)->update($data);

            $checkEnrollment = Database::table("reportedissues")->where("student", $student->student)->where("id", $issueid)->where("brief", $data['brief'])->first();

            if(!empty($checkEnrollment)){

                //updatemanager

                $data = str_replace(array('-','_'),array('+','/'),$checkEnrollment->brief);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $checkEnrollment->brief = base64_decode($data);
                
                $getUser = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", $user->id)->first();
                $reportedby = Database::table("users")->where("branch", $checkEnrollment->branch)->where("school", $checkEnrollment->school)->where("id", $checkEnrollment->reportedby)->first();
                $studentDetails = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", $student->student)->first();
                $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

                $message = "Dear ".$manager->fname." ".$manager->lname.",\nGreetings from RCDS!\n\nBelow issues has an updated *Brief* by *".$getUser->fname." ".$getUser->lname."* (".$getUser->phone."). Kindly review the below.\n\n*Student:* ".$studentDetails->fname." ".$studentDetails->lname." (".$studentDetails->phone.")\n*Issue Type:* ".$checkEnrollment->type."\n*Issue Status:* ".$checkEnrollment->status."\n*Reported By:* ".$reportedby->fname." ".$reportedby->lname." (".$reportedby->phone.")\n\n*Old Issue Brief:* ".$oldbrief."\n\n*New Issue Brief:* ".$checkEnrollment->brief."\n\n*Comment:* ".escape(input('comment'))."\n\nRCDS - Real Car Driving School.";

                if(strlen($manager->phone)>10){
                    $mphone = substr($manager->phone,-10);
                }
                else{
                    $mphone = $manager->phone;
                }

                if (!empty($mphone)) {

                    Database::table("usermessages")->insert(array(
                    "receiver" => $manager->id, 
                    "type" => "whatsapp", 
                    "contact" => $mphone,
                    "Subject" => "New Comment",
                    "message" => $message,
                    "scheduled_at" => date("d-m-Y H:i:s"),
                    "sent_by" => $user->id,
                    "school" => $manager->school, 
                    "branch" => $manager->branch, 
                    "status" => "Pending"
                    ));
                    }

                return response()->json(responder("success", "Done!", "Comment has been updated for the issue.", "reload()"));
            }else{
                return response()->json(responder("error", "Hmm!", "Someting went wrong.", "reload()"));
            }
        }else{
            return response()->json(responder("error", "Hmm!", "No record found.", "reload()"));
        }

    }

    /**
     * Move student to resolved
    *
    */
    public function resolved(){
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $error = 1;
        if ($user->role == 'staff') {
            if ($user->position == 'amanager') {
                $error = 0;
            }elseif($user->position = 'manager') {
                $error = 0;
            }
        }

        if($user->role == 'staff' && $errro==1){
            return view('errors/404');
        }
        $studentid = escape(input('studentid'));
        $issueid = escape(input('issueid'));
        $student = Database::table('reportedissues')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $issueid
        ))->first();

        if(!empty($student)){

            $data = str_replace(array('-','_'),array('+','/'),$student->timeline);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $student->timeline = base64_decode($data);

            $data = array(
                "status" => "Resolved",
                "timeline" => $student->timeline."Issue resolved on ".date("d-m-Y").";",
                "resolvedby" => $user->id,
                "resolvedon" => date("d-m-Y")
            );

            $comment = base64_encode($data['timeline']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['timeline'] = $comment;

            Database::table("reportedissues")->where('id', $issueid)->update($data);

            $checkEnrollment = Database::table("reportedissues")->where("student", $student->student)->where("id", $issueid)->where("status", "Resolved")->first();

            if(!empty($checkEnrollment)){

                //updatemanager

                $data = str_replace(array('-','_'),array('+','/'),$checkEnrollment->brief);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $checkEnrollment->brief = base64_decode($data);
                
                $getUser = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", $user->id)->first();
                $reportedby = Database::table("users")->where("branch", $checkEnrollment->branch)->where("school", $checkEnrollment->school)->where("id", $checkEnrollment->reportedby)->first();
                $studentDetails = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", $student->student)->first();
                $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

                $message = "Dear ".$manager->fname." ".$manager->lname.",\nGreetings from RCDS!\n\nBelow issues has been moved to *Resolved* by *".$getUser->fname." ".$getUser->lname."* (".$getUser->phone."). Kindly review the below.\n\n*Student:* ".$studentDetails->fname." ".$studentDetails->lname." (".$studentDetails->phone.")\n*Issue Type:* ".$checkEnrollment->type."\n*Issue Status:* ".$checkEnrollment->status."\n*Reported By:* ".$reportedby->fname." ".$reportedby->lname." (".$reportedby->phone.")\n\n*Issue Brief:* ".$checkEnrollment->brief."\n\n*Comment:* ".escape(input('comment'))."\n\nRCDS - Real Car Driving School.";

                if(strlen($manager->phone)>10){
                    $mphone = substr($manager->phone,-10);
                }
                else{
                    $mphone = $manager->phone;
                }

                if (!empty($mphone)) {

                    Database::table("usermessages")->insert(array(
                    "receiver" => $manager->id, 
                    "type" => "whatsapp", 
                    "contact" => $mphone,
                    "Subject" => "Issue Resolved",
                    "message" => $message,
                    "scheduled_at" => date("d-m-Y H:i:s"),
                    "sent_by" => $user->id,
                    "school" => $manager->school, 
                    "branch" => $manager->branch, 
                    "status" => "Pending"
                    ));
                    }

                return response()->json(responder("success", "Done!", "Issue has been moved to resolved successfully.", "reload()"));
            }else{
                return response()->json(responder("error", "Hmm!", "Someting went wrong.", "reload()"));
            }
        }else{
            return response()->json(responder("error", "Hmm!", "No record found.", "reload()"));
        }

    }

    /**
    * Remove Issue
    *
    */
    public function remove(){
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin') {
            return view('errors/404');
        }
        $studentid = escape(input('studentid'));
        $issueid = escape(input('issueid'));
        
        Database::table('reportedissues')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $issueid
        ))->delete();

        $student = Database::table('reportedissues')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $issueid
        ))->first();

        if(!empty($student)){

            return response()->json(responder("error", "Hmm!", "No record found to delete.", "reload()"));

        }else{

            return response()->json(responder("success", "Done!", "Issue has been successfully removed from list.", "reload()"));

        }

    }


}
