<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\Database;
use Simcify\File;
use Simcify\Sms;
use Simcify\Mail;
use Simcify\FS;

class Communication{

    /**
     * Get profile view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin') {
            return view('errors/404');
        }

        $getchat = SMS::getcommunication();

        return view('communication', compact("user", "profile","getchat"));
    }

}
