<?php
namespace Simcify\Controllers;

use Simcify\Database;
use Simcify\Landa;
use Simcify\Auth;

class Attendance{

    /**
     * Get Attendance view
     * 
     * @return \Pecee\Http\Response
     */

    public function get() {
      $user = Auth::user();
      if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
        return view('errors/404');
      }
      if (isset($_GET['date'])) {
        if (!empty($_GET['date'])) {
          $date = escape(input('date'));
          $cdate = date("Y-m-d");
          $attendance = Database::table('users')->leftJoin('attendance','users.id','attendance.id')->leftJoin('invoices','users.id','invoices.student')->rightJoin('schedules','users.id','schedules.student')->where("users`.`branch", $user->branch)->where("users`.`role","student")->where("attendance`.`date", $date)->where("schedules`.`start", "LIKE", "%" . $date . "%")->orderBy('users.id', false)->get("`users.fname`", "`users.lname`", "`users.avatar`", "`users.email`", "`users.address`","`attendance.id`", "`users.phone`", "`attendance.status`","`attendance.isstarted`", "`attendance.lastupdate`", "`attendance.date`","`invoices.amount`","`invoices.amountpaid`","`schedules.instructor`","`schedules.start`","`schedules.id` as scheduleid","`schedules.cstatus`");

          $isFound = "";
          $instructors = Database::table("users")->get();
          $courses = Database::table("courses")->get();

          foreach ($attendance as $student) {
            $student->sdate = date('Y-m-d', strtotime($student->start));
            $student->stime = date('h:i A', strtotime($student->start));
          }
    
          return view('attendance', compact("attendance","user","invoices","date","cdate","instructors","isFound","courses"));
        } else {
          $date = date("Y-m-d");
          $cdate = date("Y-m-d");
          $attendance = Database::table('users')->leftJoin('attendance','users.id','attendance.id')->leftJoin('invoices','users.id','invoices.student')->rightJoin('schedules','users.id','schedules.student')->where("users`.`branch", $user->branch)->where("users`.`role","student")->where("attendance`.`date", $date)->where("schedules`.`start", "LIKE", "%" . $date . "%")->orderBy('users.id', false)->get("`users.fname`", "`users.lname`", "`users.avatar`", "`users.email`", "`users.address`","`attendance.id`", "`users.phone`", "`attendance.status`","`attendance.isstarted`", "`attendance.lastupdate`", "`attendance.date`","`invoices.amount`","`invoices.amountpaid`","`schedules.instructor`","`schedules.start`","`schedules.id` as scheduleid","`schedules.cstatus`");

          $isFound = "";
          $instructors = Database::table("users")->get();
          $courses = Database::table("courses")->get();

          foreach ($attendance as $student) {
            $student->sdate = date('Y-m-d', strtotime($student->start));
            $student->stime = date('h:i A', strtotime($student->start));
          }
    
          return view('attendance', compact("attendance","user","invoices","date","cdate","instructors","isFound","courses"));
        }
    } else {
      $date = date("Y-m-d");
      $cdate = date("Y-m-d");
      $attendance = Database::table('users')->leftJoin('attendance','users.id','attendance.id')->leftJoin('invoices','users.id','invoices.student')->rightJoin('schedules','users.id','schedules.student')->rightJoin('fleet','schedules.car','fleet.id')->rightJoin('courses','schedules.course','courses.id')->where("users`.`branch", $user->branch)->where("users`.`role","student")->where("attendance`.`date", $date)->where("schedules`.`start", "LIKE", "%" . $date . "%")->orderBy('users.id', false)->get("`users.fname`", "`users.lname`", "`users.avatar`", "`users.email`", "`users.address`","`attendance.id`", "`users.phone`", "`attendance.status`","`attendance.isstarted`", "`attendance.lastupdate`", "`attendance.date`","`invoices.amount`","`invoices.amountpaid`","`schedules.instructor`","`schedules.id` as scheduleid","`schedules.start`", "`fleet.carplate`", "`courses.duration`","`schedules.cstatus`");

      foreach ($attendance as $student) {
        $student->completed = Database::table('schedules')->where('student', $student->id)->where('status', "Complete")->count("id", "total")[0]->total;
        $student->total = Database::table('schedules')->where('student', $student->id)->count("id", "total")[0]->total;
        $student->sdate = date('Y-m-d', strtotime($student->start));
        $student->stime = date('h:i A', strtotime($student->start));

        //lesson details

        $trainingitems = Database::table('attendance')->where('id', $student->id)->get();
        foreach($trainingitems as $items){
            if($items->trainingitems!=""){
            $ttrainingitem .= $items->trainingitems.",";
            }
        }
        $lesson1 = explode(',',$ttrainingitem);
        $lesson = array_unique($lesson1);
        $k=1;
        for($i=0;$i<=count($lesson1);$i++){
            if($lesson[$i]!=""){
            $clessonDetails = Database::table('practicallessons')->where('id', $lesson[$i])->first();
            $student->completeslesson .= "<label>".$k.": ".$clessonDetails->name.": ".$clessonDetails->description."</label><br>";
            $k++;
            }
        }

        $j=1;
        $clessonDetails = Database::table('practicallessons')->get();
        $tlessons = 0;
        foreach($clessonDetails as $clesson){
          $tlessons++;
            $com=0;
            for($i=0;$i<count($lesson1);$i++){
                if($clesson->id==$lesson[$i]){
                $com=1;
                }
            }
            if($com==0){
                $student->pendinglesson .= "<label>".$j.": ".$clesson->name.": ".$clesson->description."</label><br>";
                $j++;
            }
        }

        $student->tlcomplete = $k-1;
        $student->tlpending = $j-1;
        $student->tlessons = $tlessons;

      }

      $isFound = "";
      $instructors = Database::table("users")->get();
      $courses = Database::table("courses")->get();

      return view('attendance', compact("attendance","user","invoices","date","cdate","instructors","isFound","courses"));
    }
    }

    /*else {
      $date = date("Y-m-d");
      $cdate = date("Y-m-d");
      $attendance = Database::table('users')->leftJoin('attendance','users.id','attendance.id')->leftJoin('invoices','users.id','invoices.student')->rightJoin('schedules','users.id','schedules.student')->where("users`.`branch", $user->branch)->where("users`.`role","student")->where("users`.`isWaiting",0)->where("attendance`.`date", $date)->where("schedules`.`start","<=", $date)->orderBy('users.id', false)->get("`users.fname`", "`users.lname`", "`users.avatar`", "`users.email`", "`users.address`","`attendance.id`", "`attendance.status`", "`attendance.lastupdate`", "`attendance.date`","`invoices.amount`","`invoices.amountpaid`","`schedules.instructor`");

      $instructors = Database::table("users")->get();

      return view('attendance', compact("attendance","user","invoices","date","cdate","instructors"));
    }
    } */
    
    /**
     * Update Attendance
     * 
     * @return Json
     */
    public function present() {
      $user = Auth::user();
      $data = array(
          "status" => 2
      );
      $data2 = array(
        "status" => "Complete"
      );
      $sdate = escape(input('date'));
      $cdate = date("Y-m-d");

      if($sdate<=$cdate){
      Database::table("attendance")->where("id", input("userid"))->where('date', $sdate)->where("school", $user->school)->where("branch", $user->branch)->update($data);
      Database::table("schedules")->where("id", input("scheduleid"))->where("student", input("userid"))->where("school", $user->school)->where("branch", $user->branch)->update($data2);
      return response()->json(responder("success", "Attendance Marked", "Student Marked as Present Successfully", "reload()"));
      }
      else{
        return response()->json(responder("error", "Hmm!", "Something went wrong please try again."));
      }
    }
    public function absent() {
      $user = Auth::user();
      $data = array(
          "status" => 1
      );
      $data2 = array(
        "status" => "Missed"
      );
      $sdate = escape(input('date'));
      $cdate = date("Y-m-d");

      if($sdate<=$cdate){
      Database::table("attendance")->where("id", input("userid"))->where('date', $sdate)->where("school", $user->school)->where("branch", $user->branch)->update($data);
      Database::table("schedules")->where("id", input("scheduleid"))->where("student", input("userid"))->where("school", $user->school)->where("branch", $user->branch)->update($data2);
      return response()->json(responder("success", "Attendance Marked", "Student Marked as Absent Successfully", "reload()"));
      }
      else{
        return response()->json(responder("error", "Hmm!", "Something went wrong please try again."));
      }
    }

}
