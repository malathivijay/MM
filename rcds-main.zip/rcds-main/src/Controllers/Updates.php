<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\File;
use Simcify\Database;
use DotEnvWriter\DotEnvWriter;
use Simcify\Sms;

class Updates {

    /**
     * Get settings view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user      = Auth::user();
        if ($user->role != 'instructor') {
            return view('errors/404');
          }
        $date = date("Y-m-d");
        $fuel = Database::table('fuel')->leftJoin('users','fuel.recordby','users.id')->leftJoin('fleet','fuel.car','fleet.id')->where('fuel`.`date',$date)->where('fuel`.`recordby',$user->id)->where('fuel`.`branch',$user->branch)->where('fuel`.`school',$user->school)->get("`users.id`","`users.fname`","`users.lname`","`fuel.type`","`fuel.date`","`fuel.lastupdate`","`fuel.amount`","`fuel.photo`","`fuel.odo`","`fuel.reading`","`fuel.comment`","`fleet.carplate`");
        foreach($fuel as $fue){
            if($fue->type==1){
                $fue->type = "CNG";
            }elseif($fue->type==2){
                $fue->type = "Petrol";
            }
            
        }
        $expenses = Database::table('expenses')->leftJoin('users','expenses.recordby','users.id')->leftJoin('fleet','expenses.car','fleet.id')->where('expenses`.`date',$date)->where('expenses`.`recordby',$user->id)->where('expenses`.`branch',$user->branch)->where('expenses`.`school',$user->school)->get("`users.id`","`users.fname`","`users.lname`","`expenses.type`","`expenses.date`","`expenses.lastupdate`","`expenses.amount`","`expenses.photo`","`expenses.comment`","`fleet.carplate`");

        $dropout = Database::table('dropreading')->leftJoin('users','dropreading.recordby','users.id')->leftJoin('fleet','dropreading.car','fleet.id')->where('dropreading`.`date',$date)->where('dropreading`.`recordby',$user->id)->where('dropreading`.`branch',$user->branch)->where('dropreading`.`school',$user->school)->get("`users.id`","`users.fname`","`users.lname`","`dropreading.reading`","`dropreading.date`","`dropreading.lastupdate`","`dropreading.photo`","`dropreading.comment`","`fleet.carplate`");

        $fleet = Database::table('fleet')->where('branch', $user->branch)->where('school', $user->school)->where('instructor', $user->id)->first();

        return view('updates', compact("user",'fuel','expenses','dropout',"fleet"));
    }

    /**
     * New Fuel Expenses
     * 
     * @return Json
     */
    public function fuelexpenses() {
        $user = Auth::user();
        $date = date("Y-m-d");
        $car = Database::table('fleet')->where("instructor", $user->id)->first();
        $data = array(
            "date" => $date,
            "car" => $car->id,
            "recordby" => $user->id,
            "branch" => $user->branch,
            "school" => $user->school
        );
        foreach (input()->post as $field) {
            if ($field->index == "fuel") {
                if (!empty($field->value)) {
                    $fuel = File::upload($field->value, "fuel", array(
                        "source" => "base64",
                        "extension" => "png"
                    ));
                    if ($fuel['status'] == "success") {
                        $data['photo']=$fuel['info']['name'];
                    }
                }
                continue;
            }
            if ($field->index == "odo") {
                if (!empty($field->value)) {
                    $odo = File::upload($field->value, "odo", array(
                        "source" => "base64",
                        "extension" => "png"
                    ));
                    if ($odo['status'] == "success") {
                        $data['odo']=$odo['info']['name'];
                    }
                }
                continue;
            }
            if ($field->index == "csrf-token") {
                continue;
            }
            if ($field->index == "type") {
                if($field->value=="cng"){
                    $data['type']= 1;
                }elseif($field->value=="petrol"){
                    $data['type']= 2;
                }else{
                    return response()->json(responder("error", "Oops", "Incorrect fuel option selected"));
                }
                /* Database::table('fuel')->where("date", $date)->update(array(
                    $field->index => $field->value
                )); */
                continue;
            }
            if ($field->index == "amount") {
                if($field->value>0){
                /* Database::table('fuel')->where("date", $date)->update(array(
                    $field->index => escape($field->value)
                )); */
                $data['amount']= escape($field->value);
                }else{
                    return response()->json(responder("error", "Oops", "Incorrect fuel Amount selected"));
                }
                continue;
            }
            if ($field->index == "reading") {
                if($field->value>0){
                $data['reading']= escape($field->value);
                }else{
                    return response()->json(responder("error", "Oops", "Incorrect Reading"));
                }
                continue;
            }
            if ($field->index == "comment") {
                if($field->value!=""){
                /* Database::table('fuel')->where("date", $date)->update(array(
                    $field->index => escape($field->value)
                )); */
                $data['comment']= escape($field->value);
            }
                continue;
            }
            
        }
        Database::table('fuel')->insert($data);
        $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();
        $instructor = Database::table("users")->where("id", $user->id)->where("school", $user->school)->where("branch", $user->branch)->first();
        if(strlen($instructor->phone)>10){
			$iphone = substr($instructor->phone,-10);
		}
		else{
			$iphone = $instructor->phone;
		}
        $managernotify = "Dear ".$manager->fname.",\n\nMr. ".$instructor->fname." ".$instructor->lname." Ph: ".$iphone." has insert a new expense record:\n\nCAR: ".$car->carplate."\nFuel Type: ".strtoupper(escape(input('type')))."\nAmount: ".money($data['amount'])."\nODO: ".$data['reading']."\n\n".env("APP_NAME");

        $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
        if (!empty($manager->phone)) {
	        $send = Sms::africastalking($manager->phone, $managernotify);
            if ($send) {
                return response()->json(responder("success", "Done", "Fuel Expenses Successfully updated and the manager has been notified", "reload()"));
            } else { 
                return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
            }
    	}

        return response()->json(responder("success", "Alright", "Fuel Expenses Successfully updated", "reload()"));
    }

    /**
     * New Other Expenses
     * 
     * @return Json
     */
    public function otherexpenses() {
        $user = Auth::user();
        $date = date("Y-m-d");
        $car = Database::table('fleet')->where("instructor", $user->id)->first();
        $data = array(
            "date" => $date,
            "car" => $car->id,
            "recordby" => $user->id,
            "branch" => $user->branch,
            "school" => $user->school
        );
        foreach (input()->post as $field) {
            if ($field->index == "other") {
                if (!empty($field->value)) {
                    $other = File::upload($field->value, "other", array(
                        "source" => "base64",
                        "extension" => "png"
                    ));
                    if ($other['status'] == "success") {
                        $data['photo']=$other['info']['name'];
                    }
                }
                continue;
            }
            if ($field->index == "csrf-token") {
                continue;
            }
            if ($field->index == "type") {
                
                $data['type']= escape($field->value);
                
                continue;
            }
            if ($field->index == "amount") {
                if($field->value>0){
                $data['amount']= escape($field->value);
                }else{
                    return response()->json(responder("error", "Oops", "Incorrect Expenses Amount selected"));
                }
                continue;
            }
            if ($field->index == "comment") {
                if($field->value!=""){
                $data['comment']= escape($field->value);
            }
                continue;
            }
            
        }
        Database::table('expenses')->insert($data);
        $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();
        $instructor = Database::table("users")->where("id", $user->id)->where("school", $user->school)->where("branch", $user->branch)->first();
        if(strlen($instructor->phone)>10){
			$iphone = substr($instructor->phone,-10);
		}
		else{
			$iphone = $instructor->phone;
		}
        $managernotify = "Dear ".$manager->fname.",\n\nMr. ".$instructor->fname." ".$instructor->lname." Ph: ".$iphone." has insert a new expense record:\n\nCAR: ".$car->carplate."\nType: ".strtoupper(escape(input('type')))."\nAmount: ".money($data['amount'])."\n\n".env("APP_NAME");

        $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
        if (!empty($manager->phone)) {
	        $send = Sms::africastalking($manager->phone, $managernotify);
            if ($send) {
                return response()->json(responder("success", "Done", "Expenses Successfully updated and the manager has been notified", "reload()"));
            } else { 
                return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
            }
    	}

        return response()->json(responder("success", "Alright", "Fuel Expenses Successfully updated", "reload()"));
    }

    /**
     * New Dropout record
     * 
     * @return Json
     */
    public function dropout() {
        $user = Auth::user();
        $date = date("Y-m-d");
        $car = Database::table('fleet')->where("instructor", $user->id)->first();
        $data = array(
            "date" => $date,
            "car" => $car->id,
            "recordby" => $user->id,
            "branch" => $user->branch,
            "school" => $user->school
        );
        foreach (input()->post as $field) {
            if ($field->index == "drop") {
                if (!empty($field->value)) {
                    $drop = File::upload($field->value, "drop", array(
                        "source" => "base64",
                        "extension" => "png"
                    ));
                    if ($drop['status'] == "success") {
                        $data['photo']=$drop['info']['name'];
                    }
                }
                continue;
            }
            if ($field->index == "csrf-token") {
                continue;
            }
            if ($field->index == "reading") {
                
                $data['reading']= escape($field->value);
                
                continue;
            }
            if ($field->index == "comment") {
                if($field->value!=""){
                $data['comment']= escape($field->value);
            }
                continue;
            }
            
        }
        Database::table('dropreading')->insert($data);
        $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();
        $instructor = Database::table("users")->where("id", $user->id)->where("school", $user->school)->where("branch", $user->branch)->first();
        if(strlen($instructor->phone)>10){
			$iphone = substr($instructor->phone,-10);
		}
		else{
			$iphone = $instructor->phone;
		}
        $managernotify = "Dear ".$manager->fname.",\n\nMr. ".$instructor->fname." ".$instructor->lname." Ph: ".$iphone." has inserted a new drop out record:\n\nCAR: ".$car->carplate."\nReading: ".$data['reading']."\n\n".env("APP_NAME");

        $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
        if (!empty($manager->phone)) {
	        $send = Sms::africastalking($manager->phone, $managernotify);
            if ($send) {
                return response()->json(responder("success", "Done", "Expenses Successfully updated and the manager has been notified", "reload()"));
            } else { 
                return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
            }
    	}

        return response()->json(responder("success", "Alright", "Fuel Expenses Successfully updated", "reload()"));
    }

    /**
     * Update School on settings page
     * 
     * @return Json
     */
    public function updatecompany() {
        foreach (input()->post as $field) {
            if ($field->index == "csrf-token") {
                continue;
            }
            Database::table("schools")->where("id", Auth::user()->school)->update(array(
                $field->index => escape($field->value)
            ));
        }
        return response()->json(responder("success", "Alright", "School info successfully updated"));
    }

    /**
     * Update reminders on settings page
     * 
     * @return Json
     */
    public function updatereminders() {
        $user = Auth::user();
        if (empty(input("payment_reminders"))) {
            Database::table("schools")->where("id", $user->school)->update(array(
                "payment_reminders" => "Off"
            ));
        } else {
            Database::table("schools")->where("id", $user->school)->update(array(
                "payment_reminders" => "On"
            ));
        }
        if (empty(input("class_reminders"))) {
            Database::table("schools")->where("id", $user->school)->update(array(
                "class_reminders" => "Off"
            ));
        } else {
            Database::table("schools")->where("id", $user->school)->update(array(
                "class_reminders" => "On"
            ));
        }
        Database::table("reminders")->where("school", $user->school)->delete();
        foreach (input("message") as $index => $message) {
            $reminder = array(
                "school" => $user->school,
                "days" => input("days")[$index]->value,
                "type" => input("type")[$index]->value,
                "timing" => input("timing")[$index]->value,
                "send_via" => input("send_via")[$index]->value,
                "subject" => escape(input("subject")[$index]->value),
                "message" => escape(input("message")[$index]->value)
            );
            Database::table("reminders")->insert($reminder);
        }
        return response()->json(responder("success", "Alright", "Reminders successfully updated"));
    }

    /**
     * Update password on settings page
     * 
     * @return Json
     */
    public function updatepassword() {
        $user = Auth::user();
        if (hash_compare($user->password, Auth::password(input("current")))) {
            Database::table(config('auth.table'))->where("id", $user->id)->update(array(
                "password" => Auth::password(input("password"))
            ));
            return response()->json(responder("success", "Alright", "Password successfully updated", "reload()"));
        } else {
            return response()->json(responder("error", "Oops", "You have entered an incorrect password."));
        }
    }

    /**
     * Update system settings
     * 
     * @return Json
     */
    public function updatesystem() {
        $envPath = str_replace("src/Controllers", ".env", dirname(__FILE__));
        $env     = new DotEnvWriter($envPath);
        $env->castBooleans();
        $enableToggle = array(
            "ALLOW_SIGNUP",
            "SHOW_SCHOOLS_MENU"
        );
        foreach ($enableToggle as $key) {
            if (empty(input($key))) {
                $env->set($key, 'Disabled');
            }
        }
        if (empty(input("SMTP_AUTH"))) {
            $env->set("SMTP_AUTH", false);
        }
        $env->set("MAIL_SENDER", input("APP_NAME") . " <" . input("MAIL_USERNAME") . ">");
        foreach (input()->post as $field) {
            if ($field->index == "APP_LOGO") {
                if (!empty($field->value)) {
                    $upload = File::upload($field->value, "app", array(
                        "source" => "base64",
                        "extension" => "png"
                    ));
                    if ($upload['status'] == "success") {
                        File::delete(env("APP_LOGO"), "app");
                        $env->set("APP_LOGO", $upload['info']['name']);
                        $env->save();
                    }
                }
                continue;
            }
            if ($field->index == "APP_ICON") {
                if (!empty($field->value)) {
                    $upload = File::upload($field->value, "app", array(
                        "source" => "base64",
                        "extension" => "png"
                    ));
                    if ($upload['status'] == "success") {
                        File::delete(env("APP_ICON"), "app");
                        $env->set("APP_ICON", $upload['info']['name']);
                        $env->save();
                    }
                }
                continue;
            }
            if ($field->index == "csrf-token") {
                continue;
            }
            $env->set($field->index, $field->value);
            $env->save();
        }
        return response()->json(responder("success", "Alright", "System settings successfully updated", "reload()"));
    }
}