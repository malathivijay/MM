<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\File;
use Simcify\Landa;
use Simcify\Sms;
use Simcify\Database;
use DotEnvWriter\DotEnvWriter;

class Getclass {

    /**
     * Get Classes view
     * 
     * @return \Pecee\Http\Response
     */
    public function get($studentid) {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
          }
        if(isset($_GET['date']) && $_GET['date']!=""){
            $date = escape(input('date'));
        }else{
        $date = date("Y-m-d");
        }
        $cdate = date("Y-m-d");
        $tschedule = Database::table("schedules")->where('student', $studentid)->first();
        $getclass = Database::table('users')->leftJoin('attendance','users.id','attendance.id')->leftJoin('invoices','users.id','invoices.student')->rightJoin('schedules','users.id','schedules.student')->where("users`.`branch", $user->branch)->where("users`.`school", $user->school)->where("users`.`role","student")->where("users`.`isWaiting",0)->where("schedules`.`instructor",$tschedule->instructor)->where("attendance`.`date", $date)->where("attendance`.`id", $studentid)->first("`users.fname`", "`users.lname`", "`users.avatar`", "`attendance.status`", "`attendance.lastupdate`", "`attendance.starttime`", "`attendance.endtime`", "`attendance.date`", "`attendance.isstarted`", "`attendance.status`", "`attendance.isverified`","`invoices.amount`","`invoices.amountpaid`","`schedules.instructor`","`schedules.student`","`schedules.course`","`schedules.start`","schedules.id","`schedules.status` as schedulestatus");
  
        $getclass->completed = Database::table('schedules')->where('student', $getclass->student)->where('status', "Complete")->count("id", "total")[0]->total;

        $ttrainingitems = Database::table('attendance')->where('id', $getclass->student)->where('date', $date)->first();
        $lesson = explode(',',$ttrainingitems->trainingitems);
        $lesson = array_unique($lesson);
        $k=1;
        for($i=0;$i<count($lesson);$i++){
            $clessonDetails = Database::table('practicallessons')->where('id', $lesson[$i])->first();
            $getclass->today .= "<label>".$k.": ".$clessonDetails->name.": ".$clessonDetails->description."</label><br>";
            $k++;
        }

        $trainingitems = Database::table('attendance')->where('id', $getclass->student)->get();
        foreach($trainingitems as $items){
            if($items->trainingitems!=""){
            $ttrainingitem .= $items->trainingitems.",";
            }
        }
        $lesson1 = explode(',',$ttrainingitem);
        $lesson = array_unique($lesson1);
        $k=1;
        for($i=0;$i<=count($lesson1);$i++){
            if($lesson[$i]!=""){
            $clessonDetails = Database::table('practicallessons')->where('id', $lesson[$i])->first();
            $getclass->completeslesson .= "<label>".$k.": ".$clessonDetails->name.": ".$clessonDetails->description."</label><br>";
            $k++;
            }
        }

        $j=1;
        $clessonDetails = Database::table('practicallessons')->get();
        foreach($clessonDetails as $clesson){
            $com=0;
            for($i=0;$i<count($lesson1);$i++){
                if($clesson->id==$lesson[$i]){
                $com=1;
                }
            }
            if($com==0){
                $getclass->pendinglesson .= "<label>".$j.": ".$clesson->name.": ".$clesson->description."</label><br>";
                $j++;
            }
        }

        $tlcomplete = $k-1;
        $tlpending = $j-1;

        $payment = $getclass->amount - $classes->amountpaid;
        if($payment !=0){
            $paymentstatus = $payment."/- Rs Pending";
        }else{
            $paymentstatus = "Full Paid";
        }
        $courses = Database::table("courses")->where('id', $getclass->course)->first();
        $date2 = date_create($date);
        $edate = date_format($date2,"M d, Y ").$getclass->endtime;
        $sdate = date_format($date2,"M d, Y ").$getclass->starttime;
        //$plessons = Database::table("practicallessons")->where('status', 1)->get();
  
        if($getclass->fname!=""){
        return view('getclass', compact("getclass","user","invoices","date","cdate","courses","paymentstatus","edate","sdate","plessons","tlcomplete","tlpending"));
         }else{
        redirect(url("Student@get"));
        } 
    }

    public function get3($studentid) {

        $date = date("Y-m-d");
        $tschedule = Database::table("schedules")->where('student', $studentid)->where("schedules`.`start", "LIKE", "%" . $date . "%")->first();
        $getclass = Database::table('users')->leftJoin('attendance','users.id','attendance.id')->rightJoin('schedules','users.id','schedules.student')->where("users`.`branch", $user->branch)->where("users`.`school", $user->school)->where("users`.`role","student")->where("users`.`isWaiting",0)->where("attendance`.`date", $date)->where("schedules`.`instructor",$tschedule->instructor)->where("schedules`.`start", "LIKE", "%" . $date . "%")->where("attendance`.`status",'!=',0)->orWhere("attendance`.`isstarted", 1)->first("`users.fname`", "`users.lname`", "`users.avatar`", "`attendance.status`", "`attendance.lastupdate`", "`attendance.starttime`", "`attendance.endtime`", "`attendance.date`", "`attendance.isstarted`", "`attendance.isverified`","`schedules.instructor`","`schedules.student`","`schedules.course`","`schedules.start`","schedules.id","`schedules.status` as schedulestatus");
  
        $getclass->completed = Database::table('schedules')->where('student', $getclass->student)->where('status', "Complete")->count("id", "total")[0]->total;

        $ttrainingitems = Database::table('attendance')->where('id', $getclass->student)->where('date', $date)->first();
        $lesson = explode(',',$ttrainingitems->trainingitems);
        $lesson = array_unique($lesson);
        $k=1;
        for($i=0;$i<count($lesson);$i++){
            $clessonDetails = Database::table('practicallessons')->where('id', $lesson[$i])->first();
            $getclass->today .= "<label>".$k.": ".$clessonDetails->name.": ".$clessonDetails->description."</label><br>";
            $k++;
        }

        $trainingitems = Database::table('attendance')->where('id', $getclass->student)->get();
        foreach($trainingitems as $items){
            if($items->trainingitems!=""){
            $ttrainingitem .= $items->trainingitems.",";
            }
        }
        $lesson1 = explode(',',$ttrainingitem);
        $lesson = array_unique($lesson1);
        $k=1;
        for($i=0;$i<=count($lesson1);$i++){
            if($lesson[$i]!=""){
            $clessonDetails = Database::table('practicallessons')->where('id', $lesson[$i])->first();
            $getclass->completeslesson .= "<label>".$k.": ".$clessonDetails->name.": ".$clessonDetails->description."</label><br>";
            $k++;
            }
        }

        $j=1;
        $clessonDetails = Database::table('practicallessons')->get();
        foreach($clessonDetails as $clesson){
            $com=0;
            for($i=0;$i<count($lesson1);$i++){
                if($clesson->id==$lesson[$i]){
                $com=1;
                }
            }
            if($com==0){
                $getclass->pendinglesson .= "<label>".$j.": ".$clesson->name.": ".$clesson->description."</label><br>";
                $j++;
            }
        }

        $tlcomplete = $k-1;
        $tlpending = $j-1;
  
        if($getclass->fname!=""){
        return view('getclass', compact("getclass","date","tlcomplete","tlpending"));
         }else{
            return response()->json(responder("error", "Hmm!", "There is no record for the student.", "reload()"));
        } 
    }


}