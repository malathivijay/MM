<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\Database;
use Simcify\File;

class Getfleetrecord {
    
    /**
     * Get fleet view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user        = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $error = 1;
        if ($user->role == 'staff') {
            if ($user->position == 'amanager') {
                $error = 0;
            }elseif($user->position = 'manager') {
                $error = 0;
            }
        }

        if($user->role == 'staff' && $errro==1){
            return view('errors/404');
        }
        if(isset($_REQUEST['recordid'])){
            $fleetrecord = Database::table('fleetmaintainancerecords')->where(array(
                'id' => escape(input('recordid')),
                'branch' => $user->branch,
                'school' => $user->school
            ))->first();

            /* print_r($fleetrecord); */
            /* $date = "car";
            echo $fleetrecord->$date."<br>"; */

            $fleetId = $fleetrecord->car;

            $fleet = Database::table('fleet')->where('id', $fleetId)->first();
            
            if(!empty($fleet)){
                foreach ($fleet as $car) {
                    if (empty($car->instructor)) {
                        $car->instructor = "Un-Assigned";
                    } else {
                        $instructor = Database::table('users')->where('id', $car->instructor)->first();
                        if (!empty($instructor)) {
                            $car->instructor = $instructor->fname . " " . $instructor->lname;
                        } else {
                            $car->instructor = "Un-Assigned";
                        }
                    }
                }

                $data = str_replace(array('-','_'),array('+','/'),$fleetrecord->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                
                $fleetrecord->comment = base64_decode($data); 
                $comment = explode(";",$fleetrecord->comment);

                $fleetchecks = Database::table('fleetChecks')->get();
                foreach($fleetchecks as $fleetcheck){
                    $checkName = $fleetcheck->checkName;
                    $check = explode('.',$fleetrecord->$checkName);
                    $fleetcheck->status = $check[0];
                    $fleetcheck->action = $check[1];
                    foreach($comment as $comm){
                        $commentData = explode(":",$comm);
                        if($commentData[0]==$fleetcheck->checkName){
                            $fleetcheck->fcomment = $commentData[1];
                        }
                        if($commentData[0]=='frontPhoto'){
                            $fleetrecord->fcommentfrontPhoto = $commentData[1];
                        }
                        if($commentData[0]=='rightPhoto'){
                            $fleetrecord->fcommentrightPhoto = $commentData[1];
                        }
                        if($commentData[0]=='backPhoto'){
                            $fleetrecord->fcommentbackPhoto = $commentData[1];
                        }
                        if($commentData[0]=='leftPhoto'){
                            $fleetrecord->fcommentleftPhoto = $commentData[1];
                        }
                        if($commentData[0]=='openBonnet'){
                            $fleetrecord->fcommentopenBonnet = $commentData[1];
                        }
                    }
                }

                

                $data = str_replace(array('-','_'),array('+','/'),$fleetrecord->wcomment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                
                $fleetrecord->wcomment = base64_decode($data); 


                return view('getfleetrecord', compact("user", "instructors", "fleet","fleetchecks","fleetrecord"));

            }else{
            redirect(url("Fleet@get")."?view=maintainancerecords");
            }
        }else{
            edirect(url("Fleet@get")."?view=maintainancerecords");
        }
    }
    
    /**
     * Update fleet record
     * 
     * @return Json
     */
    public function update() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $amanager = 0;
        $error = 1;
        if ($user->role == 'staff') {
            if ($user->position == 'amanager') {
                $error = 0;
                $amanager = 1;
            }elseif($user->position = 'manager') {
                $error = 0;
            }
        }

        if($user->role == 'staff' && $errro==1){
            return view('errors/404');
        }

        $recordid = escape(input('recordid'));
        $getrecord = Database::table('fleetmaintainancerecords')->where('id',$recordid)->where('school',$user->school)->where('branch',$user->branch)->first();
        $today = date("Y-m-d");

        if($amanager==1 && $today!=$getrecord->date){
            return response()->json(responder("error", "HMM!", "You are not allowed to make changes on previous records. Please contact your manager.","reload()"));
        }

        $dataStatus = array(
            'car' => $getrecord->car,
            'date' => $getrecord->date,
            'score' => 0,
            'comment' => escape(input('summary')),
            'createdby' => $getrecord->createdby,
            'status80to99' => 0,
            'status60to80' => 0,
            'status40to60' => 0,
            'status0to40' => 0,
            'statusOther' => 0,
            'branch' => $getrecord->branch,
            'school' => $getrecord->school
        );

        $fleetchecks = Database::table('fleetChecks')->get();
        $hComments = "";
        $wComments = "";

        foreach($fleetchecks as $fleetcheck){
            $fleetcheck->status = escape(input('status'.$fleetcheck->checkName));
            $fleetcheck->action = escape(input('action'.$fleetcheck->checkName));

            if($fleetcheck->status<=5 && $fleetcheck->status>0){
                if($fleetcheck->action<=5 && $fleetcheck->action>0){
                    $dataStatus[$fleetcheck->checkName] = $fleetcheck->status.".".$fleetcheck->action;
                    if($fleetcheck->status==5){
                        $dataStatus['status80to99']++;
                    }elseif($fleetcheck->status==4){
                        $dataStatus['status60to80']++;
                    }elseif($fleetcheck->status==3){
                        $dataStatus['status40to60']++;
                    }elseif($fleetcheck->status==2){
                        $dataStatus['status0to40']++;
                    }elseif($fleetcheck->status==1){
                        $dataStatus['statusOther']++;
                    }

                    $dataStatus['score'] += $fleetcheck->status;

                    //gathering comments
                    if(!empty($_REQUEST['comment'.$fleetcheck->checkName])){
                    $hComments .= ";".$fleetcheck->checkName.": ".escape(input('comment'.$fleetcheck->checkName));
                    /* $wComments .= "\n".$fleetcheck->name.": ".escape(input('comment'.$fleetcheck->checkName)); */
                    }

                }else{
                    return response()->json(responder("error", "HMM!", "Please select correct action for ".$fleetcheck->name));
                }
            }else{
                return response()->json(responder("error", "HMM!", "Please select correct status for ".$fleetcheck->name));
            }           
        }

        if(!empty($_REQUEST['commentfrontPhoto'])){
            $hComments .= ";frontPhoto: ".escape(input('commentfrontPhoto'));
            /* $wComments .= "\nFront Photo: ".escape(input('commentfrontPhoto')); */
        }
        if(!empty($_REQUEST['commentrightPhoto'])){
            $hComments .= ";rightPhoto: ".escape(input('commentrightPhoto'));
           /*  $wComments .= "\nDriver Side Photo: ".escape(input('commentrightPhoto')); */
        }
        if(!empty($_REQUEST['commentbackPhoto'])){
            $hComments .= ";backPhoto: ".escape(input('commentbackPhoto'));
           /*  $wComments .= "\nBack Photo: ".escape(input('commentbackPhoto')); */
        }
        if(!empty($_REQUEST['commentleftPhoto'])){
            $hComments .= ";leftPhoto: ".escape(input('commentleftPhoto'));
            /* $wComments .= "\nConductor Side Photo: ".escape(input('commentleftPhoto')); */
        }
        if(!empty($_REQUEST['commentopenBonnet'])){
            $hComments .= ";openBonnet: ".escape(input('commentopenBonnet'));
            /* $wComments .= "\nEngine Photo: ".escape(input('commentopenBonnet')); */
        }

        if(!empty($hComments)){
            $dataStatus['comment'] = $hComments;
            /* $dataStatus['wcomment'] .= "\n\nBelow are the specific comments:\n".$wComments; */
        }

        $comment = base64_encode($dataStatus['comment']);
        $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
        $dataStatus['comment']= $comment;

        $comment = base64_encode(escape(input('summary')));
        $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
        $dataStatus['wcomment']= $comment;
        
        

        $status = Database::table('fleetmaintainancerecords')->where('id',$recordid)->where('school',$user->school)->where('branch',$user->branch)->update($dataStatus);
        $check = Database::table('fleetmaintainancerecords')->where('id',$recordid)->where('lastupdate','!=', $getrecord->lastupdate)->first();
        if(!empty($check)){

            //send message to superadmin 1

            $fleet = Database::table("fleet")->where("id", $getrecord->car)->first();
            $createdby = Database::table("users")->where("id", $getrecord->createdby)->first();
            $createdby = $createdby->fname." ".$createdby->lname;
            $updatedby = Database::table("users")->where("id", $user->id)->first();
            $updatedby = $updatedby->fname." ".$updatedby->lname;

            $message = "*Mainintance Record Updated for ".$fleet->carplate."\n\nPrevious Record:*\n\n*Old Score:* ".$getrecord->score."/310\n*Status 80%-99%:* ".$getrecord->status80to99."/62\n*Status 60%-80%:* ".$getrecord->status60to80."/62\n*Status 40%-60%:* ".$getrecord->status40to60."/62\n*Status 0%-40%:* ".$getrecord->status0to40."/62\n*Status Other:* ".$getrecord->statusOther."/62\n*Created By:* ".$createdby."\n*Date:* ".$getrecord->date."\n\n";

            $message .= "*Updated Record: ".$fleet->carplate."*\n\n*New Score:* ".$dataStatus['score']."/310\n*Status 80%-99%:* ".$dataStatus['status80to99']."/62\n*Status 60%-80%:* ".$dataStatus['status60to80']."/62\n*Status 40%-60%:* ".$dataStatus['status40to60']."/62\n*Status 0%-40%:* ".$dataStatus['status0to40']."/62\n*Status Other:* ".$dataStatus['statusOther']."/62\n*Created By:* ".$createdby."\n*Updated By:* ".$updatedby."\n*Date:* ".date('d-m-Y')."\n\nRegards,\nRCDS - Real Car Driving School";

            $superadmin = Database::table("users")->where("id", 1)->first();

            if (!empty($superadmin->phone)) {
                //success message
                Database::table("usermessages")->insert(array(
                    "receiver" => $superadmin->id, 
                    "type" => "whatsapp", 
                    "contact" => $superadmin->phone,
                    "Subject" => "Mass Update Success",
                    "message" => $message,
                    "scheduled_at" => date("d-m-Y H:i:s"),
                    "sent_by" => $user->id,
                    "school" => $superadmin->school, 
                    "branch" => $superadmin->branch, 
                    "status" => "Pending"
            ));}

            $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

            if (!empty($manager->phone)) {
                //success message
                Database::table("usermessages")->insert(array(
                    "receiver" => $manager->id, 
                    "type" => "whatsapp", 
                    "contact" => $manager->phone,
                    "Subject" => "Mass Update Success",
                    "message" => $message,
                    "scheduled_at" => date("d-m-Y H:i:s"),
                    "sent_by" => $user->id,
                   "school" => $manager->school, 
                    "branch" => $manager->branch, 
                    "status" => "Pending"
            ));}

            return response()->json(responder("success", "Done!", "Record Details Updated Successfully.", "reload()"));
        }else{
            return response()->json(responder("error", "HMM!", "Something went wrong. Please check if all records are selected."));
        }

        /* print_r($dataStatus); */
        
        
    }
    
    /**
     * Delete fleet Maintainance record
     * 
     * @return Json
     */
    public function deletemaintainancerecord() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        if ($user->role == 'staff' && $user->position != 'manager') {
            return response()->json(responder("error", "HMM!", "You are not allowed to delete records. Please contact your manager.","reload()"));
        }

        $recordid = escape(input('recordid'));
        $getrecord = Database::table('fleetmaintainancerecords')->where('id',$recordid)->where('school',$user->school)->where('branch',$user->branch)->first();

        if(!empty($getrecord)){
            
            Database::table('fleetmaintainancerecords')->where('id',$getrecord->id)->where('school',$user->school)->where('branch',$user->branch)->delete();
        
            $check = Database::table('fleetmaintainancerecords')->where('id',$getrecord->id)->first();
            
            if(empty($check)){

                //send message to superadmin 1

                $fleet = Database::table("fleet")->where("id", $getrecord->car)->first();
                $createdby = Database::table("users")->where("id", $getrecord->createdby)->first();
                $createdby = $createdby->fname." ".$createdby->lname;
                $updatedby = Database::table("users")->where("id", $user->id)->first();
                $updatedby = $updatedby->fname." ".$updatedby->lname;

                $message = "*Mainintance Record *Deleted* for ".$fleet->carplate."\n\nPrevious Record:*\n\n*Old Score:* ".$getrecord->score."/310\n*Status 80%-99%:* ".$getrecord->status80to99."/62\n*Status 60%-80%:* ".$getrecord->status60to80."/62\n*Status 40%-60%:* ".$getrecord->status40to60."/62\n*Status 0%-40%:* ".$getrecord->status0to40."/62\n*Status Other:* ".$getrecord->statusOther."/62\n*Created By:* ".$createdby."\n*Date:* ".$getrecord->date."\n*Deleted By:* ".$updatedby."\n\nRCDS - Real Car Driving School.";

                $superadmin = Database::table("users")->where("id", 1)->first();

                if (!empty($superadmin->phone)) {
                    //success message
                    Database::table("usermessages")->insert(array(
                        "receiver" => $superadmin->id, 
                        "type" => "whatsapp", 
                        "contact" => $superadmin->phone,
                        "Subject" => "Mass Update Success",
                        "message" => $message,
                        "scheduled_at" => date("d-m-Y H:i:s"),
                        "sent_by" => $user->id,
                        "school" => $superadmin->school, 
                        "branch" => $superadmin->branch, 
                        "status" => "Pending"
                ));}

                $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

                if (!empty($manager->phone)) {
                    //success message
                    Database::table("usermessages")->insert(array(
                        "receiver" => $manager->id, 
                        "type" => "whatsapp", 
                        "contact" => $manager->phone,
                        "Subject" => "Mass Update Success",
                        "message" => $message,
                        "scheduled_at" => date("d-m-Y H:i:s"),
                        "sent_by" => $user->id,
                        "school" => $manager->school, 
                        "branch" => $manager->branch, 
                        "status" => "Pending"
                ));}

                return response()->json(responder("success", "Done!", "Record Details Deleted Successfully.", "reload()"));
        }else{
                return response()->json(responder("error", "HMM!", "Something went wrong. Please check if all records are selected."));
            }
        }else{
            return response()->json(responder("error", "HMM!", "Something went wrong. No records found.", "reload()")); 
        }
    }    
}