<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\Database;
use Simcify\File;
use Simcify\Sms;
use Simcify\Mail;
use Simcify\FS;

class Getcommunication{

    /**
     * Get profile view
     * 
     * @return \Pecee\Http\Response
     */
    public function get($userid) {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin') {
            return view('errors/404');
        }
        
        $profile = Database::table('users')->where('branch',$user->branch)->where('school',$user->school)->where('id',$userid)->first();
        if($profile->phone>10){
            $phone = substr($profile->phone,-10);
            $phone = "91".$phone;
        }else{
            $phone = "91".$profile->phone;
        }
        
        $getchat = Sms::getchat($phone);

        return view('getcommunication', compact("user","profile","getchat"));
    }

}
