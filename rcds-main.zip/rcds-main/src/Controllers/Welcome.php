<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\File;
use Simcify\Landa;
use Simcify\Sms;
use Simcify\Database;
use DotEnvWriter\DotEnvWriter;

class Welcome {

    /**
     * Get Classes view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user = Auth::user();
        
        $date = date("Y-m-d");
        $cdate = date("d-m-Y");

        $attendence = Database::table("staffattendance")->where('branch', $user->branch)->where('school', $user->school)->where('date', $date)->where('userid', $user->id)->first();

        if($attendence==""){
        
        $trainer = Database::table("users")->where('branch', $user->branch)->where('school', $user->school)->where('id', $user->id)->first();
        $alternates = Database::table("users")->where('branch', $user->branch)->where('school', $user->school)->where('role', "instructor")->where('position', "alternate")->get();
  
        return view('welcome', compact("trainer","user","alternates"));
        }
        else{
            redirect(url("Today@get"));
        }

    }

    public function iattend() {

        $user = Auth::user();

        $tz = 'Asia/Kolkata';
        $timestamp = time();
        $dt = new \DateTime("now", new \DateTimeZone($tz)); //first argument "must" be a string
        $dt->setTimestamp($timestamp); //adjust the object to correct timestamp
        $time = $dt->format('H:i:s');
        $date = date("Y-m-d"); 
        $timestamp =  $date." ".$time;

        foreach (input()->post as $field) {
            if ($field->index == "selfie") {
                if (!empty($field->value)) {
                    $selfie = File::upload($field->value, "selfie", array(
                        "source" => "base64",
                        "extension" => "png"
                    ));
                    if ($selfie['status'] == "success") {
                        $selfie=$selfie['info']['name'];
                    }
                }
                continue;
            }
            if ($field->index == "csrf-token") {
                continue;
            }
            if ($field->index == "tid") {
                $tid = $field->value;
                continue;
            }
                continue;
            
        }


        if($user->id==$tid && $user->position!="multi"){

/*             $firstclasstime = Database::table("schedules")->where('branch', $user->branch)->where('school', $user->school)->where("start", "LIKE", "%" . $date . "%")->where('instructor', $user->id)->orderBy('start', true)->first();

            $starttime = date('H:i:s', strtotime($firstclasstime->start)); */

            $starttime = "06:05:00";

            $islate = 0;
            if($starttime<$time){
                $islate = 1;
            }

            $data = array(
                "userid" => $user->id,
                "date" => $date,
                "attendance" => "Present",
                "created_by" => $user->id,
                "created_at" => $timestamp,
                "selfie" => $selfie,
                'islate' => $islate,
                "branch" => $user->branch,
                "school" => $user->school
            );
    
            Database::table("staffattendance")->insert($data);

            if($islate==1){

                $comment = "Late Fine ( ".$time." )";
                $comment = base64_encode($comment);
                $comment = str_replace(array('+','/','='),array('-','_',''),$comment);

                $data2 = array(
                    "id" => $user->id,
                    "amount" => 100,
                    "balance" => 100,
                    "comment" => $comment,
                    "date" => $date,
                    "updateby" => $user->id,
                    "school" => $user->school,
                    "branch" => $user->branch
                );

                Database::table("advance")->insert($data2);

                $staff = Database::table("users")->where('id', $user->id)->first();
                $smessage = "Dear ".$staff->fname.",\n\nKindly note that a fine of *100/- Rs* has been imposed on you because you are late as per the guidelines. Please note this fine will be deducted from you upcoming salary.\n\nKindly follow the given timings and do not disobey the rules to prevent yourself from paying fines.\n\nRegards,\n".env("APP_NAME");
	    	
                if (!empty($staff->phone)) {
                    $send = Sms::africastalking($staff->phone, $smessage);
                    if ($send) { $status = "Sent"; } else { $status = "Failed"; }
                }

                $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();
                $mmessage = "Dear ".$manager->fname.",\n\nMr. ".$staff->fname." has marked his attendence as Present. Kindly note that a fine of *100/- Rs* has been imposed on him because he was late as per the guidelines. Please note this fine will be deducted from his upcoming salary.\n\nKindly help him to follow the given timings.\n\nRegards,\n".env("APP_NAME");

                if (!empty($manager->phone)) {
                    $send = Sms::africastalking($manager->phone, $mmessage);
                    if ($send) { $status = "Sent"; } else { $status = "Failed"; }
                }

                return response()->json(responder("success", "Done!","Attendence Marked Successfully." , "reload()"));

            }else{

                $staff = Database::table("users")->where('id', $user->id)->first();
                $smessage = "Dear ".$staff->fname.",\n\nThankyou for Marking your attendence.\n\nRegards,\n".env("APP_NAME");
	    	
                if (!empty($staff->phone)) {
                    $send = Sms::africastalking($staff->phone, $smessage);
                    if ($send) { $status = "Sent"; } else { $status = "Failed"; }
                }

                $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();
                $mmessage = "Dear ".$manager->fname.",\n\nMr. ".$staff->fname." has marked his attendence as Present.\n\nRegards,\n".env("APP_NAME");

                if (!empty($manager->phone)) {
                    $send = Sms::africastalking($manager->phone, $mmessage);
                    if ($send) { $status = "Sent"; } else { $status = "Failed"; }
                }

                return response()->json(responder("success", "Done!","Attendence Marked Successfully." , "reload()"));
            }

        }else{

            $starttime = "05:50:00";

            $islate = 0;

            if($starttime<$time){
                $islate = 1;
            }

            if($user->position!="multi"){

            $data = array(
                "userid" => $user->id,
                "date" => $date,
                "attendance" => "Absent",
                "created_by" => $tid,
                "created_at" => $timestamp,
                "branch" => $user->branch,
                "school" => $user->school
            );
    
            Database::table("staffattendance")->insert($data);
            }

            $data2 = array(
                "userid" => $tid,
                "date" => $date,
                "attendance" => "Present",
                "created_by" => $user->id,
                "selfie" => $selfie,
                'islate' => $islate,
                "branch" => $user->branch,
                "school" => $user->school
            );
    
            Database::table("staffattendance")->insert($data2); 

            if($islate==1){

                $comment = "Late Fine ( ".$time." )";
                $comment = base64_encode($comment);
                $comment = str_replace(array('+','/','='),array('-','_',''),$comment);

                $data2 = array(
                    "id" => $tid,
                    "amount" => 100,
                    "balance" => 100,
                    "comment" => $comment,
                    "date" => $date,
                    "updateby" => $user->id,
                    "school" => $user->school,
                    "branch" => $user->branch
                );

                Database::table("advance")->insert($data2);

                $staff = Database::table("users")->where('id', $tid)->first();
                $smessage = "Dear ".$staff->fname.",\n\nKindly note that a fine of *100/- Rs* has been imposed on you because you are late as per the guidelines. Please note this fine will be deducted from you upcoming salary.\n\nKindly follow the given timings and do not disobey the rules to prevent yourself from paying fines.\n\nRegards,\n".env("APP_NAME");
	    	
                if (!empty($staff->phone)) {
                    $send = Sms::africastalking($staff->phone, $smessage);
                    if ($send) { $status = "Sent"; } else { $status = "Failed"; }
                }

                $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();
                $mmessage = "Dear ".$manager->fname.",\n\nMr. ".$staff->fname." has marked his attendence as Present. Kindly note that a fine of *100/- Rs* has been imposed on him because he was late as per the guidelines. Please note this fine will be deducted from his upcoming salary.\n\nKindly help him to follow the given timings.\n\nRegards,\n".env("APP_NAME");

                if (!empty($manager->phone)) {
                    $send = Sms::africastalking($manager->phone, $mmessage);
                    if ($send) { $status = "Sent"; } else { $status = "Failed"; }
                }

                return response()->json(responder("success", "Done!","Attendence Marked Successfully." , "reload()"));

            }else{

                $astaff = Database::table("users")->where('id', $user->id)->first();

                $staff = Database::table("users")->where('id', $tid)->first();
                $smessage = "Dear ".$staff->fname.",\n\nThankyou for Marking your attendence.\n\nRegards,\n".env("APP_NAME");
	    	
                if (!empty($staff->phone)) {
                    $send = Sms::africastalking($staff->phone, $smessage);
                    if ($send) { $status = "Sent"; } else { $status = "Failed"; }
                }

                $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();
                $mmessage = "Dear ".$manager->fname.",\n\nMr. ".$staff->fname." has marked his attendence as Present and ".$astaff->fname." has been marked as Absent.\n\nRegards,\n".env("APP_NAME");

                if (!empty($manager->phone)) {
                    $send = Sms::africastalking($manager->phone, $mmessage);
                    if ($send) { $status = "Sent"; } else { $status = "Failed"; }
                }

                return response()->json(responder("success", "Done!","Attendence Marked Successfully." , "reload()"));
            }

        }
        
        return response()->json(responder("error", "Error!","Please contact Manager." , "reload()"));
    }

}