<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\File;
use Simcify\Landa;
use Simcify\Sms;
use Simcify\Database;
use DotEnvWriter\DotEnvWriter;

class Classes {

    /**
     * Get Classes view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user = Auth::user();
        if ($user->role != 'instructor') {
            return view('errors/404');
          }
        $date = date("Y-m-d");
        $cdate = date("d-m-Y");
        $classes = Database::table('users')->leftJoin('attendance','users.id','attendance.id')->leftJoin('invoices','users.id','invoices.student')->rightJoin('schedules','users.id','schedules.student')->where("users`.`branch", $user->branch)->where("users`.`school", $user->school)->where("users`.`role","student")->where("users`.`isWaiting",0)->where("attendance`.`date", $date)->where("schedules`.`start", "LIKE", "%" . $date . "%")->where("schedules`.`instructor",$user->id)->where("schedules`.`status","!=","Complete")->where("attendance`.`status", 0)->where("attendance`.`isstarted", 1)->first("`users.fname`", "`users.lname`", "`users.avatar`", "`attendance.status`", "`attendance.lastupdate`", "`attendance.starttime`", "`attendance.endtime`", "`attendance.date`","`invoices.amount`","`invoices.amountpaid`","`schedules.instructor`","`schedules.student`","`schedules.course`","`schedules.start`","schedules.id","`schedules.status` as schedulestatus");
  
            $completed = Database::table('schedules')->where('student', $classes->student)->where('status', "Complete")->count("id", "total")[0]->total;
            $total = Database::table('schedules')->where('student', $classes->student)->count("id", "total")[0]->total;
        
        $trainingitems = Database::table('attendance')->where('id', $classes->student)->get();
        foreach($trainingitems as $items){
            if($items->trainingitems!=""){
            $ttrainingitem .= $items->trainingitems.",";
            }
        }
        $lesson1 = explode(',',$ttrainingitem);
        $lesson = array_unique($lesson1);
        $k=1;
        for($i=0;$i<count($lesson1);$i++){
            if($lesson[$i]!=""){
            $clessonDetails = Database::table('practicallessons')->where('id', $lesson[$i])->first();
            $classes->completeslesson .= "<label>".$k.": ".$clessonDetails->name.": ".$clessonDetails->description."</label><br>";
            $k++;
            }
        }

        $j=1;
        $clessonDetails = Database::table('practicallessons')->get();
        foreach($clessonDetails as $clesson){
            $com=0;
            for($i=0;$i<count($lesson1);$i++){
                if($clesson->id==$lesson[$i]){
                $com=1;
                }
            }
            if($com==0){
                $classes->pendinglesson .= "<label>".$j.": ".$clesson->name.": ".$clesson->description."</label><br>";
                $j++;
            }
        }

        $tlcomplete = $k-1;
        $tlpending = $j-1;

        $payment = $classes->amount - $classes->amountpaid;
        if($payment !=0){
            $paymentstatus = $payment."/- Rs Pending";
        }else{
            $paymentstatus = "Full Paid";
        }
        $courses = Database::table("courses")->where('id', $classes->course)->first();
        $edate = date("M d, Y ").$classes->endtime;
        $sdate = date("M d, Y ").$classes->starttime;
        $plessons = Database::table("practicallessons")->where('status', 1)->get();
  
        if($classes->isstarted==1){
        return view('classes', compact("classes","user","invoices","date","cdate","courses","paymentstatus","edate","sdate","plessons","tlcomplete","tlpending","completed","total"));
        }else{
        redirect(url("Today@get"));
        }
    }


}