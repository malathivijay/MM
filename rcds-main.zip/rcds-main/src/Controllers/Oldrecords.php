<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\Database;
use Simcify\File;
use Simcify\Sms;
use Simcify\Mail;
use Simcify\FS;

class Oldrecords{

    /**
     * Get students view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user = Auth::user();
        if ($user->role != 'superadmin') {
            return view('errors/404');
        }
        
        $license = Database::table('license')->where(array('status' => 0))->get();

        foreach ($license as $licenses) {
            $udpate = Database::table('users')->where('id', $licenses->updateby)->first();
            $licenses->updatedby = $udpate->fname." ".$udpate->lname;

            $data = str_replace(array('-','_'),array('+','/'),$licenses->comment);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $licenses->comment = base64_decode($data);

            $data = str_replace(array('-','_'),array('+','/'),$licenses->number);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $licenses->number = base64_decode($data);

        }

        return view('oldrecords', compact("user", "license"));
    }

}
