<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\File;
use Simcify\Database;
use DotEnvWriter\DotEnvWriter;
use Simcify\Sms;

class Amdashboard {

    /**
     * Get settings view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user      = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $error = 1;
        if ($user->role == 'staff') {
            if ($user->position == 'amanager') {
                $error = 0;
            }elseif($user->position = 'manager') {
                $error = 0;
            }
        }

        if($user->role == 'staff' && $errro==1){
            return view('errors/404');
        }

        //get issues

        $goings = Database::table('reportedissues')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
        ))->get();

        $iNew = 0;
        $iProcessing = 0;
        $iResolved = 0;

        foreach ($goings as $going) {
            if($going->status=="New") {
                $iNew += 1;
            }elseif($going->status=="Processing") {
                $iProcessing += 1;
            }elseif($going->status=="Resolved") {
                $iResolved += 1;
            }
        }

        //get fleet scoring
        $fleets = Database::table('fleet')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
        ))->get();

        foreach($fleets as $fleet){
            $fleetrecord = Database::table('fleetmaintainancerecords')->where(array(
                'school' => $user->school,
                'branch' => $user->branch,
                "car" => $fleet->id
            ))->first();

            $fleet->score = $fleetrecord->score;
            $fleet->status80to99 = $fleetrecord->status80to99;
            $fleet->status60to80 = $fleetrecord->status60to80;
            $fleet->status40to60 = $fleetrecord->status40to60;
            $fleet->status0to40 = $fleetrecord->status0to40;
            $fleet->statusOther = $fleetrecord->statusOther;
            $fleet->date = $fleetrecord->date;
        }
        
        return view('amdashboard', compact("user",'iNew','iProcessing','iResolved','fleets'));
    }

    /**
     * New Fuel Expenses
     * 
     * @return Json
     */
    public function fuelexpenses() {
        $user = Auth::user();
        $date = escape(input('date'));
        $car = Database::table('fleet')->where("id", escape(input('fleet')))->first();
        $data = array(
            "date" => $date,
            "car" => escape(input('fleet')),
            "recordby" => $user->id,
            "branch" => $user->branch,
            "school" => $user->school
        );
        foreach (input()->post as $field) {
            if ($field->index == "fuel") {
                if (!empty($field->value)) {
                    $fuel = File::upload($field->value, "fuel", array(
                        "source" => "base64",
                        "extension" => "png"
                    ));
                    if ($fuel['status'] == "success") {
                        $data['photo']=$fuel['info']['name'];
                    }
                }
                continue;
            }
            if ($field->index == "odo") {
                if (!empty($field->value)) {
                    $odo = File::upload($field->value, "odo", array(
                        "source" => "base64",
                        "extension" => "png"
                    ));
                    if ($odo['status'] == "success") {
                        $data['odo']=$odo['info']['name'];
                    }
                }
                continue;
            }
            if ($field->index == "csrf-token") {
                continue;
            }
            if ($field->index == "type") {
                if($field->value=="cng"){
                    $data['type']= 1;
                }elseif($field->value=="petrol"){
                    $data['type']= 2;
                }else{
                    return response()->json(responder("error", "Oops", "Incorrect fuel option selected"));
                }
                /* Database::table('fuel')->where("date", $date)->update(array(
                    $field->index => $field->value
                )); */
                continue;
            }
            if ($field->index == "amount") {
                if($field->value>0){
                /* Database::table('fuel')->where("date", $date)->update(array(
                    $field->index => escape($field->value)
                )); */
                $data['amount']= escape($field->value);
                }else{
                    return response()->json(responder("error", "Oops", "Incorrect fuel Amount selected"));
                }
                continue;
            }
            if ($field->index == "reading") {
                if($field->value>0){
                $data['reading']= escape($field->value);
                }else{
                    return response()->json(responder("error", "Oops", "Incorrect Reading"));
                }
                continue;
            }
            if ($field->index == "comment") {
                if($field->value!=""){
                /* Database::table('fuel')->where("date", $date)->update(array(
                    $field->index => escape($field->value)
                )); */
                $comment = base64_encode($field->value);
                $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
                $data['comment']= $comment;
            }
                continue;
            }
            
        }
        Database::table('fuel')->insert($data);
        $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();
        $instructor = Database::table("users")->where("id", $user->id)->where("school", $user->school)->where("branch", $user->branch)->first();
        $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
        if(strlen($instructor->phone)>10){
			$iphone = substr($instructor->phone,-10);
		}
		else{
			$iphone = $instructor->phone;
		}
        $managernotify = "Dear ".$manager->fname.",\n\nA new expense record:\n\nCAR: ".$car->carplate."\nFuel Type: ".strtoupper(escape(input('type')))."\nAmount: ".money($data['amount'])."\nODO: ".$data['reading']."\n\n".env("APP_NAME");

        $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
        if (!empty($manager->phone)) {
	        $send = Sms::africastalking($manager->phone, $managernotify);
            if ($send) {
                return response()->json(responder("success", "Done", "Fuel Expenses Successfully updated and the manager has been notified", "reload()"));
            } else { 
                return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
            }
    	}

        return response()->json(responder("success", "Alright", "Fuel Expenses Successfully updated", "reload()"));
    }

    /**
     * Delete Fuel Expenses
     * 
     * @return Json
     */
    public function deletefuelexpenses() {
        $user = Auth::user();
        $fuelid = escape(input('fuelid'));
        $fuel = Database::table('fuel')->where("id", $fuelid)->where("branch", $user->branch)->where("school", $user->school)->first();
        $car = Database::table('fleet')->where("id", $fuel->car)->where("branch", $user->branch)->where("school", $user->school)->first();
        if(!empty($fuel->photo)){
            File::delete($fuel->photo, "fuel");
        }
        if(!empty($fuel->odo)){
            File::delete($fuel->odo, "odo");
        }
        Database::table("fuel")->where("id", $fuelid)->where("branch", $user->branch)->where("school", $user->school)->delete();

        if($fuel->type==1){
            $type= "CNG";
        }elseif($fuel->type==2){
            $type= "Petrol";
        }

        $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

        $managernotify = "Dear ".$manager->fname.",\n\nAn expense record has been deleted:\n\nCAR: ".$car->carplate."\nFuel Type: ".strtoupper($type)."\nAmount: ".money($fuel->amount)."\nDate: ".$fuel->date."\n\n".env("APP_NAME");

        $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
        if (!empty($manager->phone)) {
	        $send = Sms::africastalking($manager->phone, $managernotify);
            if ($send) {
                return response()->json(responder("success", "Done", "Fuel Expenses Successfully deleted and the manager has been notified", "reload()"));
            } else { 
                return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
            }
    	}

        return response()->json(responder("success", "Alright", "Fuel Expenses Successfully deleted", "reload()"));
    }
    

    /**
     * New Other Expenses
     * 
     * @return Json
     */
    public function otherexpenses() {
        $user = Auth::user();
        $date = escape(input('date'));
        if(input('fleet')=="office"){
            $cars = 0;
        }else{
            $car = Database::table('fleet')->where("id", escape(input('fleet')))->first();
            $cars = escape(input('fleet'));
        }
        $data = array(
            "date" => $date,
            "car" => $cars,
            "recordby" => $user->id,
            "branch" => $user->branch,
            "school" => $user->school
        );
        foreach (input()->post as $field) {
            if ($field->index == "other") {
                if (!empty($field->value)) {
                    $other = File::upload($field->value, "other", array(
                        "source" => "base64",
                        "extension" => "png"
                    ));
                    if ($other['status'] == "success") {
                        $data['photo']=$other['info']['name'];
                    }
                }
                continue;
            }
            if ($field->index == "csrf-token") {
                continue;
            }
            if ($field->index == "type") {
                
                $data['type']= escape($field->value);
                
                continue;
            }
            if ($field->index == "amount") {
                if($field->value>0){
                $data['amount']= escape($field->value);
                }else{
                    return response()->json(responder("error", "Oops", "Incorrect Expenses Amount selected"));
                }
                continue;
            }
            if ($field->index == "comment") {
                if($field->value!=""){
                    $comment = base64_encode($field->value);
                    $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
                    $data['comment']= $comment;
            }
                continue;
            }
            
        }
        Database::table('expenses')->insert($data);
        $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();
        $instructor = Database::table("users")->where("id", $user->id)->where("school", $user->school)->where("branch", $user->branch)->first();
        if(strlen($instructor->phone)>10){
			$iphone = substr($instructor->phone,-10);
		}
		else{
			$iphone = $instructor->phone;
		}

        if(input('fleet')=="office"){
            $exp = "Expense: Office";
        }else{
            $exp = "CAR: ".$car->carplate;
        }

        $managernotify = "Dear ".$manager->fname.",\n\nA new expense record:\n\n".$exp."\nType: ".strtoupper(escape(input('type')))."\nAmount: ".money($data['amount'])."\n\n".env("APP_NAME");

        $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
        if (!empty($manager->phone)) {
	        $send = Sms::africastalking($manager->phone, $managernotify);
            if ($send) {
                return response()->json(responder("success", "Done", "Expenses Successfully updated and the manager has been notified", "reload()"));
            } else { 
                return response()->json(responder("error", "HMM!", "Something went wrong. Not able to notify the manager on WhatsApp","reload()"));
            }
    	}

        return response()->json(responder("success", "Alright", "Fuel Expenses Successfully updated", "reload()"));
    }

    /**
     * Delete Other Expenses
     * 
     * @return Json
     */
    public function deleteotherexpenses() {
        $user = Auth::user();
        $expenseid = escape(input('expenseid'));
        $expense = Database::table('expenses')->where("id", $expenseid)->where("branch", $user->branch)->where("school", $user->school)->first();
        
        if(!empty($expense->photo)){
            File::delete($expense->photo, "expense");
        }

        Database::table("expenses")->where("id", $expenseid)->where("branch", $user->branch)->where("school", $user->school)->delete();

        if($expense->car==0){
            $exp = "Expense: Office";
        }else{
            $car = Database::table('fleet')->where("id", $expense->car)->where("branch", $user->branch)->where("school", $user->school)->first();
            $exp = "CAR: ".$car->carplate;
        }

        $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

        $managernotify = "Dear ".$manager->fname.",\n\nAn expense record has been deleted:\n\n".$exp."\nType: ".strtoupper($expense->type)."\nAmount: ".money($expense->amount)."\nDate: ".$expense->date."\n\n".env("APP_NAME");

        $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
        if (!empty($manager->phone)) {
	        $send = Sms::africastalking($manager->phone, $managernotify);
            if ($send) {
                return response()->json(responder("success", "Done", "Expenses Successfully deleted and the manager has been notified", "reload()"));
            } else { 
                return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
            }
    	}

        return response()->json(responder("success", "Alright", "Expenses Successfully deleted", "reload()"));
    }

    /**
     * New Servcie Record
     * 
     * @return Json
     */
    public function servicerecords() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $data = array(
            "recordby" => $user->id,
            "branch" => $user->branch,
            "school" => $user->school
        );
        foreach (input()->post as $field) {
            if ($field->index == "other") {
                if (!empty($field->value)) {
                    $other = File::upload($field->value, "other", array(
                        "source" => "base64",
                        "extension" => "png"
                    ));
                    if ($other['status'] == "success") {
                        $data['servicekm']=$other['info']['name'];
                    }
                }
                continue;
            }
            if ($field->index == "reading") {
                if($field->value>0){
                $data['reading']= escape($field->value);
                }else{
                    return response()->json(responder("error", "Oops", "Incorrect ODO Reading"));
                }
                continue;
            }
            if ($field->index == "csrf-token") {
                continue;
            }
            if ($field->index == "date") {
                
                $data['date']= escape($field->value);
                
                continue;
            }
            if ($field->index == "fleet") {
                
                $data['car']= escape($field->value);
                
                continue;
            }
            if ($field->index == "reset") {
                
                $data['iskmreset']= escape($field->value);
                
                continue;
            }
            if ($field->index == "nservicekm") {
                
                if(escape($field->value)>0){
                    $data['nextservicekm'] = escape($field->value);
                }else{
                    $data['nextservicekm'] = $data['reading']+10000;
                }
                continue;
            }
            if ($field->index == "comments") {
                if($field->value!=""){
                    $comment = base64_encode($field->value);
                    $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
                    $data['comments']= $comment;
            }
                continue;
            }
            
        }
        Database::table('servicerecords')->insert($data);
        $car = $data['car'];
        $nextservice = $data['nextservicekm'];
        Database::table('fleet')->where("id", $car)->update(array("nextservice" => $nextservice));
        // $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();
        // $instructor = Database::table("users")->where("id", $user->id)->where("school", $user->school)->where("branch", $user->branch)->first();
        // if(strlen($instructor->phone)>10){
		// 	$iphone = substr($instructor->phone,-10);
		// }
		// else{
		// 	$iphone = $instructor->phone;
		// }

        // if(input('fleet')=="office"){
        //     $exp = "Expense: Office";
        // }else{
        //     $exp = "CAR: ".$car->carplate;
        // }

        // $managernotify = "Dear ".$manager->fname.",\n\nA new expense record:\n\n".$exp."\nType: ".strtoupper(escape(input('type')))."\nAmount: ".money($data['amount'])."\n\n".env("APP_NAME");

        // $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
        // if (!empty($manager->phone)) {
	    //     $send = Sms::africastalking($manager->phone, $managernotify);
        //     if ($send) {
        //         return response()->json(responder("success", "Done", "Expenses Successfully updated and the manager has been notified", "reload()"));
        //     } else { 
        //         return response()->json(responder("error", "HMM!", "Something went wrong. Not able to notify the manager on WhatsApp","reload()"));
        //     }
    	// }

        return response()->json(responder("success", "Alright", "Service Record Successfully Saved.", "reload()"));
    }

    /**
     * Delete Service Records
     * 
     * @return Json
     */
    public function deleteservicerecords() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin') {
            return view('errors/404');
        }
        $servicerecordid = escape(input('servicerecordid'));
        $servicerecord = Database::table('servicerecords')->where("id", $servicerecordid)->where("branch", $user->branch)->where("school", $user->school)->first();
        
        if(!empty($servicerecord->servicekm)){
            File::delete($servicerecord->servicekm, "other");
        }

        Database::table("servicerecords")->where("id", $servicerecordid)->where("branch", $user->branch)->where("school", $user->school)->delete();

        return response()->json(responder("success", "Alright", "Service Record Successfully deleted", "reload()"));
    }


    /**
     * Update Service Records
     * 
     * @return Json
     */

    public function updateservicerecord() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        if(isset($_POST['reading']) && isset($_POST['serviceid'])){

            $reading = escape(input('reading'));
            $serviceid = escape(input('serviceid'));
            
            Database::table('servicerecords')->where("id", $serviceid)->where("branch", $user->branch)->where("school", $user->school)->update(array("reading"=>$reading));

            return response()->json(responder("success", "Done", "Service Record Reading Successfully updated.", "reload()"));  
        }

        if(isset($_POST['comment']) && isset($_POST['serviceid'])){

            $comments = escape(input('comment'));
            $comment = base64_encode($comments);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $serviceid = escape(input('serviceid'));

            Database::table('servicerecords')->where("id", $serviceid)->where("branch", $user->branch)->where("school", $user->school)->update(array("comments"=>$comment));

            return response()->json(responder("success", "Done", "Service Record Comment Successfully updated.", "reload()"));   
        }

        if(isset($_POST['nservicekm']) && isset($_POST['serviceid'])){

            $nservicekm = escape(input('nservicekm'));
            $serviceid = escape(input('serviceid'));
            
            Database::table('servicerecords')->where("id", $serviceid)->where("branch", $user->branch)->where("school", $user->school)->update(array("nextservicekm"=>$nservicekm));

            return response()->json(responder("success", "Done", "Service Record Next Service KM Successfully updated.", "reload()"));  
        }
    }

    /**
     * New Dropout record
     * 
     * @return Json
     */
    public function dropout() {
        $user = Auth::user();
        $date = escape(input('date'));
        $car = Database::table('fleet')->where("id", escape(input('fleet')))->first();
        $data = array(
            "date" => $date,
            "car" => escape(input('fleet')),
            "recordby" => $user->id,
            "branch" => $user->branch,
            "school" => $user->school
        );
        foreach (input()->post as $field) {
            if ($field->index == "drop") {
                if (!empty($field->value)) {
                    $drop = File::upload($field->value, "drop", array(
                        "source" => "base64",
                        "extension" => "png"
                    ));
                    if ($drop['status'] == "success") {
                        $data['photo']=$drop['info']['name'];
                    }
                }
                continue;
            }
            if ($field->index == "csrf-token") {
                continue;
            }
            if ($field->index == "reading") {
                
                $data['reading']= escape($field->value);
                
                continue;
            }
            if ($field->index == "comment") {
                if($field->value!=""){
                    $comment = base64_encode($field->value);
                    $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
                    $data['comment']= $comment;
            }
                continue;
            }
            
        }
        Database::table('dropreading')->insert($data);
        $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();
        $instructor = Database::table("users")->where("id", $user->id)->where("school", $user->school)->where("branch", $user->branch)->first();
        if(strlen($instructor->phone)>10){
			$iphone = substr($instructor->phone,-10);
		}
		else{
			$iphone = $instructor->phone;
		}
        $managernotify = "Dear ".$manager->fname.",\n\nA new drop out record:\n\nCAR: ".$car->carplate."\nReading: ".$data['reading']."\n\n".env("APP_NAME");

        $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
        if (!empty($manager->phone)) {
	        $send = Sms::africastalking($manager->phone, $managernotify);
            if ($send) {
                return response()->json(responder("success", "Done", "Expenses Successfully updated and the manager has been notified", "reload()"));
            } else { 
                return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
            }
    	}

        return response()->json(responder("success", "Alright", "Fuel Expenses Successfully updated", "reload()"));
    }

    /**
     * Delete Dropout Records
     * 
     * @return Json
     */
    public function deletedropout() {
        $user = Auth::user();
        $dropid = escape(input('dropid'));
        $drop = Database::table('dropreading')->where("id", $dropid)->where("branch", $user->branch)->where("school", $user->school)->first();
        
        if(!empty($drop->photo)){
            File::delete($drop->photo, "drop");
        }

        Database::table("dropreading")->where("id", $dropid)->where("branch", $user->branch)->where("school", $user->school)->delete();

        $car = Database::table('fleet')->where("id", $drop->car)->where("branch", $user->branch)->where("school", $user->school)->first();
        $exp = "CAR: ".$car->carplate;

        $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

        $managernotify = "Dear ".$manager->fname.",\n\nA record has been deleted:\n\n".$exp."\nReading: ".$drop->reading."\nDate: ".$drop->date."\n\n".env("APP_NAME");

        $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
        if (!empty($manager->phone)) {
	        $send = Sms::africastalking($manager->phone, $managernotify);
            if ($send) {
                return response()->json(responder("success", "Done", "Drop Record Successfully deleted and the manager has been notified", "reload()"));
            } else { 
                return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
            }
    	}

        return response()->json(responder("success", "Alright", "Drop record Successfully deleted", "reload()"));
    }

    /**
     * Update Expenses
     * 
     * @return Json
     */
    public function updateexpenses() {
        $user = Auth::user();
        
        if(isset($_POST['fuelamount']) && isset($_POST['recordimage'])){

            $amount = escape(input('fuelamount'));
            $photo = escape(input('recordimage'));
            
            if($amount>0 && $photo!=""){
                Database::table('fuel')->where("photo", $photo)->where("branch", $user->branch)->where("school", $user->school)->update(array("amount"=>$amount));

                $fuel = Database::table('fuel')->where("photo", $photo)->where("amount", $amount)->where("branch", $user->branch)->where("school", $user->school)->first();
                $car = Database::table('fleet')->where("id", $fuel->car)->where("branch", $user->branch)->where("school", $user->school)->first();
                if($fuel->type==1){
                    $type= "CNG";
                }elseif($fuel->type==2){
                    $type= "Petrol";
                }

                if($fuel->amount!=""){

                    $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

                    $managernotify = "Dear ".$manager->fname.",\n\nAn expense record has been update:\n\nCAR: ".$car->carplate."\nFuel Type: ".strtoupper($type)."\nAmount: ".money($fuel->amount)."\nDate: ".$fuel->date."\n\n".env("APP_NAME");

                    $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
                    if (!empty($manager->phone)) {
                        $send = Sms::africastalking($manager->phone, $managernotify);
                        if ($send) {
                            return response()->json(responder("success", "Done", "Fuel Expenses Successfully updated and the manager has been notified", "reload()"));
                        } else { 
                            return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager, Not able to send notification.","reload()"));
                        }
                    }
                }else{
                    return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager, Not able to update record","reload()"));
                }

            }else{
                return response()->json(responder("error", "HMM!", "Something went wrong. Incorrect Values.","reload()"));
            }  
        }

        if(isset($_POST['odoreading']) && isset($_POST['odoimage'])){

            $reading = escape(input('odoreading'));
            $odo = escape(input('odoimage'));
            
            if($reading>0 && $odo!=""){
                Database::table('fuel')->where("odo", $odo)->where("branch", $user->branch)->where("school", $user->school)->update(array("reading"=>$reading));

                $fuel = Database::table('fuel')->where("odo", $odo)->where("reading", $reading)->where("branch", $user->branch)->where("school", $user->school)->first();
                $car = Database::table('fleet')->where("id", $fuel->car)->where("branch", $user->branch)->where("school", $user->school)->first();
                if($fuel->type==1){
                    $type= "CNG";
                }elseif($fuel->type==2){
                    $type= "Petrol";
                }

                if($fuel->odo!=""){

                    $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

                    $managernotify = "Dear ".$manager->fname.",\n\nAn ODO reading record has been updated:\n\nCAR: ".$car->carplate."\nODO Reading: ".$fuel->reading."\nFuel Type: ".strtoupper($type)."\nAmount: ".money($fuel->amount)."\nDate: ".$fuel->date."\n\n".env("APP_NAME");

                    $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
                    if (!empty($manager->phone)) {
                        $send = Sms::africastalking($manager->phone, $managernotify);
                        if ($send) {
                            return response()->json(responder("success", "Done", "ODO Reading details Successfully updated and the manager has been notified", "reload()"));
                        } else { 
                            return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager, Not able to send notification.","reload()"));
                        }
                    }
                }else{
                    return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager, Not able to update record","reload()"));
                }

            }else{
                return response()->json(responder("error", "HMM!", "Something went wrong. Incorrect Values.","reload()"));
            } 
        }

        if(isset($_POST['fuelcomment']) && isset($_POST['fuelid'])){

            $comment = escape(input('fuelcomment'));
            $id = escape(input('fuelid'));

            //encoding 
            $comment = base64_encode($comment);
	        $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            
                Database::table('fuel')->where("id", $id)->where("branch", $user->branch)->where("school", $user->school)->update(array("comment"=>$comment));

                $fuel = Database::table('fuel')->where("id", $id)->where("comment", $comment)->where("branch", $user->branch)->where("school", $user->school)->first();
                $car = Database::table('fleet')->where("id", $fuel->car)->where("branch", $user->branch)->where("school", $user->school)->first();
                if($fuel->type==1){
                    $type= "CNG";
                }elseif($fuel->type==2){
                    $type= "Petrol";
                }

                if($fuel->id!=""){

                    $data = str_replace(array('-','_'),array('+','/'),$fuel->comment);
                    $mod4 = strlen($data) % 4;
                    if ($mod4) {
                        $data .= substr('====', $mod4);
                    }
                    $fuel->comment = base64_decode($data);

                    $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

                    $managernotify = "Dear ".$manager->fname.",\n\nA comment for Fuel record has been updated:\n\nCAR: ".$car->carplate."\nODO Reading: ".$fuel->reading."\nFuel Type: ".strtoupper($type)."\nAmount: ".money($fuel->amount)."\nDate: ".$fuel->date."\nNew Comment: ".$fuel->comment."\n\n".env("APP_NAME");

                    $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
                    if (!empty($manager->phone)) {
                        $send = Sms::africastalking($manager->phone, $managernotify);
                        if ($send) {
                            return response()->json(responder("success", "Done", "Fuel Comment details Successfully updated and the manager has been notified", "reload()"));
                        } else { 
                            return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager, Not able to send notification.","reload()"));
                        }
                    }
                }else{
                    return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager, Not able to update record","reload()"));
                }

        }


        if(isset($_POST['expenseamount']) && isset($_POST['expenseimage'])){

            $amount = escape(input('expenseamount'));
            $photo = escape(input('expenseimage'));
            
            if($amount>0 && $photo!=""){
                Database::table('expenses')->where("photo", $photo)->where("branch", $user->branch)->where("school", $user->school)->update(array("amount"=>$amount));

                $expenses = Database::table('expenses')->where("photo", $photo)->where("amount", $amount)->where("branch", $user->branch)->where("school", $user->school)->first();
                if($expenses->car!=0){
                    $car = Database::table('fleet')->where("id", $expenses->car)->where("branch", $user->branch)->where("school", $user->school)->first();
                    $exp = "\n\nCAR: ".$car->carplate;
                }else{
                    $exp = "\n\nOffice Expenses";
                }

                if($expenses->amount!=""){

                    $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

                    $managernotify = "Dear ".$manager->fname.",\n\nAn expense record has been update:".$exp."\nFuel Type: ".strtoupper($expenses->type)."\nAmount: ".money($fuel->amount)."\nDate: ".$expenses->date."\n\n".env("APP_NAME");

                    $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
                    if (!empty($manager->phone)) {
                        $send = Sms::africastalking($manager->phone, $managernotify);
                        if ($send) {
                            return response()->json(responder("success", "Done", "Expense details Successfully updated and the manager has been notified", "reload()"));
                        } else { 
                            return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager, Not able to send notification.","reload()"));
                        }
                    }
                }else{
                    return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager, Not able to update record","reload()"));
                }

            }else{
                return response()->json(responder("error", "HMM!", "Something went wrong. Incorrect Values.","reload()"));
            }  
        }

        if(isset($_POST['expensecomment']) && isset($_POST['expenseid'])){

            $comment = escape(input('expensecomment'));
            $id = escape(input('expenseid'));

            //encoding 
            $comment = base64_encode($comment);
	        $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            
                Database::table('expenses')->where("id", $id)->where("branch", $user->branch)->where("school", $user->school)->update(array("comment"=>$comment));

                $expenses = Database::table('expenses')->where("id", $id)->where("comment", $comment)->where("branch", $user->branch)->where("school", $user->school)->first();
                if($expenses->car!=0){
                    $car = Database::table('fleet')->where("id", $expenses->car)->where("branch", $user->branch)->where("school", $user->school)->first();
                    $exp = "\n\nCAR: ".$car->carplate;
                }else{
                    $exp = "\n\nOffice Expenses";
                }

                if($expenses->id!=""){

                    $data = str_replace(array('-','_'),array('+','/'),$expenses->comment);
                    $mod4 = strlen($data) % 4;
                    if ($mod4) {
                        $data .= substr('====', $mod4);
                    }
                    $expenses->comment = base64_decode($data);

                    $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

                    $managernotify = "Dear ".$manager->fname.",\n\nA comment for expense record has been update:".$exp."\nFuel Type: ".strtoupper($expenses->type)."\nAmount: ".money($fuel->amount)."\nDate: ".$expenses->date."\nNew Comment: ".$expenses->comment."\n\n".env("APP_NAME");

                    $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
                    if (!empty($manager->phone)) {
                        $send = Sms::africastalking($manager->phone, $managernotify);
                        if ($send) {
                            return response()->json(responder("success", "Done", "Expense Comment details Successfully updated and the manager has been notified", "reload()"));
                        } else { 
                            return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager, Not able to send notification.","reload()"));
                        }
                    }
                }else{
                    return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager, Not able to update record","reload()"));
                }

        }
        
        if(isset($_POST['dropoutreading']) && isset($_POST['dropoutimage'])){

            $reading = escape(input('dropoutreading'));
            $photo = escape(input('dropoutimage'));
            
            if($reading>0 && $photo!=""){
                Database::table('dropreading')->where("photo", $photo)->where("branch", $user->branch)->where("school", $user->school)->update(array("reading"=>$reading));

                $drop = Database::table('dropreading')->where("photo", $photo)->where("reading", $reading)->where("branch", $user->branch)->where("school", $user->school)->first();
                $car = Database::table('fleet')->where("id", $fuel->car)->where("branch", $user->branch)->where("school", $user->school)->first();

                if($drop->reading!=""){

                    $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

                    $managernotify = "Dear ".$manager->fname.",\n\nAn ODO reading record has been updated:\n\nCAR: ".$car->carplate."\nODO Reading: ".$drop->reading."\nRecord Type: Drop Reading\nDate: ".$drop->date."\n\n".env("APP_NAME");

                    $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
                    if (!empty($manager->phone)) {
                        $send = Sms::africastalking($manager->phone, $managernotify);
                        if ($send) {
                            return response()->json(responder("success", "Done", "ODO Reading details Successfully updated and the manager has been notified", "reload()"));
                        } else { 
                            return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager, Not able to send notification.","reload()"));
                        }
                    }
                }else{
                    return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager, Not able to update record","reload()"));
                }

            }else{
                return response()->json(responder("error", "HMM!", "Something went wrong. Incorrect Values.","reload()"));
            } 
        }

        if(isset($_POST['dropcomment']) && isset($_POST['dropid'])){

            $comment = escape(input('dropcomment'));
            $id = escape(input('dropid'));

            //encoding 
            $comment = base64_encode($comment);
	        $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            
                Database::table('dropreading')->where("id", $id)->where("branch", $user->branch)->where("school", $user->school)->update(array("comment"=>$comment));

                $drop = Database::table('dropreading')->where("id", $id)->where("comment", $comment)->where("branch", $user->branch)->where("school", $user->school)->first();
                $car = Database::table('fleet')->where("id", $fuel->car)->where("branch", $user->branch)->where("school", $user->school)->first();

                if($drop->id!=""){

                    $data = str_replace(array('-','_'),array('+','/'),$drop->comment);
                    $mod4 = strlen($data) % 4;
                    if ($mod4) {
                        $data .= substr('====', $mod4);
                    }
                    $drop->comment = base64_decode($data);

                    $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

                    $managernotify = "Dear ".$manager->fname.",\n\nA comment on a record has been updated:\n\nCAR: ".$car->carplate."\nODO Reading: ".$drop->reading."\nRecord Type: Drop Reading\nDate: ".$drop->date."\nNew Comment: ".$drop->comment."\n\n".env("APP_NAME");

                    $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
                    if (!empty($manager->phone)) {
                        $send = Sms::africastalking($manager->phone, $managernotify);
                        if ($send) {
                            return response()->json(responder("success", "Done", "Dropout Comment details Successfully updated and the manager has been notified", "reload()"));
                        } else { 
                            return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager, Not able to send notification.","reload()"));
                        }
                    }
                }else{
                    return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager, Not able to update record","reload()"));
                }

        }

            return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));

    }

}