<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\Database;
use Simcify\File;
use Simcify\Sms;
use Simcify\Mail;
use Simcify\FS;

class Profile{

    /**
     * Get profile view
     * 
     * @return \Pecee\Http\Response
     */
    public function get($userid) {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
          }
        $enrollments = $invoices = $payments = array();
        $date = date("Y-m-d");
        $profile = Database::table('users')->where('id',$userid)->first();
        if ($profile->role!="student" && $user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        if ($profile->branch!=$user->branch && $profile->school!=$user->school){
            return view('errors/404');
        }
        $branches =  Database::table('branches')->where('school',$user->school)->get();
        $courses = Database::table('courses')->where('school',$user->school)->where('status',"Available")->get();
        $instructors = Database::table('users')->where(['role'=>'instructor','branch'=>$user->branch,'school'=>$user->school])->get();
        $fleets = Database::table('fleet')->where('branch',$user->branch)->get();
        $timeline = Database::table('timeline')->where('user',$userid)->get();
        $students = Database::table('users')->where(['role'=>'student','branch'=>$user->branch,'school'=>$user->school])->get();
        if ($profile->role == "student") {
            
            $enrollments = Database::table('coursesenrolled')->leftJoin('courses','coursesenrolled.course','courses.id')->where('student',$profile->id)->orderBy('coursesenrolled.id', false)->get("`courses.name`", "`courses.duration`", "`courses.period`", "`coursesenrolled.created_at`", "`coursesenrolled.id`", "`coursesenrolled.course`", "`coursesenrolled.total_practical`", "`coursesenrolled.total_theory`", "`coursesenrolled.completed_theory`", "`coursesenrolled.completed_practical`");
            $payments = Database::table('payments')->leftJoin('invoices','payments.invoice','invoices.id')->where('payments`.`student',$profile->id)->orderBy('payments.id', false)->get("`payments.id`", "`payments.created_at`", "`payments.amount`", "`payments.method`", "`payments.invoice`", "`invoices.reference`");
            $invoices = Database::table("invoices")->where("student", $profile->id)->orderBy('id', false)->get();

            $getclass = Database::table('attendance')->where('id', $profile->id)->where('status', 2)->get();

            foreach($getclass as $class){
                $lesson = explode(',',$class->trainingitems);
                $k=1;
                for($i=0;$i<count($lesson);$i++){
                    $clessonDetails = Database::table('practicallessons')->where('id', $lesson[$i])->first();
                    $class->summary .= $k.". ".$clessonDetails->name.": ".$clessonDetails->description."<br>";
                    $k++;
                }

                $tname = Database::table('users')->leftJoin('schedules','users.id','schedules.instructor')->where("schedules`.`start", "LIKE", "%" . $class->$date . "%")->where("schedules`.`status","Complete")->where('schedules`.`student',$class->id)->first("`users.fname`","`users.lname`");

                $class->trainer = $tname->fname." ".$tname->lname;

                $dt1 = date('h:i:s', strtotime($class->starttime));
                $dt2 = date('h:i:s', strtotime($class->endtime));
                $dt1 = new \DateTime($dt1);
                $dt2 = new \DateTime($dt2);
                $mtime = $dt1->diff($dt2)->format('%i');
                $htime = $dt1->diff($dt2)->format('%h');
                if($htime>0){
                    $mtime += $htime*60;
                }
                $class->expectedendtime = $mtime;

                $dt3 = date('h:i:s', strtotime($class->setendtime));
                $dt3 = new \DateTime($dt3);
                $mtime = $dt1->diff($dt3)->format('%i');
                $htime = $dt1->diff($dt3)->format('%h');
                if($htime>0){
                    $mtime += $htime*60;
                }
                $class->realendtime = $mtime;

            }

        }
        $notes = Database::table('notes')->leftJoin('users','notes.note_by','users.id')->where('note_for',$profile->id)->orderBy('notes.id', false)->get("`users.fname`", "`users.lname`", "`users.avatar`", "`notes.created_at`", "`notes.note`", "`notes.id`", "`notes.note_by`");
        $attachments = Database::table('attachments')->leftJoin('users','attachments.uploaded_by','users.id')->where('attachment_for',$profile->id)->orderBy('attachments.id', false)->get("`users.fname`", "`users.lname`", "`users.avatar`", "`attachments.created_at`", "`attachments.name`", "`attachments.attachment`", "`attachments.id`", "`attachments.uploaded_by`");

        if($user->role=="superadmin" || $user->role=="admin"){

        $accountdetails = Database::table('accountdetails')->where('branch',$user->branch)->where('school',$user->school)->where('id',$userid)->first();
        $details = Database::table('users')->where('id',$accountdetails->updatedby)->first();
        $accountdetails->updateby = $details->fname." ".$details->lname;

        }

        if($profile->role!="student"){
            $advance = Database::table("advance")->where("id", $profile->id)->where('branch',$user->branch)->where('school',$user->school)->where("ispaid", 0)->get();
            foreach($advance as $adv){
                $details = Database::table('users')->where('id',$adv->updateby)->first();
                $adv->updatedby = $details->fname." ".$details->lname;

                $data = str_replace(array('-','_'),array('+','/'),$adv->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $adv->comment = base64_decode($data); 

                $staffattend = Database::table("staffattendance")->where("userid", $adv->id)->where('branch',$user->branch)->where('school',$user->school)->where("date", $adv->date)->first();

                $adv->selfie = $staffattend->selfie;
            }
            $incentive = Database::table("incentive")->where("id", $profile->id)->where('branch',$user->branch)->where('school',$user->school)->where("ispaid", 0)->get();
            foreach($incentive as $inc){
                $details = Database::table('users')->where('id',$inc->updateby)->first();
                $inc->updatedby = $details->fname." ".$details->lname;

                $data = str_replace(array('-','_'),array('+','/'),$inc->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $inc->comment = base64_decode($data); 
            }
            $lastMonth = date("Y-m-d", strtotime ( 'first day of previous month' , strtotime ( $date ) )) ;
            $month = date('m', strtotime($lastMonth));
            $payslips = Database::table("payslips")->where("userid", $profile->id)->where('branch',$user->branch)->where('school',$user->school)->where('month',$month)->get();
            foreach($payslips as $payslip){
                $details = Database::table('users')->where('id',$payslip->created_by)->first();
                $payslip->createdby = $details->fname." ".$details->lname;
                $fdate = $payslip->year."-".$payslip->month;
                $payslip->fmonth = date('F', strtotime($fdate));
            }
            $staffattendance = Database::table("staffattendance")->where("userid", $profile->id)->where('branch',$user->branch)->where('school',$user->school)->where("marked", 0)->get();
            foreach($staffattendance as $attendance){
                $data = str_replace(array('-','_'),array('+','/'),$attendance->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $attendance->comment = base64_decode($data); 

                $details = Database::table('users')->where('id',$attendance->created_by)->first();
                $attendance->createdby = $details->fname." ".$details->lname;
            }
        }
        
        return view('profile', compact("user", "profile","branches","enrollments","courses","notes","attachments","invoices","payments","instructors","fleets","students","timeline","getclass","getchat","accountdetails","date","advance","payslips","staffattendance","incentive"));
    }

    /**
     * Update profile
     * 
     * @return Json
     */
    public function update() {
        if (!empty(input("date_of_birth"))) {
            $date_of_birth = date('Y-m-d', strtotime(input("date_of_birth")));
        }else{
            $date_of_birth = '';
        }
        $data = array(
            "fname" => escape(input("fname")),
            "lname" => escape(input("lname")),
            "phone" => escape(input("phone")),
            "alternatephone" => escape(input("altphone")),
            "email" => escape(input("email")),
            "address" => escape(input("address")),
            "location" => escape(input("location")),
            "date_of_birth" => $date_of_birth,
            "gender" => escape(input("gender"))
        );
        if (!empty(input("permissions"))) {
            $data['permissions'] = escape(input("permissions"));
            $data['branch'] =  escape(input("branch"));
        }
        Database::table("users")->where("id", input("userid"))->update($data);
        return response()->json(responder("success", "Alright", "Profile successfully updated", "reload()"));
    }

    /**
     * Add Account Details
     * 
     * @return Json
     */
    public function addaccountdetails() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin') {
            return view('errors/404');
        }

        if(!is_int("salary") && input("salary")<=0){
            return response()->json(responder("error", "HMM!", "Incorrect Salary Amount" , "reload()"));
        }

        $profile = Database::table('users')->where('id',escape(input('userid')))->where('branch',$user->branch)->where('school',$user->school)->first();

        if($profile=""){
            return response()->json(responder("error", "HMM!", "Something went wrong. User Profile not found","reload()"));
        }

        $data = array(
            "id" => escape(input("userid")),
            "salary" => escape(input("salary")),
            "bankname" => escape(input("bankname")),
            "accountnumber" => escape(input("accountnumber")),
            "ifsccode" => escape(input("ifsccode")),
            "branchaddress" => escape(input("branchaddress")),
            "updatedby" => $user->id,
            "branch" => $user->branch,
            "school" => $user->school
        );
        Database::table("accountdetails")->insert($data);

        $update = Database::table("accountdetails")->where("id", escape(input("userid")))->first();

        if($data['salary']!=$update->salary || $data['bankname']!=$update->bankname || $data['accountnumber']!=$update->accountnumber || $data['ifsccode']!=$update->ifsccode || $data['branchaddress']!=$update->branchaddress || $data['updatedby']!=$update->updatedby){
            return response()->json(responder("error", "HMM!", "Something went wrong. Not able to update data.","reload()"));
        }
        return response()->json(responder("success", "Alright", "Account Details successfully updated", "reload()"));
    }

    /**
     * Update Account
     * 
     * @return Json
     */
    public function updateaccount() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin') {
            return view('errors/404');
        }

        if(!is_int("salary") && input("salary")<=0){
            return response()->json(responder("error", "HMM!", "Incorrect Salary Amount" , "reload()"));
        }

        $profile = Database::table('users')->where('id',escape(input('userid')))->where('branch',$user->branch)->where('school',$user->school)->first();

        if($profile=""){
            return response()->json(responder("error", "HMM!", "Something went wrong. User Profile not found","reload()"));
        }

        $data = array(
            "salary" => escape(input("salary")),
            "bankname" => escape(input("bankname")),
            "accountnumber" => escape(input("accountnumber")),
            "ifsccode" => escape(input("ifsccode")),
            "branchaddress" => escape(input("branchaddress")),
            "updatedby" => $user->id
        );
        Database::table("accountdetails")->where("id", escape(input("userid")))->update($data);
        $update = Database::table("accountdetails")->where("id", escape(input("userid")))->first();
        if($data['salary']!=$update->salary || $data['bankname']!=$update->bankname || $data['accountnumber']!=$update->accountnumber || $data['ifsccode']!=$update->ifsccode || $data['branchaddress']!=$update->branchaddress || $data['updatedby']!=$update->updatedby){
            return response()->json(responder("error", "HMM!", "Something went wrong. Not able to update data.","reload()"));
        }
        return response()->json(responder("success", "Alright", "Account Details successfully updated", "reload()"));
    }

    /**
     * Set Student Status as Started/OnGoing
     * 
     * @return Json
     */

    public function setongoing() {
        $user = Auth::user();
        $data = array(
            "isWaiting" => 0
        );
        Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", input("userid"))->update($data);
        return response()->json(responder("success", "Alright", "Student details successfully updated", "reload()"));
    }

    /**
     * Set Student Status as Waiting
     * 
     * @return Json
     */

    public function setwaiting() {
        $user = Auth::user();
        $data = array(
            "isWaiting" => 1
        );
        Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", input("userid"))->update($data);
        return response()->json(responder("success", "Alright", "Student details successfully updated", "reload()"));
    }

    /**
     * Set Student Status as Started/OnGoing
     * 
     * @return Json
     */

    public function setcancelled() {
        $user = Auth::user();
        $data = array(
            "isWaiting" => 2
        );
        Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", input("userid"))->update($data);
        return response()->json(responder("success", "Alright", "Student details successfully updated", "reload()"));
    }

    /**
     * Set Student Status as Started/OnGoing
     * 
     * @return Json
     */

    public function setcompleted() {
        $user = Auth::user();
        $data = array(
            "isWaiting" => 3
        );
        Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", input("userid"))->update($data);
        return response()->json(responder("success", "Alright", "Student details successfully updated", "reload()"));
    }
    
        /**
     * Set Student Status as Started/OnGoing
     * 
     * @return Json
     */

    public function setdefaulter() {
        $user = Auth::user();
        $data = array(
            "defaulter" => 1
        );
        Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", input("userid"))->update($data);
        return response()->json(responder("success", "Alright", "Student details successfully updated", "reload()"));
    }

        /**
     * Set Student Status as Started/OnGoing
     * 
     * @return Json
     */

    public function resetdefaulter() {
        $user = Auth::user();
        $data = array(
            "defaulter" => 0
        );
        Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", input("userid"))->update($data);
        return response()->json(responder("success", "Alright", "Student details successfully updated", "reload()"));
    }


    /**
     * Delete user account
     * 
     * @return Json
     */
    public function delete() {
        $user = Auth::user();
        $account = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("school", input("userid"))->get();
        if (!empty($account->avatar)) {
            File::delete($account->avatar, "avatar");
        }
        Database::table("users")->where("id", input("userid"))->delete();
        return response()->json(responder("success", "User Deleted", "User account successfully deleted", "redirect('".url('')."', true)"));
    }
    
    
    /**
     * Send Email to user
     * 
     * @return Json
     */
    public function sendemail() {
        $user = Database::table("users")->where("id", input("userid"))->first();
        $send   = Mail::send($user->email, input("subject"), array(
            "message" => input("message")
        ), "basic");
        
        if ($send) {
            return response()->json(responder("success", "Alright", "Email successfully sent", "reload()"));
        } else {
            return response()->json(responder("error", "Hmm!", $send->ErrorInfo));
        }
    }
    
    /**
     * Send SMS to user
     * 
     * @return Json
     */
    public function sendsms() {
        $user = Database::table("users")->where("id", input("userid"))->first();
        if (empty($user->phone)) {
            return response()->json(responder("error", "Hmm!", "This user has not set it's phone number."));
        }
        
        if (env("DEFAULT_SMS_GATEWAY") == "africastalking") {
            if (empty(env("AFRICASTALKING_USERNAME"))) {
                return response()->json(responder("error", "Hmm!", "Your Africa's Talking Username is not set."));
            }
            if (empty(env("AFRICASTALKING_KEY"))) {
                return response()->json(responder("error", "Hmm!", "Your Africa's Talking API KEY is not set."));
            }
            
            $send = Sms::africastalking($user->phone, input("message"));
            
            if ($send) {
                return response()->json(responder("success", "Alright", "SMS successfully sent", "reload()"));
            } else {
                return response()->json(responder("error", "Hmm!", "Failed to send SMS please try again."));
            }
            
        } elseif (env("DEFAULT_SMS_GATEWAY") == "twilio") {
            if (empty(env("TWILIO_SID"))) {
                return response()->json(responder("error", "Hmm!", "Your Twilio SID is not set."));
            }
            if (empty(env("TWILIO_AUTHTOKEN"))) {
                return response()->json(responder("error", "Hmm!", "Your Twilio Auth Token is not set."));
            }
            if (empty(env("TWILIO_PHONENUMBER"))) {
                return response()->json(responder("error", "Hmm!", "Your Twilio Phone Number is not set."));
            }
            
            $send = Sms::twilio($user->phone, input("message"));
            
            if ($send) {
                return response()->json(responder("success", "Alright", "SMS successfully sent", "reload()"));
            } else {
                return response()->json(responder("error", "Hmm!", "Failed to send SMS please try again."));
            }
        }
        
    }


    /**
     * Add note to profile
     * 
     * @return Json
     */
    public function addnote() {
        $user = Auth::user();
        $data = array(
                'note_by'=>$user->id,
                'note_for'=>input('userid'),
                'note'=> escape(input('note'))
                );
        Database::table('notes')->insert($data);
        return response()->json(responder("success", "Alright", "Note successfully published", "reload()"));
    }
    
    /**
     * Delete note
     * 
     * @return Json
     */
    public function deletenote() {
        Database::table("notes")->where("id", input("noteid"))->delete();
        return response()->json(responder("success", "Note Deleted", "Note successfully deleted.", "reload()"));
    }
    
    /**
     * Note details view
     * 
     * @return Json
     */
    public function readnote() {
        $note = Database::table("notes")->where("id", input("noteid"))->first();
        return view('extras/readnote', compact("note"));
    }
    
    /**
     * Note update view
     * 
     * @return Json
     */
    public function updatenoteview() {
        $note = Database::table("notes")->where("id", input("noteid"))->first();
        return view('extras/updatenote', compact("note"));
    }
    
    /**
     * Update Note
     * 
     * @return Json
     */
    public function updatenote() {
        $data = array(
            "note" => escape(input("note"))
        );
        Database::table("notes")->where("id", input("noteid"))->update($data);
        return response()->json(responder("success", "Alright", "Note successfully updated", "reload()"));
    }

    /**
    *Upload attachment
    * 
    * @return Json
    */
    public function uploadattachment() {
        $user = Auth::user();
        $upload = File::upload(
            $_FILES['attachment'], 
            "attachments"
            ,array(
                "source" => "form",
                "allowedExtensions" => "pdf, png, gif, jpg, jpeg",
                 )
        );

        if($upload['status'] == 'success'){
            $data = array(
                'name'=>escape(input('name')),
                'attachment'=>$upload['info']['name'],
                'uploaded_by'=>$user->id,
                'attachment_for'=>escape(input('userid'))
            );
            Database::table('attachments')->insert($data);
            return response()->json(responder("success", "Alright", "Attachment successfully uploaded", "reload()"));
        }else{
            return response()->json(responder("error", "Hmm!", "Something went wrong.".$upload['message']));
        }
    }
    
    /**
     * Delete attachment
     * 
     * @return Json
     */
    public function deleteattachment() {
        $attachment = Database::table("attachments")->where("id", input("attachmentid"))->first();
        File::delete($attachment->attachment, "attachments");
        Database::table("attachments")->where("id", input("attachmentid"))->delete();
        return response()->json(responder("success", "Attachment Deleted", "Attachment successfully deleted", "reload()"));
    }
    
    /**
     * disconnect google calendar
     * 
     * @return Json
     */
    public function disconnectgoogle() {
        Database::table("users")->where("id", input("userid"))->update(array("google_access_token" => ""));
        return response()->json(responder("success", "Disconnected!", "Your Google calendar has been disconnected", "reload()"));
    }

    public function requestreview() {
        $user = Auth::user();

        $student =  Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", input("userid"))->first();

        $manager = Database::table('users')->where('school',$user->school)->where('branch',$user->branch)->where('position',"manager")->first();

            if(strlen($manager->phone)>10){
                $mphone = substr($manager->phone,-10);
            }
            else{
                $mphone = $manager->phone;
            }

            $location = "https://goo.gl/maps/oWzzECUeDWv18pB56";

            if($student->isWaiting==3){
            $studentMessage = "Dear ".$student->fname.",\n\nWe wish you all the best for your future. It was a great experience with you. Thankyou for training with us.\n\nWe request you to share your kind review on Google for us to motivate in our journey here: ".$location."\n\nYou can connect with us anytime at Ph: ".$mphone."\n\nRegards,\n".env("APP_NAME");
            }else{
                $studentMessage = "Dear ".$student->fname.",\n\nWe hope you are having a great time with us. We request you to share your kind review on Google for us to motivate in our journey here: ".$location."\n\nYou can connect with us anytime at Ph: ".$mphone."\n\nRegards,\n".env("APP_NAME");
            }
            if (empty($student->phone)){
                return response()->json(responder("error", "Hmm!", "Not able to find student phone number to send notification."));
            }

            if (!empty($student->phone)) {
                    $send = Sms::africastalking($student->phone, $studentMessage);
                    if ($send) { $status = "Sent"; 
                        return response()->json(responder("success", "Notification Send", "Student has been requested for review." , "reload()"));
                    } else { $status = "Failed"; 
                        return response()->json(responder("error", "HMM!", "Something went wrong" , "reload()"));
                    }
            }
        }

    /**
     * Add Advance
     * 
     * @return Json
     */
    public function addadvance() {
        $user = Auth::user();

        if(!is_int("amount") && input("amount")<=0){
            return response()->json(responder("error", "HMM!", "Incorrect Amount" , "reload()"));
        }

        $validation = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("userid")))->first();

        if($validation->id==""){
            return response()->json(responder("error", "HMM!", "Invalid User Details" , "reload()"));
        }

        $comment = base64_encode(escape(input("comment")));
        $comment = str_replace(array('+','/','='),array('-','_',''),$comment);

        $data = array(
            "id" => escape(input("userid")),
            "amount" => escape(input("amount")),
            "balance" => escape(input("amount")),
            "comment" => $comment,
            "date" => escape(input("date")),
            "updateby" => $user->id,
            "school" => $user->school,
            "branch" => $user->branch
        );

        if(isset($_POST['emi']) && input("emi")!=""){
            $data['emi'] = escape(input("emi"));
        }

        Database::table("advance")->insert($data);

        $validation2 = Database::table("advance")->where("id", input("userid"))->where("branch",$user->branch)->where("school",$user->school)->where("date",$data['date'])->where("amount",$data['amount'])->first();

        if($validation2->date!=""){
            return response()->json(responder("success", "Alright", "Advance Details successfully added.", "reload()"));
        }else{
            return response()->json(responder("error", "HMM!", "Not able to update Details." , "reload()"));
        }
    }

    /**
     * Delete Advance
     * 
     * @return Json
     */
    public function deleteadvance() {
        $user = Auth::user();

        $validation = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("userid")))->first();

        if($validation->fname==""){
            return response()->json(responder("error", "HMM!", "Invalid User Details" , "reload()"));
        }

        Database::table("advance")->where("branch",$user->branch)->where("school",$user->school)->where("id", input("userid"))->where("sr", input("advancesr"))->delete();

        $validation2 = Database::table("advance")->where("sr", input("advancesr"))->first();

        if($validation2->sr==""){
            return response()->json(responder("success", "Alright", "Advance Details successfully deleted.", "reload()"));
        }else{
            return response()->json(responder("error", "HMM!", "Not able to update Details." , "reload()"));
        }
    }

    /**
     * Add Incentive
     * 
     * @return Json
     */
    public function addincentive() {
        $user = Auth::user();

        if(!is_int("amount") && input("amount")<=0){
            return response()->json(responder("error", "HMM!", "Incorrect Amount" , "reload()"));
        }

        $validation = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("userid")))->first();

        if($validation->id==""){
            return response()->json(responder("error", "HMM!", "Invalid User Details" , "reload()"));
        }

        $comment = base64_encode(escape(input("comment")));
        $comment = str_replace(array('+','/','='),array('-','_',''),$comment);

        $data = array(
            "id" => escape(input("userid")),
            "amount" => escape(input("amount")),
            "comment" => $comment,
            "date" => escape(input("date")),
            "updateby" => $user->id,
            "school" => $user->school,
            "branch" => $user->branch
        );

        Database::table("incentive")->insert($data);

        $validation2 = Database::table("incentive")->where("id", input("userid"))->where("branch",$user->branch)->where("school",$user->school)->where("date",$data['date'])->where("amount",$data['amount'])->first();

        if($validation2->date!=""){
            return response()->json(responder("success", "Alright", "Incentive Details successfully added.", "reload()"));
        }else{
            return response()->json(responder("error", "HMM!", "Not able to update Details." , "reload()"));
        }
    }

    /**
     * Delete Incentive
     * 
     * @return Json
     */
    public function deleteincentive() {
        $user = Auth::user();

        $validation = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("userid")))->first();

        if($validation->fname==""){
            return response()->json(responder("error", "HMM!", "Invalid User Details" , "reload()"));
        }

        Database::table("incentive")->where("branch",$user->branch)->where("school",$user->school)->where("id", input("userid"))->where("sr", input("incentivesr"))->delete();

        $validation2 = Database::table("incentive")->where("sr", input("incentivesr"))->first();

        if($validation2->sr==""){
            return response()->json(responder("success", "Alright", "Incentive Details successfully deleted", "reload()"));
        }else{
            return response()->json(responder("error", "HMM!", "Not able to update Details." , "reload()"));
        }
    }

    /**
     * Update Account status
     * 
     * @return Json
     */
    public function activateaccount($userid) {
        $user = Auth::user();

        $validation = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id",$userid)->first();

        if($validation->fname==""){
            return response()->json(responder("error", "HMM!", "Invalid User Details" , "reload()"));
        }

        $data = array(
            "status" => "Active"
        );

        Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id", $userid)->update($data);

        $validation2 = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id", $userid)->first();

        if($validation2->status==$data['status']){
            redirect(url("Profile@get").$userid);
        }else{
            return view('errors/404');
        }
    }

        /**
     * Update Account status
     * 
     * @return Json
     */
    public function dactivateaccount($userid) {
        $user = Auth::user();

        $validation = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id",$userid)->first();

        if($validation->fname==""){
            return response()->json(responder("error", "HMM!", "Invalid User Details" , "reload()"));
        }

        $data = array(
            "status" => "Inactive"
        );

        Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id", $userid)->update($data);

        $validation2 = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id", $userid)->first();

        if($validation2->status==$data['status']){
            redirect(url("Profile@get").$userid);
        }else{
            return view('errors/404');
        }
    }

    /**
     * Generate Payslip
     * 
     * @return Json
     */
    public function generatepayslip() {
        $user = Auth::user();
        
        if ($user->role != 'superadmin' && $user->role != 'admin') {
            return response()->json(responder("error", "HMM!", "Permission Denied. You are not allowed  to generate payslips." , "reload()"));
        }

        $validation = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("userid")))->first();

        if($validation->fname==""){
            return response()->json(responder("error", "HMM!", "Invalid User Details" , "reload()"));
        }

        $validation2 = Database::table("payslips")->where("branch",$user->branch)->where("school",$user->school)->where("userid",escape(input("userid")))->where("month",escape(input("month")))->where("year",escape(input("year")))->first();

        if($validation2->userid!=""){
            return response()->json(responder("error", "HMM!", "Payslip already exists for the selected month." , "reload()"));
        }

        //get deduction amount

        $advance = Database::table("advance")->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("userid")))->get();
        $check = "";
        $damount = 0;
        $dadjusted = "";
        
        foreach($advance as $key1 => $advance){
            $check = "advance".$advance->sr;
            if(input($check)=="on"){
                $damount += $advance->balance;
                $dadjusted .=  $advance->sr.",";
            }
        }

        $pstatus = escape(input("paymentstatus"));
        if($pstatus=="yes"){
            $pstatus = 1;
        }else{
            $pstatus = 0;
        }

        $arear = 0;
        $pdays = 0;
        $adays = 0;
        $hdays = 0;
        $sdate = 1;

        $payment = Database::table("accountdetails")->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("userid")))->first();
        /* $famount = $payment->salary - $damount; */

        $cmonth = escape(input("year"))."-".escape(input("month"));
        $sattendance = Database::table("staffattendance")->where("branch",$user->branch)->where("school",$user->school)->where("marked",0)->where("date","LIKE", "%" . $cmonth . "%")->where("userid",escape(input("userid")))->get();

        foreach($sattendance as $attendance){
            if($attendance->attendance=="Present"){
                $pdays++;
            }elseif($attendance->attendance=="Compoff"){
                $pdays++;
            }elseif($attendance->attendance=="Leave"){
                $pdays++;
            }elseif($attendance->attendance=="Absent"){
                $adays++;
            }elseif($attendance->attendance=="Halfday"){
                $hdays+=0.5;
            }elseif($attendance->attendance=="extra"){
                $arear++;
            }
        }

        $incentive = Database::table('incentive')->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("userid")))->where("ispaid",0)->where("date","LIKE", "%" . $cmonth . "%")->sum("amount","total")[0]->total;

        /* $cmonth = escape(input("year"))."-".escape(input("month")); */
        if(escape(input("wdays"))!="" && escape(input("wdays"))>0 && escape(input("wdays"))<32){
            $mdays = escape(input("wdays"));
            $sdate = $mdays;
            $tdays = date('t', strtotime($cmonth));
            $onedaysalary = $payment->salary/$tdays;
            $fdays = $tdays-$mdays+1;
            $pdays = ($fdays+$arear)-($hdays+$adays);
            $salary = $onedaysalary*$fdays;
            $famount = (($onedaysalary*$pdays)+$incentive)- $damount;
        }else{
            $tdays = date('t', strtotime($cmonth));
            $onedaysalary = $payment->salary/$tdays;
            $pdays = ($tdays+$arear)-($hdays+$adays);
            $salary = $payment->salary;
            $famount = (($onedaysalary*$pdays)+$incentive)- $damount;
        }
        

        $data = array(
            "userid" => escape(input("userid")),
            "month" => escape(input("month")),
            "year" => escape(input("year")),
            "date" => $sdate,
            "salary" => $salary,
            "damount" => $damount,
            "famount" => round($famount),
            "arear" => $arear,
            "incentive" => $incentive,
            "branch" => $user->branch,
            "school" => $user->school,
            "pdays" => $pdays,
            "adays" => $adays,
            "hdays" => $hdays,
            "status" => $pstatus,
            "dadjusted" => $dadjusted,
            "created_by" => $user->id
        );

        if($pstatus==1){
            if($_REQUEST['pdate']==""){
                return response()->json(responder("error", "HMM!", "Invalid Payment Date" , "reload()"));
            }else{
                $data["paymentdate"] = escape(input("pdate"));
            }
        }

        Database::table("payslips")->insert($data);

        $validation2 = Database::table("payslips")->where("userid", input("userid"))->where("branch",$user->branch)->where("school",$user->school)->where("month",$data['month'])->where("year",$data['year'])->first();

        if($validation2->userid!=""){
            /* if($validation2->status==1){ */
                if($validation2->paymentdate==""){
                    $paymentdate = "";
                }
                $data1 = array(
                    "ispaid" => 1,
                    "dateadjusted" => $paymentdate,
                    "payslipid" => $validation2->id
                );
                $advance = Database::table("advance")->where("branch",$validation2->branch)->where("school",$validation2->school)->where("id",$validation2->userid)->get();
                foreach($advance as $key2 => $advance){
                    $check = "advance".$advance->sr;
                    if(input($check)=="on"){
                            Database::table("advance")->where("branch",$validation2->branch)->where("school",$validation2->school)->where("id",$validation2->userid)->where("sr",$advance->sr)->update($data1);
                    }
                /* } */
                }
                Database::table('incentive')->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("userid")))->where("ispaid",0)->where("date","LIKE", "%" . $cmonth . "%")->update($data1);

                $data2 = array(
                    "marked" => 1
                );
                foreach($sattendance as $attendance){
                Database::table("staffattendance")->where("sr",$attendance->sr)->update($data2);
                }

                return response()->json(responder("success", "Alright", "Payslip Details successfully added.", "reload()"));
            }else{
                return response()->json(responder("error", "HMM!", "Not able to update Details." , "reload()"));
        }
    }

    /**
     * Delete Payslip
     * 
     * @return Json
     */
    public function deletepayslip() {
        $user = Auth::user();

        if ($user->role != 'superadmin' && $user->role != 'admin') {
            return response()->json(responder("error", "HMM!", "Permission Denied." , "reload()"));
        }

        $validation2 = Database::table("payslips")->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("payslipid")))->first();

        if($validation2->id==""){
            return response()->json(responder("error", "HMM!", "Invalid User Details" , "reload()"));
        }

        $dateadjusted = "";

        $data = array(
            "ispaid" => 0,
            "dateadjusted" => $dateadjusted,
            "payslipid" => 0
        );

        $advance = Database::table("advance")->where("branch",$validation2->branch)->where("school",$validation2->school)->where("payslipid",$validation2->id)->get();

        foreach($advance as $key3 => $advance){
            Database::table("advance")->where("sr",$advance->sr)->update($data);
        }

        Database::table('incentive')->where("branch",$validation2->branch)->where("school",$validation2->school)->where("payslipid",$validation2->id)->update($data);

        $cmonth = $validation2->year."-".$validation2->month;
        $data2 = array(
            "marked" => 0
        );
        Database::table("staffattendance")->where("branch",$user->branch)->where("school",$user->school)->where("date","LIKE", "%" . $cmonth . "%")->where("userid",$validation2->userid)->update($data2);

        $advance2 = Database::table("advance")->where("branch",$validation2->branch)->where("school",$validation2->school)->where("payslipid",$validation2->id)->get();

        if($advance2->sr==""){
        Database::table("payslips")->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("payslipid")))->delete();
        return response()->json(responder("success", "Alright", "Payslip deleted.", "reload()"));
        }else{
            return response()->json(responder("error", "HMM!", "Not able to update Details." , "reload()"));
        }
    }

   /**
     * Update Payslip
     * 
     * @return Json
     */
    public function updatepayslip() {
        $user = Auth::user();

        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return response()->json(responder("error", "HMM!", "Permission Denied." , "reload()"));
        }

        $validation2 = Database::table("payslips")->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("payslipid")))->first();

        if($validation2->id==""){
            return response()->json(responder("error", "HMM!", "Invalid Payslip Details" , "reload()"));
        }

        if($_REQUEST['newcourse']=="paid"){

            $dateadjusted = escape(input("pdate"));
            $payslipid = escape(input("payslipid"));
            $pmethod = escape(input("pmethod"));

            if($dateadjusted==""){
                return response()->json(responder("error", "HMM!", "Invalid Payment Date" , "reload()"));
            }

            $data = array(
                "dateadjusted" => $dateadjusted
            );

            $data2 = array(
                "status" => 1,
                "paymentdate" => $dateadjusted,
                "pmethod" => $pmethod
            );

            $advance = Database::table("advance")->where("branch",$validation2->branch)->where("school",$validation2->school)->where("payslipid",$validation2->id)->get();

            foreach($advance as $key3 => $advance){
                Database::table("advance")->where("sr",$advance->sr)->update($data);
            }

            Database::table('incentive')->where("branch",$validation2->branch)->where("school",$validation2->school)->where("payslipid",$validation2->id)->update($data);

            Database::table("payslips")->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("payslipid")))->update($data2);
            return response()->json(responder("success", "Alright", "Payslip Status Updated Successfully.", "reload()"));

        }else{
            return response()->json(responder("error", "HMM!", "Invalid Payment Status." , "reload()"));
        }
    }

    /**
     * Add Attendance
     * 
     * @return Json
     */
    public function addattendance() {
        $user = Auth::user();
        
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return response()->json(responder("error", "HMM!", "Permission Denied. You are not allowed  to add attendance." , "reload()"));
        }

        $validation = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("userid")))->first();

        if($validation->fname==""){
            return response()->json(responder("error", "HMM!", "Invalid User Details" , "reload()"));
        }

        $comment = base64_encode(escape(input("comment")));
        $comment = str_replace(array('+','/','='),array('-','_',''),$comment);

        $data = array(
            "userid" => escape(input("userid")),
            "date" => escape(input("date")),
            "attendance" => escape(input("attendance")),
            "created_by" => $user->id,
            "comment" => $comment,
            "branch" => $user->branch,
            "school" => $user->school
        );

        Database::table("staffattendance")->insert($data);

        $validation2 = Database::table("staffattendance")->where("userid", input("userid"))->where("branch",$user->branch)->where("school",$user->school)->where("date",escape(input("date")))->first();

        if($validation2->userid!=""){
            return response()->json(responder("success", "Alright", "Attendance Details successfully added.", "reload()"));
        }else{
            return response()->json(responder("error", "HMM!", "Not able to update Attendance Details." , "reload()"));
        }
    }

    /**
     * Update Attendance
     * 
     * @return Json
     */
    public function updateattendance() {
        $user = Auth::user();
        
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return response()->json(responder("error", "HMM!", "Permission Denied. You are not allowed  to add attendance." , "reload()"));
        }

        $validation = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("userid")))->first();

        if($validation->fname==""){
            return response()->json(responder("error", "HMM!", "Invalid User Details" , "reload()"));
        }

        $comment = base64_encode(escape(input("comment")));
        $comment = str_replace(array('+','/','='),array('-','_',''),$comment);

        $data = array(
            "attendance" => escape(input("attendance")),
            "created_by" => $user->id,
            "comment" => $comment
        );

        Database::table("staffattendance")->where("sr",escape(input("sattendanceid")))->update($data);

        $validation2 = Database::table("staffattendance")->where("sr",escape(input("sattendanceid")))->where("attendance",escape(input("attendance")))->where("comment",$comment)->first();

        if($validation2->userid!=""){
            return response()->json(responder("success", "Alright", "Attendance Details successfully Updated.", "reload()"));
        }else{
            return response()->json(responder("error", "HMM!", "Not able to update Attendance Details." , "reload()"));
        }
    }

    /**
     * Delete Attendance
     * 
     * @return Json
     */
    public function deleteattendance() {
        $user = Auth::user();
        
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return response()->json(responder("error", "HMM!", "Permission Denied. You are not allowed  to add attendance." , "reload()"));
        }

        $validation = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id",escape(input("userid")))->first();

        if($validation->fname==""){
            return response()->json(responder("error", "HMM!", "Invalid User Details" , "reload()"));
        }

        Database::table("staffattendance")->where("sr",escape(input("sattendanceid")))->delete();

        $validation2 = Database::table("staffattendance")->where("sr",escape(input("sattendanceid")))->first();

        if($validation2->userid==""){
            return response()->json(responder("success", "Alright", "Attendance Details successfully removed.", "reload()"));
        }else{
            return response()->json(responder("error", "HMM!", "Not able to update Attendance Details." , "reload()"));
        }
    }

}
