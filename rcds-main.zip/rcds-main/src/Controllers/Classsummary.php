<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\Database;
use Simcify\File;
use Simcify\Sms;
use Simcify\Mail;
use Simcify\FS;

class Classsummary{

    /**
     * Get profile view
     * 
     * @return \Pecee\Http\Response
     */
    public function get($userid) {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $profile = Database::table('users')->where('branch',$user->branch)->where('school',$user->school)->where('id',$userid)->first();

        $getclass = Database::table('attendance')->where('id', $profile->id)->where('status', 2)->get();

            foreach($getclass as $class){
                $lesson = explode(',',$class->trainingitems);
                $k=1;
                for($i=0;$i<count($lesson);$i++){
                    $clessonDetails = Database::table('practicallessons')->where('id', $lesson[$i])->first();
                    $class->summary .= $k.". ".$clessonDetails->name.": ".$clessonDetails->description."<br>";
                    $k++;
                }

                $tname = Database::table('users')->leftJoin('schedules','users.id','schedules.instructor')->where("schedules`.`start", "LIKE", "%" . $class->$date . "%")->where("schedules`.`status","Complete")->where('schedules`.`student',$class->id)->first("`users.fname`","`users.lname`");

                $class->trainer = $tname->fname." ".$tname->lname;

                $dt1 = date('h:i:s', strtotime($class->starttime));
                $dt2 = date('h:i:s', strtotime($class->endtime));
                $dt1 = new \DateTime($dt1);
                $dt2 = new \DateTime($dt2);
                $mtime = $dt1->diff($dt2)->format('%i');
                $htime = $dt1->diff($dt2)->format('%h');
                if($htime>0){
                    $mtime += $htime*60;
                }
                $class->expectedendtime = $mtime;

                $dt3 = date('h:i:s', strtotime($class->setendtime));
                $dt3 = new \DateTime($dt3);
                $mtime = $dt1->diff($dt3)->format('%i');
                $htime = $dt1->diff($dt3)->format('%h');
                if($htime>0){
                    $mtime += $htime*60;
                }
                $class->realendtime = $mtime;

            }

        return view('classsummary', compact("user", "profile","getclass"));
    }

}
