<?php
namespace Simcify\Controllers;

use Simcify\Database;
use Simcify\Landa;
use Simcify\Auth;
use Simcify\Sms;

class Today{

    /**
     * Get Attendance view
     * 
     * @return \Pecee\Http\Response
     */

    public function get() {
      $user = Auth::user();
      if ($user->role != 'instructor') {
        return view('errors/404');
      }
      $date = date("Y-m-d");
      $cdate = date("Y-m-d");
      $attendence = Database::table("staffattendance")->where('branch', $user->branch)->where('school', $user->school)->where('date', $date)->where('userid', $user->id)->first();

      if($attendence==""){
        redirect(url("Welcome@get"));
      }
      $today = Database::table('users')->leftJoin('attendance','users.id','attendance.id')->rightJoin('schedules','users.id','schedules.student')->where("users`.`branch", $user->branch)->where("users`.`role","student")->where("users`.`isWaiting",0)->where("attendance`.`date", $date)->where("attendance`.`status", 0)->where("attendance`.`isstarted","!=", 2)->where("schedules`.`start", "LIKE", "%" . $date . "%")->where("schedules`.`instructor",$user->id)->orderBy('schedules.start', true)->where("schedules`.`status","!=","Complete")->get("`users.fname`", "`users.lname`", "`users.avatar`", "`users.email`", "`users.address`", "`users.aadhar`", "`users.aadharfront`", "`users.aadharback`", "`users.phone`", "`users.location`","`users.defaulter`","`attendance.id`", "`attendance.status`","`attendance.isstarted`", "`attendance.lastupdate`", "`attendance.date`","`schedules.instructor`","`schedules.student`","`schedules.course`","`schedules.start`","`schedules.id` as `schedulesid`","`schedules.status` as schedulestatus","`schedules.cstatus`");

      $toataltoday = count($today);

      //,"`invoices.amount`","`invoices.amountpaid`"

      foreach ($today as $student) {
      $student->completed = Database::table('schedules')->where('student', $student->student)->where('status', "Complete")->count("id", "total")[0]->total;
      $student->amount = Database::table("invoices")->where('student', $student->student)->first("amount");
      $student->amountpaid = Database::table("invoices")->where('student', $student->student)->first("amountpaid");
      }
      $isFound = "";
      $isFound2 = "";
      $instructors = Database::table("users")->get();
      $courses = Database::table("courses")->get();
      $isclass = Database::table('users')->leftJoin('attendance','users.id','attendance.id')->leftJoin('invoices','users.id','invoices.student')->rightJoin('schedules','users.id','schedules.student')->where("users`.`branch", $user->branch)->where("users`.`school", $user->school)->where("schedules`.`instructor",$user->id)->where("users`.`role","student")->where("users`.`isWaiting",0)->where("attendance`.`date", $date)->where("schedules`.`start", "LIKE", "%" . $date . "%")->where("attendance`.`isstarted", 1)->first("`attendance.isstarted`");

      return view('today', compact("today","user","invoices","date","cdate","instructors","isFound","isFound2","courses","isclass","toataltoday"));
}

    /**
     * Send Student detials to instructor
     * 
     * @return Json
     */
    
    public function getdetails(){
        $date = date("Y-m-d");
        $student = Database::table("users")->where("id", input("studentid"))->first();
        $trainer = Database::table("users")->where("id", input("userid"))->first();
        $schedules = Database::table("schedules")->where("student", input("studentid"))->where("start", "LIKE", "%" . $date . "%")->first();
        $course = Database::table("courses")->where("id", $schedules->course)->first();
        $payments = Database::table("invoices")->where("student", input("studentid"))->first();
        $balance = $payments->amount-$payments->amountpaid;
        if($balance>0){
            $payment = "Payment Pending: ".$balance." /- Rs.";
        }else{
            $payment = "Payment: Full Paid";
        }
        if(strlen($student->phone)>10){
			$phone = substr($student->phone,-10);
		}
		else{
			$phone = $student->phone;
		}
        if(strlen($student->alternatephone)>10){
			$altphone = substr($student->alternatephone,-10);
		}
		else{
			$altphone = $student->alternatephone;
		}
        if($student->location!=""){
            $trainerMessage = "Hello! ".$trainer->fname.", please find the contact details for requested Student below:\n\nName: ".$student->fname."\nPh: ".$phone."\nAlt: ".$altphone."\nCourse: ".$course->name."(".$course->duration." Days)\nAddress: ".$student->address."\nLocation:".$student->location."\n".$payment."\n\n".env("APP_NAME");
        }else{
        $trainerMessage = "Hello! ".$trainer->fname.", please find the contact details for requested Student below:\n\nName: ".$student->fname."\nPh: ".$phone."\nCourse: ".$course->name."(".$course->duration." Days)\nAddress: ".$student->address."\n".$payment."\n\n".env("APP_NAME");
        }
    	if (!empty($trainer->phone)) {
	        $send = Sms::africastalking($trainer->phone, $trainerMessage);
            if ($send) {
                return response()->json(responder("success", "Sent", "Details has been shared successfully","reload()"));
            } else { 
                return response()->json(responder("error", "HMM!", "Something went wrong. Pelase connect with your Manager","reload()"));
            }
    	}


    }


    /**
     * Start Class
     * 
     * @return Json
     */
    public function start() {
        $user = Auth::user();
        if ($user->role != 'instructor') {
          return view('errors/404');
        }
        $date = date("Y-m-d");

        $isclass = Database::table('users')->leftJoin('attendance','users.id','attendance.id')->leftJoin('invoices','users.id','invoices.student')->rightJoin('schedules','users.id','schedules.student')->where("users`.`branch", $user->branch)->where("users`.`school", $user->school)->where("schedules`.`instructor",$user->id)->where("users`.`role","student")->where("users`.`isWaiting",0)->where("attendance`.`date", $date)->where("schedules`.`start", "LIKE", "%" . $date . "%")->where("attendance`.`isstarted", 1)->first("`attendance.isstarted`");

        $isdefaulter = Database::table('users')->where("school", $user->school)->where("branch", $user->branch)->where("id", escape(input('studentid')))->first();

        if($isclass->isstarted==1){
            return response()->json(responder("error", "HMM!", "One Class is already running. Please end the class if you want to start another.","reload()"));
        }elseif($isdefaulter->defaulter==1){
            return response()->json(responder("error", "HMM!", "The Payment is required for the student to start the class.","reload()"));
        }

        $sdate = date("Y-m-d");
        $schedule = Database::table("schedules")->where("id", input("scheduleid"))->where("student", input('studentid'))->where("instructor", $user->id)->where("school", $user->school)->where("branch", $user->branch)->where("status", '!=', "Complete")->where("start", "LIKE", "%" . $sdate . "%")->first();

        $dt1 = date('H:i:s', strtotime($schedule->start));
        $dt2 = date('H:i:s', strtotime($schedule->end));
        $dateTimeObject1 = date_create($dt1); 
        $dateTimeObject2 = date_create($dt2); 
          
        $difference = date_diff($dateTimeObject1, $dateTimeObject2); 
        $minutes = $difference->days * 24 * 60;
        $minutes += $difference->h * 60;
        $minutes += $difference->i;
        $totalTime = "+".$minutes.' minutes';

        $tz = 'Asia/Kolkata';
        $timestamp = time();
        $dt = new \DateTime("now", new \DateTimeZone($tz)); //first argument "must" be a string
        $dt->setTimestamp($timestamp); //adjust the object to correct timestamp
        $stime = $dt->format('H:i:s');
        $time = strtotime($stime);
        $etime = date("H:i:s", strtotime($totalTime, $time));


        $data = array(
            "isstarted" => 1,
            "starttime" => $stime,
            "endtime" => $etime
        );

        Database::table("attendance")->where("id", $schedule->student)->where('date', $sdate)->where("school", $user->school)->where("branch", $user->branch)->update($data);

        $date = date("Y-m-d");
        $student = Database::table("users")->where("id", $schedule->student)->where("school", $user->school)->where("branch", $user->branch)->first();
        $instructor = Database::table("users")->where("id", $user->id)->where("school", $user->school)->where("branch", $user->branch)->first();
        $schedules = Database::table("schedules")->where("student", $student->id)->where("start", "LIKE", "%" . $date . "%")->where("school", $user->school)->where("branch", $user->branch)->first();
        $course = Database::table("courses")->where("id", $schedule->course)->where("school", $user->school)->where("branch", $user->branch)->first();
        $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();
        $payments = Database::table("invoices")->where("student", $student->id)->first();
        $completed = Database::table('schedules')->where('student', $student->id)->where('status', "Complete")->count("id", "total")[0]->total;
        $completed++;
        if($completed==1){
            $class = "1st";
        }elseif($completed==2){
            $class = "2nd";
        }elseif($completed==3){
            $class = "3rd";
        }elseif($completed==21){
            $class = "21st";
        }elseif($completed==22){
            $class = "22nd";
        }elseif($completed==23){
            $class = "23rd";
        }elseif($completed==31){
            $class = "31st";
        }elseif($completed==32){
            $class = "32nd";
        }elseif($completed==33){
            $class = "33rd";
        }else{
            $class = $completed."th";
        }
        $balance = $payments->amount-$payments->amountpaid;
        if($balance>0){
            $payment = " whose pending payment is ".$balance." /- Rs.";
        }else{
            $payment = " who has done full payment already.";
        }
        if(strlen($student->phone)>10){
			$sphone = substr($student->phone,-10);
		}
		else{
			$sphone = $student->phone;
		}
        if(strlen($instructor->phone)>10){
			$iphone = substr($instructor->phone,-10);
		}
		else{
			$iphone = $instructor->phone;
		}
        $managerMessage = "Dear ".$manager->fname.", Mr. ".$instructor->fname." (".$iphone.") has started ".$class." class today with ".$student->fname." (".$sphone.") enrolled in ".$course->name." course for ".$course->duration." Days from ".$student->address." at ".$date." ".$stime.$payment."\n\n".env("APP_NAME")."\n\nTime: ".$totalTime;
    	$branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
        if (!empty($manager->phone)) {
            Database::table("usermessages")->insert(array(
                "receiver" => $manager->id, 
                "type" => "whatsapp", 
                "contact" => $manager->phone,
                "Subject" => "Class Completed",
                "message" => escape($managerMessage),
                "scheduled_at" => date("d-m-Y H:i:s"),
                "sent_by" => $user->id,
                "school" => $manager->school, 
                "branch" => $manager->branch, 
                "status" => "Pending"
              ));
                return response()->json(responder("success", "Class Started", "Class has been started please go to Class", "reload()"));
            } else { 
                return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
            }
    }

    /**
     * Mark Absent
     * 
     * @return Json
     */


    public function absent() {
        $user = Auth::user();
    	$school = Database::table('schools')->where('id',$user->school)->first();
        if ($user->role != 'instructor') {
          return view('errors/404');
        }
        $data2 = array(
         "status" => "Missed"
        );
        $sdate = escape(input('date'));
        $cdate = date("Y-m-d");

        if($sdate==$cdate){
        Database::table("schedules")->where("id", input("scheduleid"))->where("student", input("studentid"))->where("instructor", $user->id)->update($data2);

        $statuses =  Database::table("schedules")->where("id", input("scheduleid"))->where("student", input("studentid"))->where("instructor", $user->id)->first();

        if($statuses->status=="Missed"){
            $data = array(
                "status" => 1
            );
    
        Database::table("attendance")->where("id",  input("studentid"))->where('date', $sdate)->update($data);

        /*$statuses2 =  Database::table("schedules")->where("student", input("studentid"))->get();

        $firstdate = array();
        foreach($statuses2 as $sat => $statuse){
            $firstdate []= $statuse->start;
        }

        $lastdate = $firstdate[0];

        for($i=1;$i<count($firstdate);$i++){
            if($lastdate<$firstdate[$i]){
                $lastdate=$firstdate[$i];
            }
        }

        $ldate = date('Y-m-d', strtotime($lastdate));
        $date = strtotime($ldate);
        $date = strtotime("+1 day", $date);
        $day = date('D', $date);
        if($day=="Sun"){
        $date = strtotime("+1 day", $date);
        }

        $ldate = date('Y-m-d', $date);
        $lastdate = $ldate." ".date('H:i:s', strtotime($statuses->start));
        $enddate = $ldate." ".date('H:i:s', strtotime($statuses->end));


        $data = array(
            'school'=>$statuses->school,
			'branch'=>$statuses->branch,
            'start'=>$lastdate,
            'end'=>$enddate,
            'course'=>$statuses->course,
            'student'=>$statuses->student,
            'instructor'=>$statuses->instructor,
            'class_type'=>$statuses->class_type,
            'car'=>$statuses->car,
            'status'=>"New"
        );

        Database::table('schedules')->insert($data);
        $scheduleId = Database::table('schedules')->insertId();*/

        if ($school->class_sms_notifications == "Enabled") {
            $course = Database::table('courses')->where('id',$statuses->course)->first();
            $student = Database::table('users')->where('id', $statuses->student)->first();
            $instructor = Database::table('users')->where('id',$user->id)->first();
            $schedule2 = Database::table('schedules')->where('id', $scheduleId)->first();
            $manager = Database::table('users')->where('school',$user->school)->where('branch',$user->branch)->where('position',"manager")->first();
            $payments = Database::table("invoices")->where("student", $statuses->student)->first();
            if(strlen($instructor->phone)>10){
                $phone = substr($instructor->phone,-10);
            }
            else{
                $phone = $instructor->phone;
            }
            if(strlen($manager->phone)>10){
                $phone2 = substr($manager->phone,-10);
            }
            else{
                $phone2 = $manager->phone;
            }

            $studentMessage = "Hello! ".$student->fname.", you missed your ".$statuses->class_type." class for your ".$course->name." course which was scheduled on ".date('d-m-Y', strtotime($statuses->start))." at ".date('h:i A', strtotime($statuses->start))." to ".date('h:i A', strtotime($statuses->end))." with Mr. ".$instructor->fname." ".$instructor->lname." Ph: ".$phone."\n\nKindly Connect with Mr. ".$manager->fname." ".$manager->lname." (Manager)\nPhone: ".$phone2."\n\n".env("APP_NAME");
            if (!empty($student->phone)) {
                Database::table("usermessages")->insert(array(
                    "receiver" => $student->id, 
                    "type" => "whatsapp", 
                    "contact" => $student->phone,
                    "Subject" => "Class Completed",
                    "message" => escape($studentMessage),
                    "scheduled_at" => date("d-m-Y H:i:s"),
                    "sent_by" => $user->id,
                    "school" => $student->school, 
                    "branch" => $student->branch, 
                    "status" => "Pending"
                  ));
                }
            
                
            $balance = $payments->amount-$payments->amountpaid;
            if($balance>0){
                    $payment = "Payment Pending: ".$balance."/- Rs";
            }else{
                $payment = "Payment: Full Paid";
            }
            $managerMessage = "Dear ".$manager->fname.",\n\n".$student->fname.", has missed his/her ".$statuses->class_type." class for your ".$course->name." course which was scheduled on ".date('d-m-Y', strtotime($statuses->start))." at ".date('h:i A', strtotime($statuses->start))." to ".date('h:i A', strtotime($statuses->end))." with Mr. ".$instructor->fname." ".$instructor->lname." Ph: ".$phone."\n\nPlease find the contact details for below:\n\nName: ".$student->fname."\nPh: ".$phone."\nCourse: ".$course->name."(".$course->duration." Days)\nAddress: ".$student->address."\n".$payment."\n\n".env("APP_NAME");
            $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
            if (!empty($manager->phone)) {
                Database::table("usermessages")->insert(array(
                    "receiver" => $manager->id, 
                    "type" => "whatsapp", 
                    "contact" => $manager->phone,
                    "Subject" => "Class Completed",
                    "message" => escape($managerMessage),
                    "scheduled_at" => date("d-m-Y H:i:s"),
                    "sent_by" => $user->id,
                    "school" => $manager->school, 
                    "branch" => $manager->branch, 
                    "status" => "Pending"
                  ));
                }
            }
            return response()->json(responder("success", "Attendance Marked", "Student Marked as Absent Successfully", "reload()"));
        }
        return response()->json(responder("error", "Hmm!", "Something went wrong please try again."));
      
        }
        else{
            return response()->json(responder("error", "Hmm!", "Something went wrong please try again."));
        }
    }

    public function notify() {
        $user = Auth::user();
    	$school = Database::table('schools')->where('id',$user->school)->first();
        if ($user->role != 'instructor') {
          return view('errors/404');
        }

        $date = date("Y-m-d");
        $statuses =  Database::table("schedules")->where("student", input("student"))->where("instructor", $user->id)->where("schedules`.`start", "LIKE", "%" . $date . "%")->first();

        if(input('time')>0 && input('time')<16 && $statuses->student!=""){

        if ($school->class_sms_notifications == "Enabled") {
            $course = Database::table('courses')->where('id',$statuses->course)->first();
            $student = Database::table('users')->where('id', $statuses->student)->first();
            $instructor = Database::table('users')->where('id',$user->id)->first();
            $schedule2 = Database::table('schedules')->where('id', $scheduleId)->first();
            $manager = Database::table('users')->where('school',$user->school)->where('branch',$user->branch)->where('position',"manager")->first();
            $payments = Database::table("invoices")->where("student", $statuses->student)->first();
            if(strlen($instructor->phone)>10){
                $phone = substr($instructor->phone,-10);
            }
            else{
                $phone = $instructor->phone;
            }
            if(strlen($manager->phone)>10){
                $phone2 = substr($manager->phone,-10);
            }
            else{
                $phone2 = $manager->phone;
            }
            if(strlen($student->phone)>10){
                $phone3 = substr($manager->phone,-10);
            }
            else{
                $phone3 = $manager->phone;
            }

            $studentMessage = "Dear ".$student->fname."!,\n\nSorry for your inconvinience. We would like to inform you that your class has been delayed by ".escape(input('time'))." minutes with Mr. ".$instructor->fname." ".$instructor->lname." PH: ".$phone." which was scheduled on ".date('d-m-Y', strtotime($statuses->start))." at ".date('h:i A', strtotime($statuses->start))." to ".date('h:i A', strtotime($statuses->end))."\n\nKindly Connect with Mr. ".$manager->fname." ".$manager->lname." (Manager) Ph: ".$phone2." for any query.\n\n".env("APP_NAME");
            if (empty($student->phone)){
                return response()->json(responder("error", "Hmm!", "Not able to find student phone number to send notification."));
            }elseif (empty($manager->phone)){
                return response()->json(responder("error", "Hmm!", "Not able to find Manager phone number to send notification."));
            }


            if (!empty($student->phone)) {
                    $send = Sms::africastalking($student->phone, $studentMessage);
                    if ($send) { $status = "Sent"; } else { $status = "Failed"; }
            }
                
            $balance = $payments->amount-$payments->amountpaid;
            if($balance>0){
                    $payment = "Payment Pending: ".$balance."/- Rs";
            }else{
                $payment = "Payment: Full Paid";
            }
            $managerMessage = "Dear ".$manager->fname."!, \n\nMr. ".$instructor->fname." ".$instructor->lname." PH: ".$instructor->phone." has send a notification to ".$student->fname." for the delay of class by ".escape(input('time'))." minutes which was scheduled on ".date('d-m-Y', strtotime($statuses->start))." at ".date('h:i A', strtotime($statuses->start))." to ".date('h:i A', strtotime($statuses->end)).".\n\nPlease find the contact details for below:\n\nName: ".$student->fname."\nPh: ".$phone3."\nCourse: ".$course->name."(".$course->duration." Days)\nAddress: ".$student->address."\n".$payment."\n\n".env("APP_NAME");

            $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
            if (!empty($manager->phone)) {
	        $send = Sms::africastalking($manager->phone, $managerMessage);
                    if ($send) { $status = "Sent"; } else { $status = "Failed"; }
                    Database::table("usermessages")->insert(array(
                        "receiver" => $manager->id, "type" => "sms", "contact" => $manager->phone,
                        "message" => escape($managerMessage),
                        "school" => $manager->school, "branch" => $manager->branch, "status" => $status
                    ));
                }
                $res = "A notification for ".input('time')." minutes of delay has been sent to ".$student->fname;
                return response()->json(responder("success", "Notification Send", $res , "reload()"));
            }
        }else{
            return response()->json(responder("error", "Hmm!", "Wrong notification time."));
        }
    }

    public function requestpayment() {
        $user = Auth::user();

        $date = date("Y-m-d");
        if($user->role!="superadmin" && $user->role!="admin" && $user->role!="staff"){
            $statuses =  Database::table("schedules")->where("branch", $user->branch)->where("school", $user->school)->where("student", input("studentid"))->where("instructor", $user->id)->where("schedules`.`start", "LIKE", "%" . $date . "%")->first();

            $student =  Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", $statuses->student)->first();

            if($student->fname==""){
                return response()->json(responder("error", "HMM!", "No record for student" , "reload()"));
            }
        }else{
            $statuses =  Database::table("schedules")->where("branch", $user->branch)->where("school", $user->school)->where("student", escape(input("studentid")))->first();
            $student =  Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("id", escape(input("studentid")))->first();
            if($student->fname==""){
                return response()->json(responder("error", "HMM!", "No record for student" , "reload()"));
            }
        }

        $enrollment = Database::table("coursesenrolled")->where("branch", $user->branch)->where("school", $user->school)->where("student", $student->id)->first();

        $course = Database::table("courses")->where("branch", $user->branch)->where("school", $user->school)->where("id", $enrollment->course)->first();

        $paymentlink = Database::table("paymentlinks")->where("branch", $user->branch)->where("school", $user->school)->where("course", $enrollment->course)->first();

        $manager = Database::table('users')->where('school',$user->school)->where('branch',$user->branch)->where('position',"manager")->first();
        $payments = Database::table("invoices")->where("student", escape(input("studentid")))->first();
        $balance = $payments->amount-$payments->amountpaid;
        if($balance>0){
                $payment = "Payment Pending: ".$balance."/- Rs";
        }else{
            return response()->json(responder("error", "HMM!", "Please contact manager to start the class." , "reload()"));
        }

            if(strlen($manager->phone)>10){
                $mphone = substr($manager->phone,-10);
            }
            else{
                $mphone = $manager->phone;
            }

            $location = "https://goo.gl/maps/oWzzECUeDWv18pB56";

            
            $studentMessage = "Dear ".$student->fname.",\n\nWe hope you are having a great time with us. We request you to complete your due payment using the below payment details to avoid intruption of your classes.\n\n".$payment."\n\nYou can use any payment method like Paytm, GPay, Phonepay on 9034179580 (Rekha) also please share the screenshot with our manager at Ph: ".$mphone."\n\nRegards,\n".env("APP_NAME");

/*             if($paymentlink->id!=""){
            $studentMessage = "Dear ".$student->fname.",\n\nWe hope you are having a great time with us. We request you to complete your due payment using the below payment details to avoid intruption of your classes.\n\n".$payment."\n\nYou can use below link for payment with Paytm, GPay, Phonepay etc. also please share the screenshot with our manager at Ph: ".$mphone."\n\nCourse Enrolled: ".$course->name."\nAmount: ".$course->price."\nPayment Link: ".$paymentlink->paymentlink."\n\nRegards,\n".env("APP_NAME");
            }else{
                $studentMessage = "Dear ".$student->fname.",\n\nWe hope you are having a great time with us. We request you to complete your due payment using the below payment details to avoid intruption of your classes.\n\n".$payment."\n\nYou can use below link for payment with Paytm, GPay, Phonepay etc. also please share the screenshot with our manager at Ph: ".$mphone."\n\nCourse Enrolled:".$course->name."\nAmount:".$course->price."\nPayment Link: https://www.instamojo.com/@realcardriving \n\nRegards,\n".env("APP_NAME");
            } */
            
            if (empty($student->phone)){
                return response()->json(responder("error", "Hmm!", "Not able to find student phone number to send notification."));
            }

            if (!empty($student->phone)) {
                    $send = Sms::africastalking($student->phone, $studentMessage);
                    if ($send) { $status = "Sent"; 
                        return response()->json(responder("success", "Notification Send", "Student has been requested for payment." , "reload()"));
                    } else { $status = "Failed"; 
                        return response()->json(responder("error", "HMM!", "Something went wrong" , "reload()"));
                    }
            }
        }

}
