<?php
namespace Simcify\Controllers;

use Simcify\Database;
use Simcify\Landa;
use Simcify\Auth;
use Simcify\Mail;

class License{

    /**
     * Get students view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user = Auth::user();
        if ($user->role != 'superadmin') {
            return view('errors/404');
        }
        
        $license = Database::table('license')->where(array('status' => 1))->get();

        foreach ($license as $licenses) {
            $udpate = Database::table('users')->where('id', $licenses->updateby)->first();
            $licenses->updatedby = $udpate->fname." ".$udpate->lname;
        }

        $courses = Database::table('courses')->where('school',$user->school)->where('status',"Available")->get();
        return view('license', compact("user", "license"));
    }
  
    
    /**
     * Add New License
     * 
     * @return Json
     */
    public function new() {
        $user = Auth::user();
        if ($user->role != 'superadmin') {
            return view('errors/404');
        }

        //validating inputs

        $data = array(
            "updateby" => $user->id,
            "branch" => $user->branch,
            "school" => $user->school
        );

        foreach (input()->post as $field) {
            if ($field->index == "name") {
                
                $data['name']= escape($field->value);
                
                continue;
            }
            if ($field->index == "csrf-token") {
                continue;
            }
            if ($field->index == "number") {
                if($field->value!=""){
                    $number = base64_encode($field->value);
                    $number = str_replace(array('+','/','='),array('-','_',''),$number);
                    $data['number']= $number;
            }
                continue;
            }
            if ($field->index == "type") {
                
                $data['type']= escape($field->value);
                
                continue;
            }
            if ($field->index == "sdate") {
                
                $data['start']= escape($field->value);
                
                continue;
            }
            if ($field->index == "edate") {
                
                $data['end']= escape($field->value);
                
                continue;
            }
            if ($field->index == "alertdays") {
                
                $data['alertdays']= escape($field->value);
                
                continue;
            }
            if ($field->index == "attachment") {
                if (!empty($field->value)) {
                    $attachments = File::upload($field->value, "attachments", array(
                        "source" => "form",
                        "allowedExtensions" => "pdf, png, gif, jpg, jpeg",
                    ));
                    if ($attachments['status'] == "success") {
                        $data['file']=$attachments['info']['name'];
                    }
                }
                continue;
            }
            if ($field->index == "comment") {
                if($field->value!=""){
                    $comment = base64_encode($field->value);
                    $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
                    $data['comment']= $comment;
            }
                continue;
            }
        }

        Database::table('license')->insert($data);

        $status = Database::table('license')->where('file', $data['file'])->first();

        if(!empty($status)){        
            return response()->json(responder("success", "Record Added!", "New License Record Successfully Added.", "reload()"));
        }else{
            return response()->json(responder("error", "HMM!", "Something went wrong. Not able to Save Details","reload()"));
        }
        
    }


    /**
     * Add course
    *
    */
    public function addcourse(){
        if($_REQUEST['amountpaid']==""){
            $amountpaid = 0;
        }
        $amountpaid = escape(input('amountpaid'));
        if($_REQUEST['discount']==""){
            $discount = 0;
        }
        $discount = escape(input('discount'));
        self::enroll(escape(input("studentid")), escape(input("newcourse")));
        self::createinvoice(escape(input("studentid")), escape(input("newcourse")), $amountpaid , escape(input("method")), $discount);
        return response()->json(responder("success", "Alright", "Student successfully enrolled to the course", "reload()"));
    }

    /**
     * Enroll student to a course
    *
     * @return true
    */
    private function enroll($students, $course){
        $user = Auth::user();
        $school = Database::table('schools')->where('id',$user->school)->first();
        $course = Database::table('courses')->where('id',$course)->first();
        $student = Database::table('users')->where('id',$students)->first();

        $data = array(
            'school'=>$user->school,
            'branch'=>$user->branch,
            'student'=>$student->id,
            'course'=>$course->id,
            'total_theory'=>$course->theory_classes,
            'total_practical'=>$course->practical_classes
        );
        Database::table('coursesenrolled')->insert($data);   
          $timeline = 'Enrolled to <strong>'.$course->name.'</strong> course.';
          Landa::timeline($student->id, $timeline);  
        // send enrollment email
        /*  Mail::send($student->email, "Course enrollment at ".$school->name, array(
              "message" => "Hello ".$student->fname.",<br><br>You have successfully been enrolled to <strong>(" . $course->name . ")</strong> course at ".$school->name.". <br>This course will have <strong>".$course->practical_classes." practical classes</strong> and <strong>".$course->theory_classes." theory classes</strong>. <br><br>Cheers!<br>" . $school->name. " Team."
          ), "basic");*/

          return true;
    }

    /**
     * Delete student Enrollment student to a course
    *
     * @return true
    */
    public function deleteenrollment(){
        Database::table('coursesenrolled')->where("id", input("enrollmentid"))->delete();
        return response()->json(responder("success", "Alright", "Student enrollment successfully deleted", "reload()"));
    }

    /**
     * Create an invoice
    *
     * @return true
    */
    private function createinvoice($students, $course, $amountpaid, $paymentmethod, $discount){

        $user = Auth::user();
        $school = Database::table('schools')->where('id',$user->school)->first();
        $course = Database::table('courses')->where('id',$course)->first();
        $student = Database::table('users')->where('id',$students)->first();

        $reference = rand(111111,999999);
        $data = array(
            'school'=>$user->school,
            'branch'=>$user->branch,
            'student'=>$student->id,
            'reference'=> $reference,
            'item'=>$course->name,
            'amount'=>$course->price-$discount,
            'amountpaid'=>$amountpaid,
            'discount'=>$discount
          );  
          Database::table('invoices')->insert($data); 
          $invoiceId = Database::table('invoices')->insertId();  

          if ($amountpaid > 0) {
            $data = array(
                'invoice'=>$invoiceId,
                'school'=>$user->school,
                'branch'=>$user->branch,
                'student'=>$student->id,
                'method'=>$paymentmethod,
                'amount'=>$amountpaid
            );   
            Database::table('payments')->insert($data);
            $notification = 'You made a payment of <strong>'.money($amountpaid).'</strong>.';
            Landa::notify($notification, $student->id, "payment", "personal");
            $notification = 'A payment of <strong>'.money($amountpaid).'</strong> has been received from <strong>'.$student->fname.' '.$student->lname.'</strong>.';
            Landa::notify($notification, $user->id, "payment");
          }  


        // send invoice email
          /*Mail::send($student->email, $school->name." invoice #".$reference, 
            array(
                "title" => "Thank you for joining us!",
                "subtitle" => "This is an invoice for your ".$school->name." enrollment. <strong>$".$amountpaid." </strong> paid.",
                "summary" => array(
                                "currency" => currency(),
                                "subtotal" => $course->price,
                                "tax" => 0,
                                "total" => $course->price,
                            ),
                "items" => array(
                            array(
                                "name" => $course->name,
                                "quantity" => "1",
                                "price" => $course->price,
                            )
                        )
            ), "invoice");*/

          return true;

    }


}
