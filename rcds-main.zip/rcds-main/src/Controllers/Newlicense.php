<?php
namespace Simcify\Controllers;

use Simcify\Database;
use Simcify\Landa;
use Simcify\Auth;
use Simcify\Mail;

class Newlicense{

    /**
     * Get students view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $date = date("Y-m-d");

        if (!isset($_GET['view'])) {
            $currentstatus = "Enrolled";
        }elseif (isset($_GET['view']) && $_GET['view'] == "Started") {
            $currentstatus = "Started";
        }elseif (isset($_GET['view']) && $_GET['view'] == "Payment") {
            $currentstatus = "Payment";
        }elseif (isset($_GET['view']) && $_GET['view'] == "Processing") {
            $currentstatus = "Processing";
        }elseif (isset($_GET['view']) && $_GET['view'] == "Learning") {
            $currentstatus = "Learning";
        }elseif (isset($_GET['view']) && $_GET['view'] == "Permanent") {
            $currentstatus = "Permanent";
        }elseif (isset($_GET['view']) && $_GET['view'] == "Completed") {
            $currentstatus = "Completed";
        }else{
            $currentstatus = "Enrolled";
        }

        $goings = Database::table('newdrivinglicense')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
        ))->orderBy('createdat', false)->get();

        $Enrolled = 0;
        $Started = 0;
        $Payment = 0;
        $Processing = 0;
        $Learning = 0;
        $Permanent = 0;
        $Completed = 0;

        foreach ($goings as $going) {
            if($going->currentstatus=="Enrolled") {
                $Enrolled += 1;
            }elseif($going->currentstatus=="Started") {
                $Started += 1;
            }elseif($going->currentstatus=="Payment") {
                $Payment += 1;
            }elseif($going->currentstatus=="Processing") {
                $Processing += 1;
            }elseif($going->currentstatus=="Learning") {
                $Learning += 1;
            }elseif($going->currentstatus=="Permanent") {
                $Permanent += 1;
            }elseif($going->currentstatus=="Completed") {
                $Completed += 1;
            }
        }

        $Enrolled = "(".$Enrolled.")";
        $Started = "(".$Started.")";
        $Payment = "(".$Payment.")";
        $Processing = "(".$Processing.")";
        $Learning = "(".$Learning.")";
        $Permanent = "(".$Permanent.")";
        $Completed = "(".$Completed.")";

        $students = Database::table('newdrivinglicense')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'currentstatus' => $currentstatus
        ))->orderBy('createdat', false)->get();
        

        foreach ($students as $student) {
            
            $courseenrolled = Database::table("coursesenrolled")->where("student", $student->student)->first();
            $courseenrolled = Database::table("courses")->where("id", $courseenrolled->course)->first();
            $student->courseenrolled = $courseenrolled->name."<br>Days: ".$courseenrolled->duration;

            $studentinfo = Database::table("users")->where("id", $student->student)->first();
            $student->name = $studentinfo->fname." ".$studentinfo->lname;
            $student->address = $studentinfo->address;

            $data = str_replace(array('-','_'),array('+','/'),$student->timeline);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $student->timeline = base64_decode($data);

            $data = str_replace(array('-','_'),array('+','/'),$student->comment);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $student->comment = base64_decode($data);

            //create timeline

            $gettimeline = explode(";", $student->timeline);
            $student->timeline = "";
            for($i=0;$i<count($gettimeline)-1;$i++) {
                $student->timeline .= "<li class='feed-item'>".$gettimeline[$i]."</li>";
            }
            
        }
        
        return view('newlicense', compact("user", "students","Enrolled","Started","Payment","Processing","Learning","Permanent","Completed"));
    }
  
    
    /**
     * Enroll student Account for New License
     * 
     * @return Json
     */
    public function enroll() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }

        $studentid = escape(input('userid'));

        $checkEnrollment = Database::table("newdrivinglicense")->where("student", $studentid)->first();

        if(!empty($checkEnrollment)){
            return response()->json(responder("error", "Hmm!", "Student has already been enrolled for License", "reload()"));
        }

        $student = Database::table('users')->where(array(
            'role' => 'student',
            'school' => $user->school,
            'branch' => $user->branch,
            'id' => $studentid
        ))->where('isWaiting', "!=", 2)->where('drivinglicense', "<", 3)->first();

        if(!empty($student)){
            
            $data = array(
                "student" => $student->id,
                "currentstatus" => "Enrolled",
                "timeline" => "Enrolled for New License on ".date("d-m-Y").";",
                'school' => $user->school,
                'branch' => $user->branch,
                "createdby" => $user->id
            );

            $comment = base64_encode($data['timeline']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['timeline'] = $comment;

            Database::table("newdrivinglicense")->insert($data);

            $checkEnrollment = Database::table("newdrivinglicense")->where("student", $student->id)->first();

            if(!empty($checkEnrollment)){
                return response()->json(responder("success", "Done!", "Student has been enrolled for New License", "reload()"));
            }else{
                return response()->json(responder("error", "Hmm!", "Someting went wrong.", "reload()"));
            }

        }else{
            return response()->json(responder("error", "Hmm!", "No data found for the selected user.", "reload()"));
        }
        
    }

    /**
     * Move student to enrolled
    *
    */
    public function enrolled(){
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $studentid = escape(input('studentid'));
        $enrollmentid = escape(input('enrollmentid'));
        $students = Database::table('newdrivinglicense')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $enrollmentid
        ))->first();

        if(!empty($students)){

            $data = str_replace(array('-','_'),array('+','/'),$students->timeline);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $students->timeline = base64_decode($data);

            $data = array(
                "currentstatus" => "Enrolled",
                "timeline" => $students->timeline."Moved to Enrolled on ".date("d-m-Y").";"
            );

            $comment = base64_encode($data['timeline']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['timeline'] = $comment;

            Database::table("newdrivinglicense")->where('id', $enrollmentid)->update($data);

            $checkEnrollment = Database::table("newdrivinglicense")->where("student", $students->student)->where("currentstatus", "Enrolled")->first();

            if(!empty($checkEnrollment)){
                return response()->json(responder("success", "Done!", "Student has been moved to Enrolled.", "reload()"));
            }else{
                return response()->json(responder("error", "Hmm!", "Someting went wrong.", "reload()"));
            }
        }else{
            return response()->json(responder("error", "Hmm!", "No record found.", "reload()"));
        }

    }

    /**
     * Move student to started
    *
    */
    public function started(){
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $studentid = escape(input('studentid'));
        $enrollmentid = escape(input('enrollmentid'));
        $students = Database::table('newdrivinglicense')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $enrollmentid
        ))->first();

        if(!empty($students)){

            $data = str_replace(array('-','_'),array('+','/'),$students->timeline);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $students->timeline = base64_decode($data);

            $data = array(
                "currentstatus" => "Started",
                "timeline" => $students->timeline."Moved to Started on ".date("d-m-Y").";"
            );

            $comment = base64_encode($data['timeline']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['timeline'] = $comment;

            Database::table("newdrivinglicense")->where('id', $enrollmentid)->update($data);

            $checkEnrollment = Database::table("newdrivinglicense")->where("student", $students->student)->where("currentstatus", "Started")->first();

            if(!empty($checkEnrollment)){
                return response()->json(responder("success", "Done!", "Student has been moved to Started.", "reload()"));
            }else{
                return response()->json(responder("error", "Hmm!", "Someting went wrong.", "reload()"));
            }
        }else{
            return response()->json(responder("error", "Hmm!", "No record found.", "reload()"));
        }

    }

    /**
     * Move student to Payment Phase
    *
    */
    public function payment(){
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $studentid = escape(input('studentid'));
        $enrollmentid = escape(input('enrollmentid'));
        $students = Database::table('newdrivinglicense')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $enrollmentid
        ))->first();

        if(!empty($students)){

            $data = str_replace(array('-','_'),array('+','/'),$students->timeline);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $students->timeline = base64_decode($data);

            $data = array(
                "currentstatus" => "Payment",
                "timeline" => $students->timeline."Moved to Payment Phase on ".date("d-m-Y").";"
            );

            $comment = base64_encode($data['timeline']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['timeline'] = $comment;

            Database::table("newdrivinglicense")->where('id', $enrollmentid)->update($data);

            $checkEnrollment = Database::table("newdrivinglicense")->where("student", $students->student)->where("currentstatus", "Payment")->first();

            if(!empty($checkEnrollment)){
                return response()->json(responder("success", "Done!", "Student has been moved to Payment Phase.", "reload()"));
            }else{
                return response()->json(responder("error", "Hmm!", "Someting went wrong.", "reload()"));
            }
        }else{
            return response()->json(responder("error", "Hmm!", "No record found.", "reload()"));
        }

    }

    /**
    * Move student to Payment Phase
    *
    */
    public function processing(){
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $studentid = escape(input('studentid'));
        $enrollmentid = escape(input('enrollmentid'));
        $students = Database::table('newdrivinglicense')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $enrollmentid
        ))->first();

        if(!empty($students)){

            $data = str_replace(array('-','_'),array('+','/'),$students->timeline);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $students->timeline = base64_decode($data);

            $data = array(
                "currentstatus" => "Processing",
                "timeline" => $students->timeline."Moved to Processing Phase on ".date("d-m-Y").";"
            );

            $comment = base64_encode($data['timeline']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['timeline'] = $comment;

            Database::table("newdrivinglicense")->where('id', $enrollmentid)->update($data);

            $checkEnrollment = Database::table("newdrivinglicense")->where("student", $students->student)->where("currentstatus", "Processing")->first();

            if(!empty($checkEnrollment)){
                return response()->json(responder("success", "Done!", "Student has been moved to Processing Phase.", "reload()"));
            }else{
                return response()->json(responder("error", "Hmm!", "Someting went wrong.", "reload()"));
            }
        }else{
            return response()->json(responder("error", "Hmm!", "No record found.", "reload()"));
        }

    }

    /**
    * Move student to Learning Phase
    *
    */
    public function learning(){
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $studentid = escape(input('studentid'));
        $enrollmentid = escape(input('enrollmentid'));
        $students = Database::table('newdrivinglicense')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $enrollmentid
        ))->first();

        if(!empty($students)){

            $data = str_replace(array('-','_'),array('+','/'),$students->timeline);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $students->timeline = base64_decode($data);

            $data = array(
                "currentstatus" => "Learning",
                "timeline" => $students->timeline."Moved to Learning License Phase on ".date("d-m-Y").";"
            );

            $comment = base64_encode($data['timeline']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['timeline'] = $comment;

            Database::table("newdrivinglicense")->where('id', $enrollmentid)->update($data);

            $checkEnrollment = Database::table("newdrivinglicense")->where("student", $students->student)->where("currentstatus", "Learning")->first();

            if(!empty($checkEnrollment)){
                return response()->json(responder("success", "Done!", "Student has been moved to Learning License Phase.", "reload()"));
            }else{
                return response()->json(responder("error", "Hmm!", "Someting went wrong.", "reload()"));
            }
        }else{
            return response()->json(responder("error", "Hmm!", "No record found.", "reload()"));
        }

    }

    /**
    * Move student to Permanent License Phase
    *
    */
    public function permanent(){
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $studentid = escape(input('studentid'));
        $enrollmentid = escape(input('enrollmentid'));
        $students = Database::table('newdrivinglicense')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $enrollmentid
        ))->first();

        if(!empty($students)){

            $data = str_replace(array('-','_'),array('+','/'),$students->timeline);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $students->timeline = base64_decode($data);

            $data = array(
                "currentstatus" => "Permanent",
                "timeline" => $students->timeline."Moved to Permanent License Phase on ".date("d-m-Y").";"
            );

            $comment = base64_encode($data['timeline']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['timeline'] = $comment;

            Database::table("newdrivinglicense")->where('id', $enrollmentid)->update($data);

            $checkEnrollment = Database::table("newdrivinglicense")->where("student", $students->student)->where("currentstatus", "Permanent")->first();

            if(!empty($checkEnrollment)){
                return response()->json(responder("success", "Done!", "Student has been moved to Permanent License Phase.", "reload()"));
            }else{
                return response()->json(responder("error", "Hmm!", "Someting went wrong.", "reload()"));
            }
        }else{
            return response()->json(responder("error", "Hmm!", "No record found.", "reload()"));
        }

    }

    /**
    * Move student to Completed Phase
    *
    */
    public function completed(){
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $studentid = escape(input('studentid'));
        $enrollmentid = escape(input('enrollmentid'));
        $students = Database::table('newdrivinglicense')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $enrollmentid
        ))->first();

        if(!empty($students)){

            $data = str_replace(array('-','_'),array('+','/'),$students->timeline);
            $mod4 = strlen($data) % 4;
            if ($mod4) {
                $data .= substr('====', $mod4);
            }
            $students->timeline = base64_decode($data);

            $data = array(
                "currentstatus" => "Completed",
                "timeline" => $students->timeline."Moved to Completed License list on ".date("d-m-Y").";"
            );

            $comment = base64_encode($data['timeline']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['timeline'] = $comment;

            Database::table("newdrivinglicense")->where('id', $enrollmentid)->update($data);

            $checkEnrollment = Database::table("newdrivinglicense")->where("student", $students->student)->where("currentstatus", "Completed")->first();

            if(!empty($checkEnrollment)){
                return response()->json(responder("success", "Done!", "Student has been moved to Completed License List.", "reload()"));
            }else{
                return response()->json(responder("error", "Hmm!", "Someting went wrong.", "reload()"));
            }
        }else{
            return response()->json(responder("error", "Hmm!", "No record found.", "reload()"));
        }

    }

    /**
    * Move student to Udpate Comments
    *
    */
    public function updatecomment(){
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $studentid = escape(input('studentid'));
        $enrollmentid = escape(input('enrollmentid'));
        $students = Database::table('newdrivinglicense')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $enrollmentid
        ))->first();

        if(!empty($students)){

            $data = array(
                "comment" => escape(input('comment'))
            );

            $comment = base64_encode($data['comment']);
            $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
            $data['comment'] = $comment;

            Database::table("newdrivinglicense")->where('id', $enrollmentid)->update($data);

            return response()->json(responder("success", "Done!", "Student comments has been succesfully updated.", "reload()"));

        }else{
            return response()->json(responder("error", "Hmm!", "No record found.", "reload()"));
        }

    }

    /**
    * Remove Students
    *
    */
    public function cancelled(){
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $studentid = escape(input('studentid'));
        $enrollmentid = escape(input('enrollmentid'));
        
        Database::table('newdrivinglicense')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $enrollmentid
        ))->delete();

        $student = Database::table('newdrivinglicense')->where(array(
            'school' => $user->school,
            'branch' => $user->branch,
            'student' => $studentid,
            'id' => $enrollmentid
        ))->first();

        if(!empty($student)){

            return response()->json(responder("error", "Hmm!", "No record found to delete.", "reload()"));

        }else{

            return response()->json(responder("success", "Done!", "Student has been successfully removed from list.", "reload()"));

        }

    }

}
