<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\File;
use Simcify\Database;
use DotEnvWriter\DotEnvWriter;
use Simcify\Sms;
use Simcify\Landa;

class ScheduleNotification {

    /**
     * Send Notifications view
     * 
     * @return \Pecee\Http\Response
     */
        public function get() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        if ($user->role == 'staff' && $user->position != 'manager') {
            return view('errors/404');
        }
        $success = 0;
        $failed = 0;
        $pending = Database::table("usermessages")->where("status", "Pending")->get();
        foreach($pending as $pending){
            $send = Sms::africastalking($pending->contact, urldecode($pending->message));
            if ($send) { 
                $status = "Sent"; 
                $success++;
            } else { 
                $status = "Failed"; 
                $failed++;
            }
            Database::table("usermessages")->where('id', $pending->id)->update(array(
                "status" => $status,
                "sent_at" => date("d-m-Y H:i:s")
            ));
        }

        $lastsync = date("d-m-Y H:i:s");

        $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();
        $managernotify = "Dear ".$manager->fname.",\n\nAll the pending messages has been sent.\n\nStatus: Sent: ".$success."\nFailed: ".$failed."\nLast Sync: ".$lastsync."\n\n".env("APP_NAME");
        if (!empty($manager->phone)) {
	        $send = Sms::africastalking($manager->phone, $managernotify);
            if ($send) {
                return response()->json(responder("success", "Alright", "All Notifications has been sent. Sent: ".$success.", Failed: ".$failed.", Last Sync: ".$lastsync));
            } else { 
                return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
            }
    	}
    }
}

