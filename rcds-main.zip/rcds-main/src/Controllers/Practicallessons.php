<?php
namespace Simcify\Controllers;

use Simcify\Database;
use Simcify\Landa;
use Simcify\Auth;
use Simcify\Mail;

class Practicallessons{

    /**
     * Get students view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin') {
            return view('errors/404');
        }
        $practicallessons = Database::table('practicallessons')->get();
        return view('practicallessons', compact("user", "practicallessons"));
    }
  
    
    /**
     * Create New Lesson
     * 
     * @return Json
     */
    public function create() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin') {
            return view('errors/404');
        }
        $name = Database::table("practicallessons")->where("name", input('lname'))->first();
        if (!empty($name)) {
            return response()->json(array(
                "status" => "error",
                "title" => "Name Already exists.",
                "message" => "Lesson Already exists."
            ));
        }
        if(input('lname')!="" && input('ldesc')!="" && input('lstatus')!=""){
        $data = array(
            "name" => escape(input("lname")),
            "description" => escape(input("ldesc")),
            "status" => escape(input("lstatus"))
        );
   
        Database::table("practicallessons")->insert($data);

        return response()->json(responder("success", "Lesson Added", "New lesson successfully added", "reload()"));
        }else { 
            return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
        }

    }

    /**
     * Update Lesson
     * 
     * @return Json
     */
    public function update() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin') {
            return view('errors/404');
        }
        $name = Database::table("practicallessons")->where("name", input('lname'))->first();
        if (!empty($name)) {
            return response()->json(array(
                "status" => "error",
                "title" => "Name Already exists.",
                "message" => "Lesson Already exists."
            ));
        }
        if(input('lname')!="" && input('ldesc')!="" && input('lstatus')!="" && input('lessonid')!=""){
        $data = array(
            "name" => escape(input("lname")),
            "description" => escape(input("ldesc")),
            "status" => escape(input("lstatus"))
        );
   
        Database::table("practicallessons")->where('id', input('lessonid'))->update($data);

        return response()->json(responder("success", "Lesson Updated", "Lesson successfully Updated", "reload()"));
        }else { 
            return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
        }

    }


    /**
     * Active Lesson
     * 
     * @return Json
     */
    public function active() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin') {
            return view('errors/404');
        }

        if(input('lessonid')!=""){

        $data = array(
            "status" => 1
        );
   
        Database::table("practicallessons")->where('id', input('lessonid'))->update($data);

        return response()->json(responder("success", "Lesson Activated", "Lesson successfully Activated", "reload()"));
        }else { 
            return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
        }

    }


    /**
     * Inactive Lesson
     * 
     * @return Json
     */
    public function inactive() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin') {
            return view('errors/404');
        }
        if(input('lessonid')!=""){

        $data = array(
            "status" => 0
        );
   
        Database::table("practicallessons")->where('id', input('lessonid'))->update($data);

        return response()->json(responder("success", "Lesson Inactive", "Lesson successfully Inactivated", "reload()"));
        }else { 
            return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
        }

    }


    /**
     * delete Lesson
     * 
     * @return Json
     */
    public function delete() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin') {
            return view('errors/404');
        }
        if(input('lessonid')!=""){
   
        Database::table("practicallessons")->where("id", input("lessonid"))->delete();

        return response()->json(responder("success", "Lesson Deleted", "Lesson successfully Deleted", "reload()"));
        }else { 
            return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
        }

    }


    /**
     * Add course
    *
    */
    public function addcourse(){
        self::enroll(escape(input("studentid")), escape(input("newcourse")));
        self::createinvoice(escape(input("studentid")), escape(input("newcourse")), escape(input("amountpaid")), escape(input("method")));
        return response()->json(responder("success", "Alright", "Student successfully enrolled to the course", "reload()"));
    }


}
