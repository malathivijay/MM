<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\File;
use Simcify\Database;
use DotEnvWriter\DotEnvWriter;
use Simcify\Sms;

class Records {

    /**
     * Get settings view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user      = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $error = 1;
        if ($user->role == 'staff') {
            if ($user->position == 'amanager') {
                $error = 0;
            }elseif($user->position = 'manager') {
                $error = 0;
            }
        }

        if($user->role == 'staff' && $errro==1){
            return view('errors/404');
        }

        //if user is Assistantmanager

        if($user->role == 'staff' && $user->position == 'amanager') {
            $_GET['view']="maintainancerecords";
        }

        if(isset($_GET['startdate']) && isset($_GET['enddate'])){
            $sdate = escape(input('startdate'));
            $edate = escape(input('enddate'));
            $cdate = date("Y-m-d");
            $agendaDayStart = $sdate." 00:00:00";
			$agendaDayEnd = $edate." 23:59:59";
			$range = $agendaDayStart."' AND '".$agendaDayEnd;
            $range2 = $sdate."' AND '".$edate;

       if (!isset($_GET['view'])) {
            $payments = Database::table('payments')->leftJoin('invoices','payments.invoice','invoices.id')->leftJoin('users','payments.student','users.id')->where('payments`.`branch',$user->branch)->where('payments`.`school',$user->school)->where('payments`.`created_at','BETWEEN',$range)->orderBy('payments.created_at', false)->get("`payments.amount`","`payments.invoice`","`payments.id`","`payments.method`","`payments.created_at`","`users.fname`","`users.id` as `userid`","`users.lname`","`users.phone`","`invoices.item`","`invoices.reference`");

        }elseif (isset($_GET['view']) && $_GET['view'] == "cng") {
            $fuel = Database::table('fuel')->leftJoin('users','fuel.recordby','users.id')->leftJoin('fleet','fuel.car','fleet.id')->where('fuel`.`branch',$user->branch)->where('fuel`.`school',$user->school)->where('fuel`.`date','BETWEEN',$range2)->orderBy('fuel.date', false)->get("`fuel.id`","`users.fname`","`users.lname`","`fuel.type`","`fuel.date`","`fuel.lastupdate`","`fuel.amount`","`fuel.photo`","`fuel.odo`","`fuel.reading`","`fuel.comment`","`fleet.carplate`");
            foreach($fuel as $fue){
                if($fue->type==1){
                    $fue->type = "CNG";
                }elseif($fue->type==2){
                    $fue->type = "Petrol";
                }
                $data = str_replace(array('-','_'),array('+','/'),$fue->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $fue->comment = base64_decode($data);
            }
        }elseif (isset($_GET['view']) && $_GET['view'] == "other") {
            $expenses = Database::table('expenses')->leftJoin('users','expenses.recordby','users.id')->leftJoin('fleet','expenses.car','fleet.id')->where('expenses`.`branch',$user->branch)->where('expenses`.`school',$user->school)->where('expenses`.`date','BETWEEN',$range2)->orderBy('expenses.date', false)->get("`expenses.id`","`users.fname`","`users.lname`","`expenses.type`","`expenses.date`","`expenses.car`","`expenses.lastupdate`","`expenses.amount`","`expenses.photo`","`expenses.comment`","`fleet.carplate`");

            foreach($expenses as $expense){
                if($expense->car==0){
                    $expense->carplate="office";
                }
                $data = str_replace(array('-','_'),array('+','/'),$expense->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $expense->comment = base64_decode($data); 
            }
        }elseif (isset($_GET['view']) && $_GET['view'] == "dropout") {

            $dropout = Database::table('dropreading')->leftJoin('users','dropreading.recordby','users.id')->leftJoin('fleet','dropreading.car','fleet.id')->where('dropreading`.`branch',$user->branch)->where('dropreading`.`school',$user->school)->where('dropreading`.`date','BETWEEN',$range2)->orderBy('dropreading.date', false)->get("`dropreading.id`","`users.fname`","`users.lname`","`dropreading.reading`","`dropreading.date`","`dropreading.lastupdate`","`dropreading.photo`","`dropreading.comment`","`fleet.carplate`");

            foreach($dropout as $drop){
                $data = str_replace(array('-','_'),array('+','/'),$drop->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $drop->comment = base64_decode($data);          
            }

            $fleet = Database::table('fleet')->get();
        }

            return view('records', compact("user",'payments','fuel','expenses','dropout','cdate','date','fleet'));

        }else{
       $cdate = date("Y-m-d");
       if (!isset($_GET['view'])) {
            $payments = Database::table('payments')->leftJoin('invoices','payments.invoice','invoices.id')->leftJoin('users','payments.student','users.id')->where('payments`.`branch',$user->branch)->where('payments`.`school',$user->school)->orderBy('payments.created_at', false)->get("`payments.amount`","`payments.invoice`","`payments.id`","`payments.method`","`payments.created_at`","`users.fname`","`users.id` as `userid`","`users.lname`","`users.phone`","`invoices.item`","`invoices.reference`");

        }elseif (isset($_GET['view']) && $_GET['view'] == "cng") {
            $fuel = Database::table('fuel')->leftJoin('users','fuel.recordby','users.id')->leftJoin('fleet','fuel.car','fleet.id')->where('fuel`.`branch',$user->branch)->where('fuel`.`school',$user->school)->orderBy('fuel.date', false)->get("`fuel.id`","`users.fname`","`users.lname`","`fuel.type`","`fuel.date`","`fuel.lastupdate`","`fuel.amount`","`fuel.photo`","`fuel.odo`","`fuel.reading`","`fuel.comment`","`fleet.carplate`");
            foreach($fuel as $fue){
                if($fue->type==1){
                    $fue->type = "CNG";
                }elseif($fue->type==2){
                    $fue->type = "Petrol";
                }
                $data = str_replace(array('-','_'),array('+','/'),$fue->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $fue->comment = base64_decode($data);
            }
        }elseif (isset($_GET['view']) && $_GET['view'] == "other") {
            $expenses = Database::table('expenses')->leftJoin('users','expenses.recordby','users.id')->leftJoin('fleet','expenses.car','fleet.id')->where('expenses`.`branch',$user->branch)->where('expenses`.`school',$user->school)->orderBy('expenses.date', false)->get("`expenses.id`","`users.fname`","`users.lname`","`expenses.type`","`expenses.date`","`expenses.car`","`expenses.lastupdate`","`expenses.amount`","`expenses.photo`","`expenses.comment`","`fleet.carplate`");

            foreach($expenses as $expense){
                if($expense->car==0){
                    $expense->carplate="office";
                }
                $data = str_replace(array('-','_'),array('+','/'),$expense->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $expense->comment = base64_decode($data); 
            }
        }elseif (isset($_GET['view']) && $_GET['view'] == "servicerecords") {
            $servicerecords = Database::table('servicerecords')->leftJoin('fleet','servicerecords.car','fleet.id')->leftJoin('users','servicerecords.recordby','users.id')->where('servicerecords`.`branch',$user->branch)->where('servicerecords`.`school',$user->school)->orderBy('servicerecords.date', false)->get("`servicerecords.id`","`users.fname`","`users.lname`","`servicerecords.date`","`servicerecords.reading`","`servicerecords.servicekm`","`servicerecords.iskmreset`","`servicerecords.nextservicekm`","`servicerecords.comments`","`fleet.carplate`");

            foreach($servicerecords as $servicerecord){
                $data = str_replace(array('-','_'),array('+','/'),$servicerecord->comments);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $servicerecord->comments = base64_decode($data); 
            }
        }elseif (isset($_GET['view']) && $_GET['view'] == "dropout") {

            $dropout = Database::table('dropreading')->leftJoin('users','dropreading.recordby','users.id')->leftJoin('fleet','dropreading.car','fleet.id')->where('dropreading`.`branch',$user->branch)->where('dropreading`.`school',$user->school)->orderBy('dropreading.date', false)->get("`dropreading.id`","`users.fname`","`users.lname`","`dropreading.reading`","`dropreading.date`","`dropreading.lastupdate`","`dropreading.photo`","`dropreading.comment`","`fleet.carplate`");

            foreach($dropout as $drop){
                $data = str_replace(array('-','_'),array('+','/'),$drop->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $drop->comment = base64_decode($data);          
            }

            $fleet = Database::table('fleet')->get();
        }elseif (isset($_GET['view']) && $_GET['view'] == "maintainancerecords") {
            $maintainancerecords = Database::table('fleetmaintainancerecords')->where('branch',$user->branch)->where('school',$user->school)->orderBy('date', false)->get();

            foreach($maintainancerecords as $maintainancerecord){

                //getting comment in plain text

                $data = str_replace(array('-','_'),array('+','/'),$maintainancerecord->comments);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $maintainancerecord->comments = base64_decode($data); 

                //getting created by user name

                $createdby = Database::table('users')->where('id',$maintainancerecord->createdby)->first();
                $maintainancerecord->createdby = $createdby->fname." ".$createdby->lname;

                //get care plate

                $car = Database::table('fleet')->where('id',$maintainancerecord->car)->first();
                $maintainancerecord->carplate = $car->carplate;
            }
        }

            return view('records', compact("user",'payments','fuel','expenses','dropout','cdate','date','fleet','servicerecords',"maintainancerecords"));
    }
}

}