<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\File;
use Simcify\Database;
use DotEnvWriter\DotEnvWriter;
use Simcify\Sms;

class Updatestudentaadhar {

    /**
     * Get settings view
     * 
     * @return \Pecee\Http\Response
     */
    public function get($studentid) {
        $user      = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
          }
        $profile = Database::table('users')->where("branch", $user->branch)->where("school", $user->school)->where("role","student")->where("id",$studentid)->first("`users.id`","`users.fname`", "`users.lname`");

        if($profile->fname!=""){
        return view('updatestudentaadhar', compact("user","profile","studentid"));
        }elseif($user->role!="instructor"){
            redirect(url('Profile@get',['userid'=>$studentid]));
        }else{
            redirect(url("Today@get"));
        }
    }

    /**
     * Update Student Details
     * 
     * @return Json
     */
    public function update() {
        $user = Auth::user();
        $studentid = escape(input('studentid'));
        $student = Database::table('users')->where("branch", $user->branch)->where("school", $user->school)->where("role","student")->where("id",$studentid)->first("`users.id`","`users.fname`", "`users.lname`");

        if($student->fname==""){
            return response()->json(responder("error", "HMM!", "Something went wrong. Student not found","reload()"));
        }

        $data = array();
        foreach (input()->post as $field) {
            
                if ($field->index == "aadharfront") {
                    if (!empty($field->value)) {
                        $aadhar = File::upload($field->value, "aadhar", array(
                            "source" => "base64",
                            "extension" => "png"
                        ));
                        if ($aadhar['status'] == "success") {
                            $data['aadharfront']=$aadhar['info']['name'];
                        }
                    }
                    continue;
                }
                if ($field->index == "aadharback") {
                    if (!empty($field->value)) {
                        $aadhar2 = File::upload($field->value, "aadhar", array(
                            "source" => "base64",
                            "extension" => "png"
                        ));
                        if ($aadhar2['status'] == "success") {
                            $data['aadharback']=$aadhar2['info']['name'];
                        }
                    }
                    continue;
                }
                if ($field->index == "studentid") {
                    continue;
                }
                if ($field->index == "csrf-token") {
                    continue;
                }
                if ($field->index == "aadhar") {
                    
                    $data['aadhar']= escape($field->value);
                    
                    continue;
                }
            
                continue;
        }
            
        Database::table('users')->where("id",$studentid)->update($data);
 
        $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();
        $instructor = Database::table("users")->where("id", $user->id)->where("school", $user->school)->where("branch", $user->branch)->first();
        $student = Database::table('users')->where("id",$studentid)->first();

        if($student->aadhar=="" ||$student->aadharfront=="" ||$student->aadharback==""){
            File::delete($data['avatar'], "avatar");
            File::delete($data['aadharfront'], "aadhar");
            File::delete($data['aadharback'], "aadhar");
            Database::table('users')->where("id",$studentid)->update(array("aadhar" => "","aadharfront" => "","aadharback" => ""));
            return response()->json(responder("error", "HMM!", "Not able to update data. Please contact your manager.","reload()"));
        }

        if(strlen($instructor->phone)>10){
			$iphone = substr($instructor->phone,-10);
		}
		else{
			$iphone = $instructor->phone;
		}
        if(strlen($manager->phone)>10){
			$mphone = substr($manager->phone,-10);
		}
		else{
			$mphone = $manager->phone;
		}
        if(strlen($student->phone)>10){
			$sphone = substr($student->phone,-10);
		}
		else{
			$sphone = $student->phone;
		}

        $studentnotify = "Dear ".$student->fname." ".$student->lname.",\n\nMr. ".$manager->fname." ".$manager->lname." Ph: ".$iphone." (Manager) has updated the aadhar/profile details record for you.\n\nAadhar Number: ".$student->aadhar."\n\nIf you have any query. Please feel free to connect him anytime.\n\nRegards,\n".env("APP_NAME");

        $managernotify = "*Update Notification*\n\nThe aadhar/profile details for ".$student->fname." ".$student->lname." Ph: ".$sphone." has been update Successfully. \n\nRegards,\n".env("APP_NAME");

        $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
        if (!empty($manager->phone)) {
	        $send = Sms::africastalking($manager->phone, $managernotify);
            if ($send) {
                if (!empty($student->phone)) {
                    $send = Sms::africastalking($student->phone, $studentnotify);
                    if ($send) {
                        return response()->json(responder("success", "Done", "Details Saved Successfully", "reload()"));
                    } else { 
                        return response()->json(responder("error", "HMM!", "Not able to notify the student. Please share the screenshot with your manager.","reload()"));
                    }
                }
            } else { 
                return response()->json(responder("error", "HMM!", "Not able to notify the student and manager. Please share the screenshot with your manager.","reload()"));
            }
    	}

        return response()->json(responder("error", "HMM!", "Details has been save but not able to notify the manager and the student. Please connect with your Manager and share the detials.","reload()"));
    }

}