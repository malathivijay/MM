<?php
namespace Simcify\Controllers;

use Simcify\Database;
use Simcify\Landa;
use Simcify\Auth;
use Simcify\Sms;

class Marked{

    /**
     * Get Attendance view
     * 
     * @return \Pecee\Http\Response
     */

    public function get() {
      $user = Auth::user();
      if ($user->role != 'instructor') {
        return view('errors/404');
      }
      $date = date("Y-m-d");
      $cdate = date("Y-m-d");
      $marked = Database::table('users')->leftJoin('attendance','users.id','attendance.id')->leftJoin('invoices','users.id','invoices.student')->leftJoin('schedules','users.id','schedules.student')->where("users`.`branch", $user->branch)->where("users`.`school", $user->school)->where("users`.`isWaiting",0)->where("attendance`.`date", $date)->where("schedules`.`instructor", $user->id)->where("schedules`.`start", "LIKE", "%" . $date . "%")->orderBy('users.id', false)->get("`users.fname`", "`users.lname`", "`users.avatar`", "`users.email`", "`users.address`","`attendance.id`", "`attendance.status`", "`attendance.isstarted`", "`attendance.lastupdate`", "`attendance.date`","`invoices.amount`","`invoices.amountpaid`","`schedules.instructor`","`schedules.id` as scheduleid");

      $isFound = "";
      $instructors = Database::table("users")->get();
      $courses = Database::table("courses")->get();

      return view('marked', compact("marked","user","invoices","date","cdate","instructors","isFound","courses"));
    }
    
    /**
     * Update Attendance
     * 
     * @return Json
     */
    public function reset() {
      $user = Auth::user();
      $data2 = array(
        "status" => "New"
      );
      $sdate = date("Y-m-d");
      Database::table("schedules")->where("id", input("scheduleid"))->where("student", input('studentid'))->where("instructor", $user->id)->where("status", '!=', "Complete")->where("start", "LIKE", "%" . $sdate . "%")->update($data2);

      $getupdate = Database::table("schedules")->where("id", input("scheduleid"))->where("student", input('studentid'))->where("instructor", $user->id)->where("start", "LIKE", "%" . $sdate . "%")->first();

      if($getupdate->status=="New"){

      $null = "";

      $data = array(
        "status" => 0,
        "isstarted" => 0,
        "starttime" => "00:00:00",
        "endtime" => "00:00:00"
      );

      Database::table("attendance")->where("id", $getupdate->student)->where('date', $sdate)->update($data);
      $instructor = Database::table("users")->where("id", $getupdate->instructor)->first();
      $manager = Database::table("users")->where("branch", $getupdate->branch)->where("school", $getupdate->school)->where("position", "manager")->first();
      $superadmin = Database::table("users")->where("role", "superadmin")->first();
      $fleet = Database::table("fleet")->where("instructor", $getupdate->instructor)->first();
      $fleetname = substr($fleet->phone,-4);
      $student = Database::table("users")->where("id", $getupdate->student)->first();
      $notification = 'Trainer - '.$instructor->fname.' ('.$fleetname.') has resetted the 
      <strong>'.$student->fname.' attendance at '.date("d-m-Y h:i:s A").'</strong>.';
      Landa::notify($notification, $manager->id, "update", "school");
      Landa::notify($notification, $superadmin->id, "update", "school");
      return response()->json(responder("success", "Attendance Resetted", "Student Attendence has been resetted Successfully.", "reload()"));
      }
      else{
        return response()->json(responder("error", "Hmm!", "Something went wrong please try again."));
      }
    }

    public function markpresent() {
      $user = Auth::user();
      if ($user->role != 'instructor') {
          return view('errors/404');
      }

      $tclass = escape(input('tclass'));

      if($tclass==0){
        return response()->json(responder("error", "HMM!", "Please select how many class has been completed today."));
      }

      $plessons = Database::table("practicallessons")->where('status', 1)->get();
      $pl = "";
      $plid = "";
      $plcid = array();

      foreach($plessons as $key1 => $plessons){
        $pl = "lesson".$plessons->id;
        if(input($pl)=="on"){
        $plid .= $plessons->id.",";
        }
      }

      if($plid==""){
        return response()->json(responder("error", "HMM!", "Please select atleast one Lesson before ending the class."));
      }

      $studentid = escape(input('studentid'));
      $scheduleid = escape(input('scheduleid'));
      $date = date("Y-m-d");
      $data = array(
          "status" => "Complete"
      );

      $completed = Database::table('schedules')->where('student', $studentid)->where('status', "Complete")->count("id", "total")[0]->total;

      Database::table("schedules")->where('student', $studentid)->where('school', $user->school)->where('id', $scheduleid)->where('instructor', $user->id)->where('branch', $user->branch)->where('start', "LIKE", "%" . $date . "%")->update($data);

      $schedule = Database::table("schedules")->where('student', $studentid)->where('school', $user->school)->where('id', $scheduleid)->where('status', "Complete")->where('instructor', $user->id)->where('branch', $user->branch)->where('start', "LIKE", "%" . $date . "%")->first();

      $attendence = Database::table("attendance")->where('id', $schedule->student)->where('date', $date)->first();

      if($schedule->status=="Complete"){
      
      $last= strlen($plid)-1;
      $plid = substr($plid,0,$last);

      $length = date("i");
      if($length>30){
        $length = $length/2;
        $length = round($length,0);
      }
      $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
      $charactersLength = strlen($characters);
      $randomString = '';
      for ($i = 0;$i<$length;$i++) {
          $randomString .= $characters[rand(0, $charactersLength - 1)];
      }

      $stime = date("H:i:s");

      $data2 = array(
          "isstarted" => 0,
          "status" => 2,
          "setendtime" => $stime,
          "trainingitems" => $plid,
          "customerlink" => $randomString
      );

      Database::table("attendance")->where('id', $schedule->student)->where('date', $date)->update($data2);
      $uAttend = Database::table("attendance")->where('id', $schedule->student)->where('date', $date)->get();

    if($tclass>1){
      
      $data3 = array(
        "note_by" => $user->id,
        "note_for" => $studentid
      );

      //mark the classes as complete from last for the respective student in schedules
      $getAllClass = Database::table("schedules")->where('student', $studentid)->where('school', $user->school)->where('branch', $user->branch)->where('instructor', $user->id)->where('status', "New")->orderBy('start', false)->get();

      $cl=$tclass;

      foreach($getAllClass as $gaclass){
        if($cl!=1){
          //Adding new classess for th same date,time and status in schedules and attendence
          $newdata = array(
            'school'=>$schedule->school,
            'branch'=>$schedule->branch,
            'start'=>$schedule->start,
            'end'=>$schedule->end,
            'course'=>$schedule->course,
            'student'=>$schedule->student,
            'instructor'=>$schedule->instructor,
            'class_type'=>$schedule->class_type,
            'car'=>$schedule->car,
            'status'=>$schedule->status
          );
          Database::table("schedules")->insert($newdata);

          $newdata2 = array(
            'id'=>$schedule->student,
            'school'=>$schedule->school,
            'branch'=>$schedule->branch,
            'date'=>date('Y-m-d', strtotime($schedule->start)),
            "isstarted" => 0,
            "status" => 2,
            "setendtime" => $stime,
            "trainingitems" => $plid,
            "customerlink" => $randomString
          );
          Database::table("attendance")->insert($newdata2);

          //delete class from end in Schedules and Attendence
          Database::table("schedules")->where('id', $gaclass->id)->delete();
          $updateDate = date('Y-m-d', strtotime($gaclass->start));
          Database::table("attendance")->where('id', $schedule->student)->where('date', $updateDate)->delete();

          //inserting note

          $instructor = Database::table("users")->where("id", $user->id)->where("school", $user->school)->where("branch", $user->branch)->first();

          $newNote = "Date: ".$updateDate." Class has been removed and added completed classs for ".$date." as Mr. ".$instructor->fname." has completed multiple classess on ".$date;

          $data3['note'] = $newNote;

          Database::table("notes")->insert($data3);

          $cl--;
        }else{
          break;
        }
      }
    }



        $date = date("Y-m-d");
        $student = Database::table("users")->where("id", $schedule->student)->where("school", $user->school)->where("branch", $user->branch)->first();
        $instructor = Database::table("users")->where("id", $user->id)->where("school", $user->school)->where("branch", $user->branch)->first();
        $course = Database::table("courses")->where("id", $schedule->course)->where("school", $user->school)->where("branch", $user->branch)->first();
        $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();
        $payments = Database::table("invoices")->where("student", $student->id)->first();
        $attend = Database::table("attendance")->where("id", $student->id)->where('date', $date)->first();
        if($tclass>1){
         for($i=1;$i<=$tclass;$i++){
          $completed++;
            if($completed==11){
              $class .= $completed."th";
            }elseif($completed==12){
              $class .= $completed."th";
            }elseif($completed==13){
              $class .= $completed."th";
            }elseif(substr($completed,-1)==1){
                $class .= $completed."st";
            }elseif(substr($completed,-1)==2){
              $class .= $completed."nd";
            }elseif(substr($completed,-1)==3){
              $class .= $completed."rd";
            }else{
                $class .= $completed."th";
            }
            if($i==$tclass-1){
              $class .= " and ";
            }elseif($i<$tclass-1){
              $class .= ", ";
            }
          }
        }else{
          $completed = Database::table('schedules')->where('student', $student->id)->where('status', "Complete")->count("id", "total")[0]->total;
          if($completed==11){
            $class = $completed."th";
          }elseif($completed==12){
            $class = $completed."th";
          }elseif($completed==13){
            $class = $completed."th";
          }elseif(substr($completed,-1)==1){
              $class = $completed."st";
          }elseif(substr($completed,-1)==2){
            $class = $completed."nd";
          }elseif(substr($completed,-1)==3){
            $class = $completed."rd";
          }else{
              $class = $completed."th";
          }

        }
        $balance = $payments->amount-$payments->amountpaid;
        if($balance>0){
            $payment = " whose pending payment is ".$balance." /- Rs.";
        }else{
            $payment = " who has done full payment already.";
        }
        if(strlen($student->phone)>10){
			$sphone = substr($student->phone,-10);
		}
		else{
			$sphone = $student->phone;
		}
          if(strlen($instructor->phone)>10){
        $iphone = substr($instructor->phone,-10);
      }
      else{
        $iphone = $instructor->phone;
      }
      if(strlen($manager->phone)>10){
        $mphone = substr($manager->phone,-10);
      }
      else{
        $mphone = $manager->phone;
      }
        $managerMessage = "Dear ".$manager->fname.", Mr. ".$instructor->fname." (".$iphone.") has completed the ".$class." class today with ".$student->fname." (".$sphone.") enrolled in ".$course->name." course for ".$course->duration." Days from ".$student->address." at ".$date." ".$stime.$payment."\n\n".env("APP_NAME")."\n\n".$gacdetails;
/*         $studentMessage = "Dear ".$student->fname.", thankyou for completing your ".$class." class with Mr. ".$instructor->fname." (".$iphone."). We hope your you had a great learning experience today.\n\nKindly click on the link to verify your today's learnings: https://student.realcardriving.com/".$attend->customerlink."\n\nRegards,\n".env("APP_NAME"); */

          $studentMessage = "Dear ".$student->fname.", thankyou for completing your ".$class." class with Mr. ".$instructor->fname." (".$iphone."). We hope you had a great learning experience today.\n\nKindly contact with Mr. ".$manager->fname." at (".$mphone.")for any query.\n\nRegards,\n".env("APP_NAME");

          $branchwgroup = Database::table("branches")->where("id", $user->branch)->where("school", $user->school)->first();
          if (!empty($manager->phone)) {

                  Database::table("usermessages")->insert(array(
                    "receiver" => $manager->id, 
                    "type" => "whatsapp", 
                    "contact" => $manager->phone,
                    "Subject" => "Class Completed",
                    "message" => escape($managerMessage),
                    "scheduled_at" => date("d-m-Y H:i:s"),
                    "sent_by" => $user->id,
                    "school" => $manager->school, 
                    "branch" => $manager->branch, 
                    "status" => "Pending"
                  ));

                  Database::table("usermessages")->insert(array(
                    "receiver" => $student->id, 
                    "type" => "whatsapp", 
                    "contact" => $student->phone,
                    "Subject" => "Class Completed",
                    "message" => escape($studentMessage),
                    "scheduled_at" => date("d-m-Y H:i:s"),
                    "sent_by" => $user->id,
                    "school" => $student->school, 
                    "branch" => $student->branch, 
                    "status" => "Pending"
                  ));

                  //Send Complete response
                  return response()->json(responder("success", "Class Ended", "Class has been ended successfully.", "reload()"));
            }
            else { 
                return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
            }
    	
      }else { 
          return response()->json(responder("error", "HMM!", "Something went wrong. Pelase connect with your Manager","reload()"));
      }
  }

}
