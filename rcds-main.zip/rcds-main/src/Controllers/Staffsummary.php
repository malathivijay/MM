<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\File;
use Simcify\Database;
use DotEnvWriter\DotEnvWriter;
use Simcify\Sms;

class Staffsummary {

    /**
     * Get settings view
     * 
     * @return \Pecee\Http\Response
     */
    public function get($userid) {
        $user      = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $cdetails = Database::table('users')->where('id',$userid)->first();
/*         if(isset($_GET['startdate']) && isset($_GET['enddate'])){
            $sdate = escape(input('startdate'));
            $edate = escape(input('enddate'));
            $cdate = date("Y-m-d");
            $agendaDayStart = $sdate." 00:00:00";
			$agendaDayEnd = $edate." 23:59:59";
			$range = $agendaDayStart."' AND '".$agendaDayEnd;
            $range2 = $sdate."' AND '".$edate;

            if (!isset($_GET['view'])) {
                $payslips = Database::table("payslips")->where('branch',$user->branch)->where('school',$user->school)->where('userid',$userid)->get();
                foreach($payslips as $payslip){
                    $details = Database::table('users')->where('id',$payslip->created_by)->first();
                    $payslip->createdby = $details->fname." ".$details->lname;

                    $details = Database::table('users')->where('id',$payslip->userid)->first();
                    $payslip->name = $details->fname." ".$details->lname;
                    $payslip->avatar = $details->avatar;
                    $payslip->phone = $details->phone;

                    $fdate = $payslip->year."-".$payslip->month;
                    $payslip->fmonth = date('F', strtotime($fdate));
                }
        }elseif (isset($_GET['view']) && $_GET['view'] == "staffattendance") {
            $staffattendance = Database::table("staffattendance")->where('branch',$user->branch)->where('school',$user->school)->where("userid", $userid)->get();
            foreach($staffattendance as $attendance){
                $data = str_replace(array('-','_'),array('+','/'),$attendance->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $attendance->comment = base64_decode($data); 

                $details = Database::table('users')->where('id',$attendance->created_by)->first();
                $attendance->createdby = $details->fname." ".$details->lname;
            }
        }elseif (isset($_GET['view']) && $_GET['view'] == "incentive") {
            $incentive = Database::table("incentive")->where("id", $userid)->where('branch',$user->branch)->where('school',$user->school)->get();
            foreach($incentive as $inc){
                $details = Database::table('users')->where('id',$inc->updateby)->first();
                $inc->updatedby = $details->fname." ".$details->lname;

                $data = str_replace(array('-','_'),array('+','/'),$inc->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $inc->comment = base64_decode($data); 
            }
        }elseif (isset($_GET['view']) && $_GET['view'] == "advance") {

            $advance = Database::table("advance")->where("id", $userid)->where('branch',$user->branch)->where('school',$user->school)->get();
                foreach($advance as $adv){
                    $details = Database::table('users')->where('id',$adv->updateby)->first();
                    $adv->updatedby = $details->fname." ".$details->lname;

                    $data = str_replace(array('-','_'),array('+','/'),$adv->comment);
                    $mod4 = strlen($data) % 4;
                    if ($mod4) {
                        $data .= substr('====', $mod4);
                    }
                    $adv->comment = base64_decode($data); 
            }
        }
    }else{ */
            $cdate = date("Y-m-d");
            if (!isset($_GET['view'])) {
                $payslips = Database::table("payslips")->where('branch',$user->branch)->where('school',$user->school)->where('userid',$userid)->get();
                foreach($payslips as $payslip){
                    $details = Database::table('users')->where('id',$payslip->created_by)->first();
                    $payslip->createdby = $details->fname." ".$details->lname;

                    $details = Database::table('users')->where('id',$payslip->userid)->first();
                    $payslip->name = $details->fname." ".$details->lname;
                    $payslip->avatar = $details->avatar;
                    $payslip->phone = $details->phone;

                    $fdate = $payslip->year."-".$payslip->month;
                    $payslip->fmonth = date('F', strtotime($fdate));
                }
        }elseif (isset($_GET['view']) && $_GET['view'] == "staffattendance") {
            $staffattendance = Database::table("staffattendance")->where('branch',$user->branch)->where('school',$user->school)->orderBy("created_at", false)->where("userid", $userid)->get();
            foreach($staffattendance as $attendance){
                $data = str_replace(array('-','_'),array('+','/'),$attendance->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $attendance->comment = base64_decode($data); 

                $details = Database::table('users')->where('id',$attendance->created_by)->first();
                $attendance->createdby = $details->fname." ".$details->lname;
            }
        }elseif (isset($_GET['view']) && $_GET['view'] == "incentive") {
            $incentive = Database::table("incentive")->where("id", $userid)->where('branch',$user->branch)->where('school',$user->school)->orderBy("date", false)->get();
            foreach($incentive as $inc){
                $details = Database::table('users')->where('id',$inc->updateby)->first();
                $inc->updatedby = $details->fname." ".$details->lname;

                $data = str_replace(array('-','_'),array('+','/'),$inc->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $inc->comment = base64_decode($data); 
            }
        }elseif (isset($_GET['view']) && $_GET['view'] == "advance") {

            $advance = Database::table("advance")->where("id", $userid)->where('branch',$user->branch)->where('school',$user->school)->orderBy("date", false)->get();
                foreach($advance as $adv){
                    $details = Database::table('users')->where('id',$adv->updateby)->first();
                    $adv->updatedby = $details->fname." ".$details->lname;

                    $data = str_replace(array('-','_'),array('+','/'),$adv->comment);
                    $mod4 = strlen($data) % 4;
                    if ($mod4) {
                        $data .= substr('====', $mod4);
                    }
                    $adv->comment = base64_decode($data); 

                    $staffattend = Database::table("staffattendance")->where("userid", $adv->id)->where('branch',$user->branch)->where('school',$user->school)->where("date", $adv->date)->first();

                    $adv->selfie = $staffattend->selfie;
            }
        }

            return view('staffsummary', compact("user","cdetails",'payslips',"staffattendance",'incentive','advance','date'));
    }
/* } */

}