<?php
namespace Simcify\Controllers;

use Simcify\Database;
use Simcify\Landa;
use Simcify\Auth;
use Simcify\File;
use Simcify\Sms;
use DotEnvWriter\DotEnvWriter;


class Payslip{

    /**
     * Get Payslip view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
          return view('errors/404');
        }
        $pendingamount = 0;
        $payslips = Database::table("payslips")->where('branch',$user->branch)->where('school',$user->school)->orderBy("created_at", false)->get();
        foreach($payslips as $payslip){
            $details = Database::table('users')->where('id',$payslip->created_by)->first();
            $payslip->createdby = $details->fname." ".$details->lname;

            $details = Database::table('users')->where('id',$payslip->userid)->first();
            $payslip->name = $details->fname." ".$details->lname;
            $payslip->avatar = $details->avatar;
            $payslip->phone = $details->phone;

            $fdate = $payslip->year."-".$payslip->month;
            $payslip->fmonth = date('F', strtotime($fdate));

            if($payslip->status==0){
              $pendingamount += $payslip->famount;
            }

        }
        return view('payslips', compact("payslips","user","pendingamount"));
    }

     /**
     * Download Payslip file
     * 
     * @return integer
     */
    public function download($payslipid) {
      $user = Auth::user();
      $payslip = Database::table('payslips')->where('branch',$user->branch)->where('school',$user->school)->where('id',$payslipid)->first();

      if($payslip->userid==""){
        return response()->json(responder("error", "HMM!", "Something went wrong. No Payslip Found.","reload()"));
      }
      $staff = Database::table('users')->where('id',$payslip->userid)->first();

      $mpdf = new \Mpdf\Mpdf([
                      'tempDir' => config("app.storage")."mpdf",
                        'margin_top' => 0,
                        'margin_left' => 0,
                        'margin_right' => 0,
                        'mirrorMargins' => true
                    ]);
      $mpdf->WriteHTML(self::payslipdownload($payslipid, "#fff"));
      $mpdf->Output("Payslip-".$staff->fname."_".$staff->lname."_".$payslip->month.$payslip->year.".pdf", 'D');
    }

    /**
     * Share Payslip file
     * 
     * @return integer
     */
    public function sharepayslip() {
      $user = Auth::user();
      $payslipid = escape(input('payslipid'));
      $payslip1 = Database::table('payslips')->where('branch',$user->branch)->where('school',$user->school)->where('id',$payslipid)->first();

      if($payslip1->userid==""){
        return response()->json(responder("error", "HMM!", "Something went wrong. No Payslip Found.","reload()"));
      }

      $length = date("i");
      if($length/2==0){
        $length = 25;
      }else{
        $length = 20;
      }
      $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
      $charactersLength = strlen($characters);
      $randomString = '';
      for ($i = 0;$i<$length;$i++) {
          $randomString .= $characters[rand(0, $charactersLength - 1)];
      }

      $payslip = Database::table('payslips')->where('id',$payslipid)->first();
      $mpdf = new \Mpdf\Mpdf([
                      'tempDir' => config("app.storage")."mpdf",
                        'margin_top' => 0,
                        'margin_left' => 0,
                        'margin_right' => 0,
                        'mirrorMargins' => true
                    ]);
      $mpdf->WriteHTML(self::payslipdownload($payslipid, "#fff"));
      $filename = $randomString.".pdf";
      $mpdf->Output(config("app.storage")."/payslips/".$filename, "F");

      $staff = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id", $payslip->userid)->first();
      $manager = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("role", "staff")->where("position", "manager")->first();

      if(strlen($manager->phone)>10){
        $mphone1 = substr($manager->phone,-10);
      }
      else{
        $mphone1 = $manager->phone;
      }

      $staffMessage = "Hello! ".$staff->fname." ".$staff->lname.",\n\nPlease find your Payslip copy below. If you have any query, Please connect with your Manager Mr. ".$manager->fname." ".$manager->lname." at Ph: ".$mphone1."\n\n".env("APP_NAME");

      if (!empty($staff->phone)) {
      $send = Sms::africastalking($staff->phone, $staffMessage);
        if ($send) {
            /* return response()->json(responder("success", "Sent", "Payslip details has been shared successfully","reload()")); */
        } else { 
            return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
        }
      }
      

      if(strlen($staff->phone)>10){
        $phoneNumber = "91".substr($staff->phone, -10);
      }else{
          $phoneNumber = "91".$staff->phone;
      }

/*       $fields = array(
        'receiver' => $phoneNumber,
        'message' => array(
                    'document' => array(
                              'url' => 'https://realcardriving.com/school/uploads/payslips/'.$filename),
                    'mimetype' => 'application/pdf',
                    'fileName' => 'RCDS-'.$staff->fname.'_Payslip.pdf'),
      ); */
      
/* https://file-example.s3-accelerate.amazonaws.com/documents/cv.pdf
http://realcardriving.com/school/uploads/payslips/'.$filename */

      $fields = array(
        "chatId" => $phoneNumber."@c.us",
        "contentType" => "MessageMediaFromURL",
        "content" => "https://realcardriving.com/school/uploads/payslips/".$filename
      );

      $json_string = json_encode($fields);

      $curl = curl_init();

      curl_setopt_array($curl, array(
        CURLOPT_URL => "http://localhost:8888/client/sendMessage/rcdsWhatsAppServer",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $json_string,
        CURLOPT_HTTPHEADER => array(
          "accept: */*",
          "Content-Type: application/json"
        ),
      ));

      $response = curl_exec($curl);
      $err = curl_error($curl);

      curl_close($curl);

      if ($err) {
        //echo "cURL Error #:" . $err;
        return response()->json(responder("error", "HMM!", "Something went wrong: ".$err , "reload()"));
      } else {
        return response()->json(responder("success", "Payslip Sent", "Payslip has been shared with Student." , "reload()"));
      } 

    }

    /**
     * Get Payslip view
     * 
     * @return \Pecee\Http\Response
     */
    public function payslipdownload($payslipid, $background = "#F8F8F8") {
      $user = Auth::user();
      $payslip = Database::table('payslips')->where('branch',$user->branch)->where('school',$user->school)->where('id',$payslipid)->first();

      if($payslip->userid==""){
        return response()->json(responder("error", "HMM!", "Something went wrong. No Payslip Found.","reload()"));
      }

      $payment = Database::table("accountdetails")->where("branch",$user->branch)->where("school",$user->school)->where("id",$payslip->userid)->first();

      $payslip->fmonth = $payslip->year."-".$payslip->month;
      $staff = Database::table('users')->where('id',$payslip->userid)->first();
      $accountdetails = Database::table('accountdetails')->where('id',$payslip->userid)->first();
      $school = Database::table('schools')->where('id',$payslip->school)->first();

      $tdays = date('t', strtotime($payslip->fmonth));

      $onedaysalary = $payment->salary/$tdays;
      $lop = round($payslip->adays*$onedaysalary);
      $hlop = round($payslip->hdays*$onedaysalary);
      $hdays = $payslip->hdays*2;
      $inwords = self::numberTowords($payslip->famount);
      $payslip->startdate = $payslip->date."-".$payslip->month."-".$payslip->year;

      $incentive = Database::table('incentive')->where('branch',$user->branch)->where('school',$user->school)->where('payslipid',$payslipid)->get();

      foreach($incentive as $inc){
        $data = str_replace(array('-','_'),array('+','/'),$inc->comment);
              $mod4 = strlen($data) % 4;
              if ($mod4) {
                  $data .= substr('====', $mod4);
              }
              $inc->comment = base64_decode($data);
      }

      $advance = Database::table('advance')->where('branch',$user->branch)->where('school',$user->school)->where('payslipid',$payslipid)->get();

      foreach($advance as $adv){
        $data = str_replace(array('-','_'),array('+','/'),$adv->comment);
              $mod4 = strlen($data) % 4;
              if ($mod4) {
                  $data .= substr('====', $mod4);
              }
              $adv->comment = base64_decode($data);
      }

      $month = $payslip->month;
      $year = $payslip->year;
      $base = array( 'MONTH(`date`)' => $month, 'YEAR(`date`)' => $year );

      $attendance = Database::table('staffattendance')->where(array_merge($base, array('branch'=>$user->branch, 'school'=>$user->school, 'marked'=>1, 'userid'=>$payslip->userid)))->get();

      foreach($attendance as $attend){
        if($attend->attendance=="Halfday"){
          $attend->pay = $onedaysalary/2;
        }else{
          $attend->pay = $onedaysalary;
        }
      }

      return view('payslipdownload', compact("payslip", "staff", "school", "background","accountdetails","lop","inwords","hlop","hdays","incentive","advance","attendance","adamount"));

  }

    /**
     * Get Payslip view
     * 
     * @return \Pecee\Http\Response
     */
    public function preview($payslipid, $background = "#F8F8F8") {
        $user = Auth::user();
        $payslip = Database::table('payslips')->where('branch',$user->branch)->where('school',$user->school)->where('id',$payslipid)->first();

        if($payslip->userid==""){
          return response()->json(responder("error", "HMM!", "Something went wrong. No Payslip Found.","reload()"));
        }

        $payment = Database::table("accountdetails")->where("branch",$user->branch)->where("school",$user->school)->where("id",$payslip->userid)->first();

        $payslip->fmonth = $payslip->year."-".$payslip->month;
        $staff = Database::table('users')->where('id',$payslip->userid)->first();
        $accountdetails = Database::table('accountdetails')->where('id',$payslip->userid)->first();
        $school = Database::table('schools')->where('id',$payslip->school)->first();

        $tdays = date('t', strtotime($payslip->fmonth));

        $onedaysalary = $payment->salary/$tdays;
        $lop = round($payslip->adays*$onedaysalary);
        $hlop = round($payslip->hdays*$onedaysalary);
        $hdays = $payslip->hdays*2;
        $inwords = self::numberTowords($payslip->famount);
        $payslip->startdate = $payslip->date."-".$payslip->month."-".$payslip->year;

        $incentive = Database::table('incentive')->where('branch',$user->branch)->where('school',$user->school)->where('payslipid',$payslipid)->get();

        foreach($incentive as $inc){
          $data = str_replace(array('-','_'),array('+','/'),$inc->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $inc->comment = base64_decode($data);
        }

        $advance = Database::table('advance')->where('branch',$user->branch)->where('school',$user->school)->where('payslipid',$payslipid)->get();

        foreach($advance as $adv){
          $data = str_replace(array('-','_'),array('+','/'),$adv->comment);
                $mod4 = strlen($data) % 4;
                if ($mod4) {
                    $data .= substr('====', $mod4);
                }
                $adv->comment = base64_decode($data);
        }

        $month = $payslip->month;
        $year = $payslip->year;
        $base = array( 'MONTH(`date`)' => $month, 'YEAR(`date`)' => $year );

        $attendance = Database::table('staffattendance')->where(array_merge($base, array('branch'=>$user->branch, 'school'=>$user->school, 'marked'=>1, 'userid'=>$payslip->userid)))->get();

        foreach($attendance as $attend){
          if($attend->attendance=="Halfday"){
            $attend->pay = $onedaysalary/2;
          }else{
            $attend->pay = $onedaysalary;
          }
        }

        return view('payslippreview', compact("payslip", "staff", "school", "background","accountdetails","lop","inwords","hlop","hdays","incentive","advance","attendance","adamount"));

    }

    public function numberTowords($num){

    $ones = array(
    0 =>"Zero",
    1 => "One",
    2 => "Two",
    3 => "Three",
    4 => "Four",
    5 => "Five",
    6 => "Six",
    7 => "Seven",
    8 => "Eight",
    9 => "Nine",
    10 => "Ten",
    11 => "Eleven",
    12 => "Twelve",
    13 => "Thirteen",
    14 => "Fourteen",
    15 => "Fifteen",
    16 => "Sixteen",
    17 => "Seventeen",
    18 => "Eighteen",
    19 => "Nineteen",
    "014" => "Fourteen"
    );
    $tens = array( 
    0 => "Zero",
    1 => "Ten",
    2 => "Twnety",
    3 => "Thirty", 
    4 => "Forty", 
    5 => "Fifty", 
    6 => "Sixty", 
    7 => "Seventy", 
    8 => "Eighty", 
    9 => "Ninety" 
    ); 
    $hundreds = array( 
    "Hundred", 
    "Thousand", 
    "Million", 
    "Billion", 
    "Trilion",
    "Quardrillion"
    ); //limit t quadrillion 
    $num = number_format($num,2,".",",");
$num_arr = explode(".",$num);
$wholenum = $num_arr[0];
$decnum = $num_arr[1];
$whole_arr = array_reverse(explode(",",$wholenum));
krsort($whole_arr);
$words = "";
foreach($whole_arr as $key => $i) {
if($i == 0) {
continue;
}
if($i < 20) {
$words .= $ones[intval($i)];
} elseif($i < 100) {
if(substr($i,0,1) == 0 && strlen($i) == 3) {
$words .= $tens[substr($i,1,1)];
if(substr($i,2,1) != 0) {
$words .= " ".$ones[substr($i,2,1)];
}
} else {
$words .= $tens[substr($i,0,1)];
if(substr($i,1,1) != 0) {
$words .= " ".$ones[substr($i,1,1)];
}
}
} else {
// $words .= $ones[substr($i,0,1)]." ".$hundreds[0].' and ';
if(substr($i,1,1) != 0 || substr($i,2,1) != 0) {
$words .= $ones[substr($i,0,1)]." ".$hundreds[0].' and ';
} else {
$words .= $ones[substr($i,0,1)]." ".$hundreds[0];
}
if(substr($i,1,2) < 20 && substr($i,1,1) != 0) {
$words .= " ".$ones[(substr($i,1,2))];
} else {
if(substr($i,1,1) != 0) {
$words .= " ".$tens[substr($i,1,1)];
}
if(substr($i,2,1) != 0) {
$words .= " ".$ones[substr($i,2,1)];
}
}
}
if($key > 0) {
$words .= " ".$hundreds[$key]." ";
}
}
/* $words .= $unit??' units'; */
if($decnum > 0) {
$words .= " and ";
if($decnum < 20) {
$words .= $ones[intval($decnum)];
} elseif($decnum < 100) {
$words .= $tens[substr($decnum,0,1)];
if(substr($decnum,1,1) != 0) {
$words .= " ".$ones[substr($decnum,1,1)];
}
}
$words .= $subunit??' subunits';
}
return $words;
    } 

}
