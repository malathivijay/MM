<?php
namespace Simcify\Controllers;

use Simcify\Database;
use Simcify\Landa;
use Simcify\Auth;
use Simcify\File;
use Simcify\Sms;
use DotEnvWriter\DotEnvWriter;


class Invoice{

    /**
     * Get invoice view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
          return view('errors/404');
        }
        $invoices = Database::table('invoices')->leftJoin('users','invoices.student','users.id')->where("invoices`.`branch", $user->branch)->orderBy('invoices.id', false)->get("`users.fname`", "`users.lname`", "`users.avatar`", "`users.email`", "`users.phone`","`invoices.id`", "`invoices.created_at`", "`invoices.amount`", "`invoices.amountpaid`", "`invoices.student`", "`invoices.reference`");
        return view('invoices', compact("invoices","user"));
    }

   /**
     * Add Payment invoice
     * 
     * @return null
     */
    public function addpayment() {
        $user = Auth::user();
        $invoice = Database::table('invoices')->where('id',input('invoice'))->first();
        $student = Database::table('users')->where('id',$invoice->student)->first();
        $data = array(
          'invoice'=>$invoice->id,
          'student'=>$invoice->student,
          'school'=>$invoice->school,
          'branch'=>$invoice->branch,
          'method'=>input('method'),
          'amount'=>input('amount'),
          'created_at'=>date('Y-m-d h:i:s', strtotime(input("payday")))
        );
        Database::table('payments')->insert($data);
        $data = array(
          'amountpaid'=>input('amount') + $invoice->amountpaid
        );
        Database::table('invoices')->where('id',$invoice->id)->update($data);
        $notification = 'You made a payment of <strong>'.money(input('amount')).'</strong>.';
        Landa::notify($notification, $invoice->student, "payment", "personal");
        $notification = 'A payment of <strong>'.money(input('amount')).'</strong> has been received from <strong>'.$student->fname.' '.$student->lname.'</strong>.';
        Landa::notify($notification, $user->id, "payment");

        return response()->json(responder("success", "Alright", "Payment successfully added.", "reload()"));
    }
    
    /**
     * Delete payment
     * 
     * @return Json
     */
    public function deletepayment() {
        $user = Auth::user();
        $payment = Database::table("payments")->where("id", input("paymentid"))->first();
        $invoice = Database::table('invoices')->where('id',$payment->invoice)->first();
        Database::table("payments")->where("id", input("paymentid"))->delete();
        $data = array(
          'amountpaid'=> $invoice->amount - $payment->amount
        );
        Database::table('invoices')->where('id',$invoice->id)->update($data);
        $notification = 'A payment record of <strong>'.money($payment->amount).'</strong> has been deleted from your account.';
        Landa::notify($notification, $invoice->student, "delete", "personal");
        $notification = 'A payment record of <strong>'.money($payment->amount).'</strong> has been deleted by <strong>'.$user->fname.' '.$user->lname.'</strong>.';
        Landa::notify($notification, $user->id, "delete");
        return response()->json(responder("success", "Payment Deleted", "Payment successfully deleted", "reload()"));
    }
    
    /**
     * View payments
     * 
     * @return Json
     */
    public function viewpayments() {
        $payments = Database::table("payments")->where("invoice", input("invoiceid"))->get();
        return view('extras/payments', compact("payments"));
      }
    
    /**
     * Update invoice
     * 
     * @return Json
     */
    public function update() {
        $data = array(
            "item" => escape(input("item")),
            "amount" => escape(input("amount"))
        );
        Database::table("invoices")->where("id", input("invoiceid"))->update($data);
        return response()->json(responder("success", "Alright", "Invoice successfully updated", "reload()"));
    }
    
    /**
     * Update invoice view
     * 
     * @return Json
     */
    public function updateview() {
        $invoice = Database::table("invoices")->where("id", input("invoiceid"))->first();
        return view('extras/updateinvoice', compact("invoice"));
    }
    
    /**
     * Delete invoice
     * 
     * @return Json
     */
    public function delete() {
        $user = Auth::user();
        $invoice = Database::table("invoices")->where("id", input("invoiceid"))->first();
        Database::table("invoices")->where("id", input("invoiceid"))->delete();
        $notification = 'Invoice #'.$invoice->reference.' of <strong>'.money($invoice->amount).'</strong> has been deleted from your account.';
        Landa::notify($notification, $invoice->student, "delete", "personal");
        $notification = 'Invoice #'.$invoice->reference.' of <strong>'.money($invoice->amount).'</strong>  has been deleted by <strong>'.$user->fname.' '.$user->lname.'</strong>.';
        Landa::notify($notification, $user->id, "delete");
        return response()->json(responder("success", "Invoice Deleted", "Invoice successfully deleted.", "reload()"));
    }


     /**
     * Download Invoice file
     * 
     * @return integer
     */
    public function download($invoiceid) {
      $invoice = Database::table('invoices')->where('id',$invoiceid)->first();
      $mpdf = new \Mpdf\Mpdf([
                      'tempDir' => config("app.storage")."mpdf",
                        'margin_top' => 0,
                        'margin_left' => 0,
                        'margin_right' => 0,
                        'mirrorMargins' => true
                    ]);
      $mpdf->WriteHTML(self::preview($invoiceid, "#fff"));
      $mpdf->Output("Invoice #".$invoice->reference.".pdf", 'D');
    }

    /**
     * Get invoice view
     * 
     * @return \Pecee\Http\Response
     */
    public function preview($invoiceid, $background = "#F8F8F8") {

        $invoice = Database::table('invoices')->where('id',$invoiceid)->first();
        $student = Database::table('users')->where('id',$invoice->student)->first();
        $school = Database::table('schools')->where('id',$invoice->school)->first();
        return view('invoicepreview', compact("invoice", "student", "school", "background"));

    }

    /**
     * Download Invoice file
     * 
     * @return integer
     */
    public function share() {
      $user = Auth::user();
      $invoiceid = escape(input('invoiceid'));
      $length = date("i");
      if($length/2==0){
        $length = 25;
      }else{
        $length = 20;
      }
      $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
      $charactersLength = strlen($characters);
      $randomString = '';
      for ($i = 0;$i<$length;$i++) {
          $randomString .= $characters[rand(0, $charactersLength - 1)];
      }

      $invoice = Database::table('invoices')->where('id',$invoiceid)->first();
      $mpdf = new \Mpdf\Mpdf([
                      'tempDir' => config("app.storage")."mpdf",
                        'margin_top' => 0,
                        'margin_left' => 0,
                        'margin_right' => 0,
                        'mirrorMargins' => true
                    ]);
      $mpdf->WriteHTML(self::preview($invoiceid, "#fff"));
      $filename = $randomString.".pdf";
      $mpdf->Output(config("app.storage")."/invoices/".$filename, "F");

      $student = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("id", $invoice->student)->first();
      $manager = Database::table("users")->where("branch",$user->branch)->where("school",$user->school)->where("role", "staff")->where("position", "manager")->first();

      if(strlen($manager->phone)>10){
        $mphone1 = substr($manager->phone,-10);
      }
      else{
        $mphone1 = $manager->phone;
      }

      $studentMessage = "Hello! ".$student->fname." ".$student->lname.",\n\nPlease find your Invoice copy below. If you have any query, Please connect with our Manager Mr. ".$manager->fname." ".$manager->lname." at Ph: ".$mphone1."\n\n".env("APP_NAME");

      if (!empty($student->phone)) {
      $send = Sms::africastalking($student->phone, $studentMessage);
        if ($send) {
            /* return response()->json(responder("success", "Sent", "Invoice details has been shared successfully","reload()")); */
        } else { 
            return response()->json(responder("error", "HMM!", "Something went wrong. Please connect with your Manager","reload()"));
        }
      }
      

      if(strlen($student->phone)>10){
        $phoneNumber = "91".substr($student->phone, -10);
      }else{
          $phoneNumber = "91".$student->phone;
      }

/*       $fields = array(
        'receiver' => $phoneNumber,
        'message' => array(
                    'document' => array(
                              'url' => 'http://realcardriving.com/school/uploads/invoices/'.$filename),
                    'mimetype' => 'application/pdf',
                    'fileName' => 'RCDS - '.$student->fname.'_Invoice.pdf'),
      ); */

      $fields = array(
        "chatId" => $phoneNumber."@c.us",
        "contentType" => "MessageMediaFromURL",
        "content" => "http://realcardriving.com/school/uploads/invoices/".$filename
      );
      
      $json_string = json_encode($fields);

      $curl = curl_init();

      curl_setopt_array($curl, array(
        CURLOPT_URL => "http://localhost:8888/client/sendMessage/rcdsWhatsAppServer",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $json_string,
        CURLOPT_HTTPHEADER => array(
          "Content-Type: application/json",
          "Accept-Encoding: gzip, deflate"
        ),
      ));

      $response = curl_exec($curl);
      $err = curl_error($curl);

      curl_close($curl);

      if ($err) {
        //echo "cURL Error #:" . $err;
        return response()->json(responder("error", "HMM!", "Something went wrong: ".$err , "reload()"));
      } else {
        return response()->json(responder("success", "Invoice Sent", "Invoice has been shared with Student." , "reload()"));
      } 

    }

}
