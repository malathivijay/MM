<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\Database;
use Simcify\File;
use Simcify\Sms;
use Simcify\Mail;
use Simcify\FS;

class Reschedule {

    /**
     * Get settings view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user      = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        if ($user->role == 'staff' && $user->position != 'manager') {
            return view('errors/404');
        }
        if(!isset($_REQUEST['view'])){
            $instructors = Database::table("users")->where("school", $user->school)->where("branch", $user->branch)->where("role", "instructor")->get();
            $trainers = Database::table("users")->where("school", $user->school)->where("branch", $user->branch)->where("role", "instructor")->get();
            return view('reschedule', compact("user", "instructors","trainers"));
        }
        if(isset($_REQUEST['view']) && $_REQUEST['view']=='utrainer'){
            $instructors = Database::table("users")->where("school", $user->school)->where("branch", $user->branch)->where("role", "instructor")->get();
            $fleet = Database::table("fleet")->where("school", $user->school)->where("branch", $user->branch)->get();
            $trainers = Database::table("users")->where("school", $user->school)->where("branch", $user->branch)->where("role", "instructor")->get();
            return view('reschedule', compact("user", "instructors", "fleet","trainers"));
        }

        return view('reschedule', compact("user"));
    }

    /**
     * Date Validator
     * 
     */

    public function validateDate($date, $format = 'Y-m-d')
    {
        $d = \DateTime::createFromFormat($format, $date);
        // The Y ( 4 digits year ) returns TRUE for any integer with any number of digits so changing the comparison from == to === fixes the issue.
        return $d && $d->format($format) === $date;
    }

    /**
     * Reschedule Classes
     * 
     * @return Json
     */
    public function classes() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        if ($user->role == 'staff' && $user->position != 'manager') {
            return view('errors/404');
        }

        $ldate = escape(input('cdate'));
        $validate = self::validateDate($ldate);
        $ldate = date('Y-m-d', strtotime(escape(input('cdate'))));

        if($validate==false){
            return response()->json(responder("error", "Invalid Date", "Given date is Invalid"));
        }

        //current schedule

        if(input('instructor')!="all"){
            $cschedule = Database::table('schedules')->where("schedules`.`start", "LIKE", "%" . $ldate . "%")->where("school", $user->school)->where("branch", $user->branch)->where("instructor", escape(input('instructor')))->get();        
            foreach($cschedule as $schedule){
                $attendancesr = Database::table('attendance')->where("date", $ldate)->where("school", $user->school)->where("branch", $user->branch)->where("id", $schedule->student)->where("status", 0)->first();
                $schedule->attendancesr = $attendancesr->sr;
            }
        }else{
            $cschedule = Database::table('schedules')->where("schedules`.`start", "LIKE", "%" . $ldate . "%")->where("school", $user->school)->where("branch", $user->branch)->get();
            foreach($cschedule as $schedule){
                $attendancesr = Database::table('attendance')->where("date", $ldate)->where("school", $user->school)->where("branch", $user->branch)->where("id", $schedule->student)->where("status", 0)->first();
                $schedule->attendancesr = $attendancesr->sr;
            }  
        }

        if(count($cschedule)==0){
            return response()->json(responder("error", "Hmm!", "Nothing is scheduled on ".$ldate));
        }

        //lastdate for all students

        $ladate = new \DateTime($ldate);

        foreach($cschedule as $lschedule){
            $lastdate = $ladate;
            $student = Database::table('schedules')->where("student", $lschedule->student)->get();
            foreach($student as $stud){
                $gdate = date('Y-m-d', strtotime($stud->start));
                $newlastdate = new \DateTime($gdate);
                if($lastdate<$newlastdate){
                    $lastdate=$newlastdate;
                }
            }
            $lschedule->lastdate = $lastdate->format("Y-m-d");
        }

        //add one day (also check if the next day is Sunday)

        foreach($cschedule as $nschedule){
            $formatted_date = new \DateTime($nschedule->lastdate);
            $date_timestamp = $formatted_date->getTimestamp();

            for( $i = 0; $i < 1; $i++ ) {
				// get what day it is next day
				$nextDay = date('w', strtotime('+1day', $date_timestamp) );
				// if it's Sunday or Saturday get $i-1
				if( $nextDay == 0 || ( $nextDay == 6 && $saturday_off ) ) { $i--; }
				// modify timestamp, add 1 day
				$date_timestamp = strtotime('+1day', $date_timestamp);
			}

            $formatted_date->setTimestamp($date_timestamp);
			$nschedule->fdate = $formatted_date->format( 'Y-m-d' );
            $nschedule->fsdate = $formatted_date->format( 'Y-m-d' )." ".date('H:i:s', strtotime($nschedule->start));
            $nschedule->fedate = $formatted_date->format( 'Y-m-d' )." ".date('H:i:s', strtotime($nschedule->end));

            $data = array(
                'start' => $nschedule->fsdate,
                'end' => $nschedule->fedate
            );
            $data2 = array(
                'date' => $nschedule->fdate
            );

            /* return response()->json(responder("success", "Alright", "I am here!")); */

            if($nschedule->attendancesr!=""){
                Database::table('schedules')->where('id', $nschedule->id)->update($data);
                Database::table('attendance')->where('sr', $nschedule->attendancesr)->update($data2);
                
                
					$course1 = Database::table('courses')->where('id',$nschedule->course)->first();
					$student1 = Database::table('users')->where('id',$nschedule->student)->first();
					$schedule1 = Database::table('schedules')->where('id',$nschedule->id)->first();
					$instructor1 = Database::table('users')->where('id',$nschedule->instructor)->first();
					$manager = Database::table("users")->where("branch", $nschedule->branch)->where("school", $nschedule->school)->where("position", "manager")->where("role", "staff")->first();
	
					if(strlen($instructor1->phone)>10){
						$phone1 = substr($instructor1->phone,-10);
					}
					else{
						$phone1 = $instructor1->phone;
					}

					if(strlen($manager->phone)>10){
						$mphone = substr($manager->phone,-10);
					}
					else{
						$mphone = $manager->phone;
					}
	
					$studentMessage = "Hello! ".$student1->fname.", your ".$schedule1->class_type." class for ".$course1->name." course which was earlier scheduled on ".$ldate." has been rescheduled at ".date('d-m-Y', strtotime($schedule1->start))." ".date('h:i A', strtotime($schedule1->start))." with Mr. ".$instructor1->fname." ".$instructor1->lname." Ph: ".$phone1."\n\nIf you have any query, Please connect with our Manager Mr. ".$manager->fname." ".$manager->lname." at Ph: ".$mphone."\n\nRegards,\n".env("APP_NAME");

					if (!empty($student1->phone)) {
						/* $send = Sms::africastalking($student1->phone, $studentMessage);
						if ($send) { $status = "Sent"; } else { $status = "Failed"; } */
						Database::table("usermessages")->insert(array(
							"receiver" => $student1->id, 
                            "type" => "whatsapp", 
                            "contact" => $student1->phone,
                            "Subject" => "Class Reschedule",
							"message" => escape($studentMessage),
                            "scheduled_at" => date("d-m-Y H:i:s"),
                            "sent_by" => $user->id,
							"school" => $student1->school, 
                            "branch" => $student1->branch, 
                            "status" => "Pending"
						));
					}
				

            }
            
        }

        /* return view('rescheduled', compact("user", "cschedule")); */

        return response()->json(responder("success", "Alright", "All the classess has been reschduled form ".$ldate));
     
    }

    /**
     * List students
     * 
     * @return Json
     */
    public function liststudents() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        if ($user->role == 'staff' && $user->position != 'manager') {
            return view('errors/404');
        }

        $cdate = escape(input('cdate'));
        $instructor = escape(input('instructor'));
        $car = escape(input('car'));

        $check = 0;

        if(!empty($cdate)){
            $check = 1;
        }elseif(!empty($instructor)){
            $check = 1;
        }elseif(!empty($car)){
            $check = 1;
        }

        if($check==0){
            return response()->json(responder("error", "Hmm!", "Please select atleast one of the filter."));
        }

        // if(!empty($cdate) && !empty($instructor) && !empty($car)){
        //     $result = Database::table('schedules')->where("start", "LIKE", "%" . $cdate . "%")->where("instructor", $instructor)->where("car", $car)->get();
        // }elseif(!empty($cdate) && !empty($instructor) && empty($car)){
        //     $result = Database::table('schedules')->where("start", "LIKE", "%" . $cdate . "%")->where("instructor", $instructor)->get();
        // }elseif(!empty($cdate) && empty($instructor) && !empty($car)){
        //     $result = Database::table('schedules')->where("start", "LIKE", "%" . $cdate . "%")->where("car", $car)->get();
        // }elseif(empty($cdate) && !empty($instructor) && !empty($car)){
        //     $result = Database::table('schedules')->where("instructor", $instructor)->where("car", $car)->get();
        // }elseif(!empty($cdate) && empty($instructor) && empty($car)){
        //     $result = Database::table('schedules')->where("start", "LIKE", "%" . $cdate . "%")->get();
        // }elseif(empty($cdate) && !empty($instructor) && empty($car)){
        //     $result = Database::table('schedules')->where("instructor", $instructor)->get();
        // }elseif(empty($cdate) && empty($instructor) && !empty($car)){
        //     $result = Database::table('schedules')->where("car", $car)->get();
        // }

        $students = Database::table('schedules')->where('instructor', 11)->get();

        if(empty($students)){
            return response()->json(responder("error", "Hmm!", "No result found."));
        }

        return view('selectstudents', compact("user","students"));
    }

    /**
     * Update Trainer
     * 
     * @return Json
     */
    public function updatetrainer(){
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        if ($user->role == 'staff' && $user->position != 'manager') {
            return view('errors/404');
        }

        if(isset($_REQUEST['oldInstructor'])){

            $oldInstructor = escape(input('oldInstructor'));
            $newInstructor = escape(input('newInstructor'));
            $cdate = escape(input('cdate'));

            if($oldInstructor==$newInstructor){
                return response()->json(responder("error", "Hmm!", "New Trainer can not be same as Current Trainer.", "reload()"));
            }

            //take database backup

            $host = "localhost";
            $username = "root";
            $password = "";
            $database = "rcds4";
            $table = "schedules";

            // Backup file path and name
            $backup_file = "/Applications/XAMPP/htdocs/databasechanges/" . date("Y-m-d-H-i-s") . "-" . $database."_".$table.".sql";

            // MySQL dump command
            $command = "/Applications/XAMPP/xamppfiles/bin/mysqldump -h $host -u $username -p $password $database $table > $backup_file";

/*             // Backup file path and name
            $backup_file = "/var/backups/mysql/realcardriving/" . date("Y-m-d-H-i-s") . "-" . $database."_".$table.".sql";

            // MySQL dump command
            $command = "/opt/lampp/bin/mysqldump -h $host -u $username -p $password $database $table > $backup_file";  */

            // Execute the command
            system($command, $output);

            // Check if backup was successful
            if ($output == 0) {
            //echo "Database backup successful!";
            //return response()->json(responder("success", "Database backup successful!", "reload()"));
                $message = "*Mass Update Notification*\n\n Trainer has been updated for the below students:";
                $error = "*Mass Update Notification*\n\n Trainer has been *not been* updated for the below students:";
                $errorStatus = 0;
                $success = 0;

                $data = array(
                   'instructor' => $newInstructor
                );

                if(!empty($cdate)){
                    $oldrecords = Database::table('schedules')->where(array(
                        'school' => $user->school,
                        'branch' => $user->branch,
                        'instructor' => $oldInstructor,
                        'status' => "New"
                    ))->where("start", "LIKE", "%" . $cdate . "%")->get();

                    if(empty($oldrecords)){
                        return response()->json(responder("error", "Hmm!", "No record Found.", "reload()"));
                    }

                    // update data in records
                    foreach($oldrecords as $oldrecord){
                        Database::table('schedules')->where("id", $oldrecords->id)->where("start", "LIKE", "%" . $cdate . "%")->update($data);
                    }
                }else{
                    $oldrecords = Database::table('schedules')->where(array(
                        'school' => $user->school,
                        'branch' => $user->branch,
                        'instructor' => $oldInstructor,
                        'status' => "New"
                    ))->get();

                    if(empty($oldrecords)){
                        return response()->json(responder("error", "Hmm!", "No record Found.", "reload()"));
                    }

                    // update data in records
                    foreach($oldrecords as $oldrecord){
                        Database::table('schedules')->where("id", $oldrecord->id)->update($data);
                    }
                }

                //get names
                $newInstructorDetails = Database::table("users")->where("id", $newInstructor)->first();
                $oldInstructorDetails = Database::table("users")->where("id", $oldInstructor)->first();
                $updatedby = Database::table("users")->where("id", $user->id)->first();

                //check udpate
                foreach($oldrecords as $oldrecord){
                    $newrecords = Database::table('schedules')->where("id", $oldrecord->id)->first();
                    if($newrecords->instructor!=$newInstructor){
                        $student = Database::table("users")->where("id", $oldrecord->student)->first();
                        $error .= "\n\nS-SID :".$oldrecord->id."-".$oldrecord->student."\nName :".$student->fname." ".$student->lname."\nPhone :".$student->phone."\nOld Instructor :".$oldInstructorDetails->fname." ".$oldInstructorDetails->lname."\nNew Instructor :".$newInstructorDetails->fname." ".$newInstructorDetails->lname."\nUpdatedBy :".$updatedby->fname." ".$updatedby->lname;
                        $errorStatus ++;
                    }else{
                        $student = Database::table("users")->where("id", $oldrecord->student)->first();
                        $message .= "\n\nS-SID :".$oldrecord->id."-".$oldrecord->student."\nName :".$student->fname." ".$student->lname."\nPhone :".$student->phone."\nOld Instructor :".$oldInstructorDetails->fname." ".$oldInstructorDetails->lname."\nNew Instructor :".$newInstructorDetails->fname." ".$newInstructorDetails->lname."\nUpdatedBy :".$updatedby->fname." ".$updatedby->lname;
                        $success++;
                    }
                }

                //create a usermessage
                $message .= "\n\nRCDS - Real Car Drivign School.";
                $error .= "\n\nTotal Errors:".$errorStatus."\n\nRCDS - Real Car Drivign School.";

                //send message to superadmin 1

                $superadmin = Database::table("users")->where("id", 1)->first();

                if (!empty($superadmin->phone)) {
                    //success message
                    Database::table("usermessages")->insert(array(
                        "receiver" => $superadmin->id, 
                        "type" => "whatsapp", 
                        "contact" => $superadmin->phone,
                        "Subject" => "Mass Update Success",
                        "message" => escape($message),
                        "scheduled_at" => date("d-m-Y H:i:s"),
                        "sent_by" => $user->id,
                        "school" => $superadmin->school, 
                        "branch" => $superadmin->branch, 
                        "status" => "Pending"
                    ));

                    if($errorStatus>0){
                    //error message
                    Database::table("usermessages")->insert(array(
                        "receiver" => $superadmin->id, 
                        "type" => "whatsapp", 
                        "contact" => $superadmin->phone,
                        "Subject" => "Mass Update Error",
                        "message" => escape($error),
                        "scheduled_at" => date("d-m-Y H:i:s"),
                        "sent_by" => $user->id,
                        "school" => $superadmin->school, 
                        "branch" => $superadmin->branch, 
                        "status" => "Pending"
                    ));
                    }
                }

                //send message to respective manager 

                $manager = Database::table("users")->where("branch", $user->branch)->where("school", $user->school)->where("position", "manager")->where("role", "staff")->first();

                if (!empty($manager->phone)) {
                    //success message
                    Database::table("usermessages")->insert(array(
                        "receiver" => $manager->id, 
                        "type" => "whatsapp", 
                        "contact" => $manager->phone,
                        "Subject" => "Mass Update Success",
                        "message" => escape($message),
                        "scheduled_at" => date("d-m-Y H:i:s"),
                        "sent_by" => $user->id,
                        "school" => $manager->school, 
                        "branch" => $manager->branch, 
                        "status" => "Pending"
                    ));

                    if($errorStatus>0){
                    //error message
                    Database::table("usermessages")->insert(array(
                        "receiver" => $manager->id, 
                        "type" => "whatsapp", 
                        "contact" => $manager->phone,
                        "Subject" => "Mass Update Error",
                        "message" => escape($error),
                        "scheduled_at" => date("d-m-Y H:i:s"),
                        "sent_by" => $user->id,
                        "school" => $manager->school, 
                        "branch" => $manager->branch, 
                        "status" => "Pending"
                    ));
                    }
                }

                return response()->json(responder("success", "Alright", "Details Updated Successfully. Success: ".$success." Failure: ".$errorStatus, "reload()"));
                
            } else{
                return response()->json(responder("error", "Hmm!", "Database backup failed! Not able to udpate details.", "reload()"));
            }
        }else{
            return response()->json(responder("error", "Hmm!", "Please select New Trainer."));
        }
    }


}