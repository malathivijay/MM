<?php
namespace Simcify\Controllers;

use Simcify\Auth;
use Simcify\Database;
use Simcify\File;

class Newfleetrecord {
    
    /**
     * Get fleet view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user        = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        if ($user->role == 'staff') {
            if ($user->position == 'amanager') {
                return true;
            }elseif ($user->position == 'manager') {
                return true;
            }else{
                return view('errors/404');
            } 
        }
        if(isset($_REQUEST['fleet'])){
            $instructors = Database::table('users')->where(array(
                'branch' => $user->branch,
                'school' => $user->school,
                'role' => 'instructor'
            ))->get();

            $fleetId = escape(input('fleet'));

            $fleet = Database::table('fleet')->where('branch', $user->branch)->where('school', $user->school)->where('id', $fleetId)->first();
            $fleetchecks = Database::table('fleetChecks')->get();
            if(!empty($fleet)){
                foreach ($fleet as $car) {
                    if (empty($car->instructor)) {
                        $car->instructor = "Un-Assigned";
                    } else {
                        $instructor = Database::table('users')->where('id', $car->instructor)->first();
                        if (!empty($instructor)) {
                            $car->instructor = $instructor->fname . " " . $instructor->lname;
                        } else {
                            $car->instructor = "Un-Assigned";
                        }
                    }
                }
                return view('newfleetrecord', compact("user", "instructors", "fleet","fleetchecks"));
            }else{
            redirect(url("Fleet@get"));
            }
        }else{
            redirect(url("Fleet@get"));
        }
    }
    
    /**
     * Add fleet
     * 
     * @return Json
     */
    public function addnew() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        if ($user->role == 'staff') {
            if ($user->position == 'amanager') {
                return true;
            }elseif ($user->position == 'manager') {
                return true;
            }else{
                return view('errors/404');
            } 
        }

        $dataStatus = array(
            'car' => escape(input('carId')),
            'date' => date("Y-m-d"),
            'score' => 0,
            'comment' => escape(input('summary')),
            'createdby' => $user->id,
            'status80to99' => 0,
            'status60to80' => 0,
            'status40to60' => 0,
            'status0to40' => 0,
            'statusOther' => 0,
            'branch' => $user->branch,
            'school' => $user->school
        );

        $fleetchecks = Database::table('fleetChecks')->get();
        $hComments = "";
        $wComments = "";

        foreach($fleetchecks as $fleetcheck){
            $fleetcheck->status = escape(input('status'.$fleetcheck->checkName));
            $fleetcheck->action = escape(input('action'.$fleetcheck->checkName));

            if($fleetcheck->status<=5 && $fleetcheck->status>0){
                if($fleetcheck->action<=5 && $fleetcheck->action>0){
                    $dataStatus[$fleetcheck->checkName] = $fleetcheck->status.".".$fleetcheck->action;
                    if($fleetcheck->status==5){
                        $dataStatus['status80to99']++;
                    }elseif($fleetcheck->status==4){
                        $dataStatus['status60to80']++;
                    }elseif($fleetcheck->status==3){
                        $dataStatus['status40to60']++;
                    }elseif($fleetcheck->status==2){
                        $dataStatus['status0to40']++;
                    }elseif($fleetcheck->status==1){
                        $dataStatus['statusOther']++;
                    }

                    $dataStatus['score'] += $fleetcheck->status;

                    //gathering comments
                    if(!empty($_REQUEST['comment'.$fleetcheck->checkName])){
                    $hComments .= "<br>;".$fleetcheck->name.": ".escape(input('comment'.$fleetcheck->checkName));
                    $wComments .= "\n".$fleetcheck->name.": ".escape(input('comment'.$fleetcheck->checkName));
                    }

                }else{
                    return response()->json(responder("error", "HMM!", "Please select correct action for ".$fleetcheck->name));
                }
            }else{
                return response()->json(responder("error", "HMM!", "Please select correct status for ".$fleetcheck->name));
            }           
        }

        if(!empty($_REQUEST['commentfrontPhoto'])){
            $hComments .= "<br>Front Photo: ".escape(input('commentfrontPhoto'));
            $wComments .= "\nFront Photo: ".escape(input('commentfrontPhoto'));
        }
        if(!empty($_REQUEST['commentrightPhoto'])){
            $hComments .= "<br>Driver Side Photo: ".escape(input('commentrightPhoto'));
            $wComments .= "\nDriver Side Photo: ".escape(input('commentrightPhoto'));
        }
        if(!empty($_REQUEST['commentbackPhoto'])){
            $hComments .= "<br>Back Photo: ".escape(input('commentbackPhoto'));
            $wComments .= "\nBack Photo: ".escape(input('commentbackPhoto'));
        }
        if(!empty($_REQUEST['commentleftPhoto'])){
            $hComments .= "<br>Conductor Side Photo: ".escape(input('commentleftPhoto'));
            $wComments .= "\nConductor Side Photo: ".escape(input('commentleftPhoto'));
        }
        if(!empty($_REQUEST['commentopenBonnet'])){
            $hComments .= "<br>Engine Photo: ".escape(input('commentopenBonnet'));
            $wComments .= "\nEngine Photo: ".escape(input('commentopenBonnet'));
        }

        if(!empty($hComments)){
            $dataStatus['comment'] .= "<br><br>Below are the specific comments:<br>".$hComments;
            $dataStatus['wcomment'] .= "\n\nBelow are the specific comments:\n".$wComments;
        }

        $comment = base64_encode($dataStatus['comment']);
        $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
        $dataStatus['comment']= $comment;

        $comment = base64_encode($dataStatus['wcomment']);
        $comment = str_replace(array('+','/','='),array('-','_',''),$comment);
        $dataStatus['wcomment']= $comment;

        if(isset($_FILES['frontPhoto'])){

            $target_file = basename($_FILES["frontPhoto"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

            if(isset($_REQUEST["frontPhoto"])) {
                $check = getimagesize($_FILES["frontPhoto"]["tmp_name"]);
                if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
                } else {
                echo "File is not an image.";
                $uploadOk = 0;
                }
            }
            
            // Check file size
            if ($_FILES["frontPhoto"]["size"] > 5000000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }
            
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "pdf" &&$imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }
            
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                return response()->json(responder("error", "HMM!", "Something went wrong with the file. Please check described deatils for file."));
            }

            $upload = File::upload(
                $_FILES['frontPhoto'], 
                "mrecords"
                ,array(
                    "source" => "form"
                     )
            );
    
            if($upload['status'] == 'success'){
                $dataStatus['frontPhoto']= $upload['info']['name'];
            }
            
        }else{
            return response()->json(responder("error", "HMM!", "Please take front side picture of the car."));
        }

        if(isset($_FILES['rightPhoto'])){

            $target_file = basename($_FILES["rightPhoto"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

            if(isset($_REQUEST["rightPhoto"])) {
                $check = getimagesize($_FILES["rightPhoto"]["tmp_name"]);
                if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
                } else {
                echo "File is not an image.";
                $uploadOk = 0;
                }
            }
            
            // Check file size
            if ($_FILES["rightPhoto"]["size"] > 5000000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }
            
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "pdf" &&$imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }
            
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                return response()->json(responder("error", "HMM!", "Something went wrong with the file. Please check described deatils for file."));
            }

            $upload = File::upload(
                $_FILES['rightPhoto'], 
                "mrecords"
                ,array(
                    "source" => "form"
                     )
            );
    
            if($upload['status'] == 'success'){
                $dataStatus['rightPhoto']= $upload['info']['name'];
            }
            
        }else{
            return response()->json(responder("error", "HMM!", "Please take right side picture of the car."));
        }

        if(isset($_FILES['backPhoto'])){

            $target_file = basename($_FILES["backPhoto"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

            if(isset($_REQUEST["backPhoto"])) {
                $check = getimagesize($_FILES["backPhoto"]["tmp_name"]);
                if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
                } else {
                echo "File is not an image.";
                $uploadOk = 0;
                }
            }
            
            // Check file size
            if ($_FILES["backPhoto"]["size"] > 5000000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }
            
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "pdf" &&$imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }
            
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                return response()->json(responder("error", "HMM!", "Something went wrong with the file. Please check described deatils for file."));
            }

            $upload = File::upload(
                $_FILES['backPhoto'], 
                "mrecords"
                ,array(
                    "source" => "form"
                     )
            );
    
            if($upload['status'] == 'success'){
                $dataStatus['backPhoto']= $upload['info']['name'];
            }
            
        }else{
            return response()->json(responder("error", "HMM!", "Please take Back side picture of the car."));
        }

        if(isset($_FILES['leftPhoto'])){

            $target_file = basename($_FILES["leftPhoto"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

            if(isset($_REQUEST["leftPhoto"])) {
                $check = getimagesize($_FILES["leftPhoto"]["tmp_name"]);
                if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
                } else {
                echo "File is not an image.";
                $uploadOk = 0;
                }
            }
            
            // Check file size
            if ($_FILES["leftPhoto"]["size"] > 5000000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }
            
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "pdf" &&$imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }
            
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                return response()->json(responder("error", "HMM!", "Something went wrong with the file. Please check described deatils for file."));
            }

            $upload = File::upload(
                $_FILES['leftPhoto'], 
                "mrecords"
                ,array(
                    "source" => "form"
                     )
            );
    
            if($upload['status'] == 'success'){
                $dataStatus['leftPhoto']= $upload['info']['name'];
            }
            
        }else{
            return response()->json(responder("error", "HMM!", "Please take left side picture of the car."));
        }

        if(isset($_FILES['openBonnet'])){

            $target_file = basename($_FILES["openBonnet"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

            if(isset($_REQUEST["openBonnet"])) {
                $check = getimagesize($_FILES["openBonnet"]["tmp_name"]);
                if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
                } else {
                echo "File is not an image.";
                $uploadOk = 0;
                }
            }
            
            // Check file size
            if ($_FILES["openBonnet"]["size"] > 5000000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }
            
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "pdf" &&$imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }
            
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                return response()->json(responder("error", "HMM!", "Something went wrong with the file. Please check described deatils for file."));
            }

            $upload = File::upload(
                $_FILES['openBonnet'], 
                "mrecords"
                ,array(
                    "source" => "form"
                     )
            );
    
            if($upload['status'] == 'success'){
                $dataStatus['openBonnet']= $upload['info']['name'];
            }
            
        }else{
            return response()->json(responder("error", "HMM!", "Please take Engine picture of the car."));
        }

        $status = Database::table('fleetmaintainancerecords')->insert($dataStatus);
        $check = Database::table('fleetmaintainancerecords')->where('date', $dataStatus['date'])->first();
        if(!empty($check)){
            return response()->json(responder("success", "Done!", "Record Details Saved Successfully.", "reload()"));
        }else{
            return response()->json(responder("error", "HMM!", "Something went wrong. Please check if all records are selected."));
        }

        /* print_r($dataStatus); */
        
        
    }
    
    
    /**
     * Delete car
     * 
     * @return Json
     */
    public function delete() {
        Database::table("fleet")->where("id", input("carid"))->delete();
        return response()->json(responder("success", "Car Deleted", "Car successfully deleted flom fleet", "reload()"));
    }
    
    /**
     * Car update view
     * 
     * @return \Pecee\Http\Response
     */
    public function updateview() {
        $user        = Auth::user();
        $instructors = Database::table('users')->where(array(
            'branch' => $user->branch,
            'role' => 'instructor'
        ))->get();
        $car         = Database::table("fleet")->where("id", input("carid"))->first();
        return view('extras/updatecar', compact("car", "instructors"));
    }
    
    /**
     * Update Car
     * 
     * @return Json
     */
    public function update() {
        $data = array(
            'carno_' => escape(input('carno')),
            'carplate' => escape(input('carplate')),
            'make' => escape(input('make')),
            'model' => escape(input('model')),
            'instructor' => escape(input('instructor')),
            'modelyear' => escape(input('modelyear'))
        );
        Database::table("fleet")->where("id", input("carid"))->update($data);
        return response()->json(responder("success", "Alright", "Car successfully updated", "reload()"));
    }
    
}