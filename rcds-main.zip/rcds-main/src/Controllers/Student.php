<?php
namespace Simcify\Controllers;

use Simcify\Database;
use Simcify\Landa;
use Simcify\Auth;
use Simcify\Mail;

class Student{

    /**
     * Get students view
     * 
     * @return \Pecee\Http\Response
     */
    public function get() {
        $user = Auth::user();
        if ($user->role != 'superadmin' && $user->role != 'admin' && $user->role != 'staff') {
            return view('errors/404');
        }
        $date = date("Y-m-d");
        if (isset($_GET['search']) OR isset($_GET['gender'])) {
            if (!empty($_GET['gender']) && !empty($_GET['search'])) {
                $students = Database::table('users')->where(array(
                    'role' => 'student',
                    'school' => $user->school,
                    'gender' => $_GET['gender'],
                    'isWaiting' => 0
                ))->orWhere("fname", "LIKE", "%" . $_GET['search'] . "%")->where(array(
                    'role' => 'student',
                    'branch' => $user->branch,
                    'isWaiting' => 0
                ))->orderBy('id', false)->get();
            } elseif (!empty($_GET['gender'])) {
                $students = Database::table('users')->where(array(
                    'role' => 'student',
                    'school' => $user->school,
                    'gender' => $_GET['gender'],
                    'isWaiting' => 0
                ))->orderBy('id', false)->get();
            } elseif (!empty($_GET['search'])) {
                $students = Database::table('users')->where(array(
                    'role' => 'student',
                    'school' => $user->school,
                    'isWaiting' => 0
                ))->where("fname", "LIKE", "%" . $_GET['search'] . "%")->orderBy('id', false)->get();
            } else {
                $students = Database::table('staffs')->where(array(
                    'role' => 'student',
                    'school' => $user->school,
                    'isWaiting' => 0
                ))->orderBy('id', false)->get();
            }
        } else {
            $students = Database::table('users')->where(array(
                'role' => 'student',
                'school' => $user->school,
                'isWaiting' => 0
            ))->orderBy('id', false)->get();
        }

        foreach ($students as $student) {
            $student->courses = Database::table('coursesenrolled')->where('student', $student->id)->count("id", "total")[0]->total;
            $student->completed = Database::table('schedules')->where('student', $student->id)->where('status', "Complete")->count("id", "total")[0]->total;
            $student->total = Database::table('schedules')->where('student', $student->id)->count("id", "total")[0]->total;

            $date = date("Y-m-d");
            $scheduled = Database::table('schedules')->where('student', $student->id)->where("start", "LIKE", "%" . $date . "%")->first();
            $plate = Database::table('fleet')->where('id', $scheduled->car)->first();
            if($scheduled->start!=""){
                $instructor = Database::table('users')->where('id', $scheduled->instructor)->first();
                $student->instructor = $instructor->fname." ".$instructor->lname."<br>".$instructor->phone." at ";
                $student->fleet = $plate->carplate;
                $student->schedule = date('H:i', strtotime($scheduled->start));
                $student->instructor .= $student->schedule;
                $student->schedule = $student->instructor;
                
            }else{
                $student->fleet = "N/A";
                $student->schedule = "N/A";
            }

            $getdate = Database::table('schedules')->where('student', $student->id)->get();

            foreach($getdate as $getdat){
    
                $date_set = date('Y-m-d', strtotime($getdat->start));
                $date_now = date('Y-m-d');
    
                if ($date_set > $date_now) {
                    $date_now = $date_set;
                }
    
            }
    
            $student->lastdate = $date_now;

            $payments = Database::table("invoices")->where("student", $student->id)->first();
            $student->balance = $payments->amount-$payments->amountpaid;

            $trainingitems = Database::table('attendance')->where('id', $student->id)->get();
            foreach($trainingitems as $items){
                if($items->trainingitems!=""){
                $ttrainingitem .= $items->trainingitems.",";
                }
            }
            $lesson1 = explode(',',$ttrainingitem);
            $lesson = array_unique($lesson1);
            $k=1;
            for($i=0;$i<=count($lesson1);$i++){
                if($lesson[$i]!=""){
                $clessonDetails = Database::table('practicallessons')->where('id', $lesson[$i])->first();
                $student->completeslesson .= "<label>".$k.": ".$clessonDetails->name.": ".$clessonDetails->description."</label><br>";
                $k++;
                }
            }
    
            $j=1;
            $clessonDetails = Database::table('practicallessons')->get();
            $tlessons = 0;
            foreach($clessonDetails as $clesson){
              $tlessons++;
                $com=0;
                for($i=0;$i<count($lesson1);$i++){
                    if($clesson->id==$lesson[$i]){
                    $com=1;
                    }
                }
                if($com==0){
                    $student->pendinglesson .= "<label>".$j.": ".$clesson->name.": ".$clesson->description."</label><br>";
                    $j++;
                }
            }
    
            $student->tlcomplete = $k-1;
            $student->tlpending = $j-1;
            $student->tlessons = $tlessons;

            //get new license enrolement and check license status

            $student->licenseStatus = "notrequired";

            if($student->drivinglicense<3){
                $getenrolement = Database::table('newdrivinglicense')->where('student', $student->id)->first();
                if(!empty($getenrolement)){
                    $student->licenseStatus = "enrolled";
                }else{
                    $student->licenseStatus = "notenrolled";
                }
            }

        }

        $courses = Database::table('courses')->where('school',$user->school)->where('status',"Available")->get();
        return view('students', compact("user", "students", "courses"));
    }
  
    
    /**
     * Create student Account
     * 
     * @return Json
     */
    public function create() {
        $user = Database::table("users")->where("email", input('email'))->first();
        if (!empty($user)) {
            return response()->json(array(
                "status" => "error",
                "title" => "Email Already exists.",
                "message" => "Email Already exists."
            ));
        }
        $user = Auth::user();
        $school = Database::table("schools")->where("id", $user->school)->first();
        $password = rand(111111, 999999);
        $iswaiting = escape(input('isWaiting'));

        if($iswaiting=="ongoing"){
            $waiting=0;
        }elseif($iswaiting=="waiting"){
            $waiting=1;
        }elseif($iswaiting=="cancelled"){
            $waiting=2;
        }elseif($iswaiting=="completed"){
            $waiting=3;
        }else{
            $waiting=0;
        }

        $signup   = Auth::signup(array(
            "fname" => escape(input('fname')),
            "lname" => escape(input('lname')),
            "email" => escape(input('email')),
            "address" => escape(input('address')),
            "drivinglicense" => escape(input('drivinglicense')),
            "car" => escape(input('car')),
            "location" => escape(input('location')),
            "phone" => escape(input('phone')),
            "alternatephone" => escape(input('altphone')),
            "gender" => escape(input('gender')),
            "permissions" => escape(input('permissions')),
            "branch" => $user->branch,
            "password" => Auth::password($password),
            "school" => $user->school,
            "role" => 'student',
            "isWaiting" => $waiting
        ), array(
            "authenticate" => false,
            "uniqueEmail" => escape(input('email'))
        ));
        
        
        if ($signup["status"] == "success") {
            $timeline = 'Account created by <strong>'.$user->fname.' '.$user->lname.'</strong>';
            Landa::timeline($signup["id"], $timeline);  
            Landa::notify($timeline, $signup["id"], "newaccount", "personal");
            $notification = 'New Student account created for <strong>'.input('fname').' '.input('lname').'</strong>.';
            Landa::notify($notification, $user->id, "newaccount");
          // send welcome email
            /*Mail::send(input('email'), "Welcome to " . $school->name. "!", array(
                "title" => "Welcome to " . $school->name . "!",
                "subtitle" => "Your school (" . $school->name . ") has created a student account for you at " . env("APP_NAME") . ".",
                "buttonText" => "Login Now",
                "buttonLink" => env("APP_URL"),
                "message" => "These are your login Credentials:<br><br><strong>Email:</strong>" . input('email') . "<br><strong>Password:</strong>" . $password . "<br><br>Cheers!<br>" . env("APP_NAME") . " Team."
            ), "withbutton");*/


            if (!empty(input("newcourse"))) {
              self::enroll($signup["id"], escape(input("newcourse")));
              self::createinvoice($signup["id"], escape(input("newcourse")), escape(input("amountpaid")), escape(input("method")));
            }


            return response()->json(responder("success", "Account Created", "Student account successfully created", "reload()"));
        }else{
          return response()->json(responder("error", "Hmm!", "Something went wrong please try again."));
        }
        
    }


    /**
     * Add course
    *
    */
    public function addcourse(){
        if($_REQUEST['amountpaid']==""){
            $amountpaid = 0;
        }
        $amountpaid = escape(input('amountpaid'));
        if($_REQUEST['discount']==""){
            $discount = 0;
        }
        $discount = escape(input('discount'));
        self::enroll(escape(input("studentid")), escape(input("newcourse")));
        self::createinvoice(escape(input("studentid")), escape(input("newcourse")), $amountpaid , escape(input("method")), $discount);
        return response()->json(responder("success", "Alright", "Student successfully enrolled to the course", "reload()"));
    }

    /**
     * Enroll student to a course
    *
     * @return true
    */
    private function enroll($students, $course){
        $user = Auth::user();
        $school = Database::table('schools')->where('id',$user->school)->first();
        $course = Database::table('courses')->where('id',$course)->first();
        $student = Database::table('users')->where('id',$students)->first();

        $data = array(
            'school'=>$user->school,
            'branch'=>$user->branch,
            'student'=>$student->id,
            'course'=>$course->id,
            'total_theory'=>$course->theory_classes,
            'total_practical'=>$course->practical_classes
        );
        Database::table('coursesenrolled')->insert($data);   
          $timeline = 'Enrolled to <strong>'.$course->name.'</strong> course.';
          Landa::timeline($student->id, $timeline);  
        // send enrollment email
        /*  Mail::send($student->email, "Course enrollment at ".$school->name, array(
              "message" => "Hello ".$student->fname.",<br><br>You have successfully been enrolled to <strong>(" . $course->name . ")</strong> course at ".$school->name.". <br>This course will have <strong>".$course->practical_classes." practical classes</strong> and <strong>".$course->theory_classes." theory classes</strong>. <br><br>Cheers!<br>" . $school->name. " Team."
          ), "basic");*/

          return true;
    }

    /**
     * Delete student Enrollment student to a course
    *
     * @return true
    */
    public function deleteenrollment(){
        Database::table('coursesenrolled')->where("id", input("enrollmentid"))->delete();
        return response()->json(responder("success", "Alright", "Student enrollment successfully deleted", "reload()"));
    }

    /**
     * Create an invoice
    *
     * @return true
    */
    private function createinvoice($students, $course, $amountpaid, $paymentmethod, $discount){

        $user = Auth::user();
        $school = Database::table('schools')->where('id',$user->school)->first();
        $course = Database::table('courses')->where('id',$course)->first();
        $student = Database::table('users')->where('id',$students)->first();

        $reference = rand(111111,999999);
        $data = array(
            'school'=>$user->school,
            'branch'=>$user->branch,
            'student'=>$student->id,
            'reference'=> $reference,
            'item'=>$course->name,
            'amount'=>$course->price-$discount,
            'amountpaid'=>$amountpaid,
            'discount'=>$discount
          );  
          Database::table('invoices')->insert($data); 
          $invoiceId = Database::table('invoices')->insertId();  

          if ($amountpaid > 0) {
            $data = array(
                'invoice'=>$invoiceId,
                'school'=>$user->school,
                'branch'=>$user->branch,
                'student'=>$student->id,
                'method'=>$paymentmethod,
                'amount'=>$amountpaid
            );   
            Database::table('payments')->insert($data);
            $notification = 'You made a payment of <strong>'.money($amountpaid).'</strong>.';
            Landa::notify($notification, $student->id, "payment", "personal");
            $notification = 'A payment of <strong>'.money($amountpaid).'</strong> has been received from <strong>'.$student->fname.' '.$student->lname.'</strong>.';
            Landa::notify($notification, $user->id, "payment");
          }  


        // send invoice email
          /*Mail::send($student->email, $school->name." invoice #".$reference, 
            array(
                "title" => "Thank you for joining us!",
                "subtitle" => "This is an invoice for your ".$school->name." enrollment. <strong>$".$amountpaid." </strong> paid.",
                "summary" => array(
                                "currency" => currency(),
                                "subtotal" => $course->price,
                                "tax" => 0,
                                "total" => $course->price,
                            ),
                "items" => array(
                            array(
                                "name" => $course->name,
                                "quantity" => "1",
                                "price" => $course->price,
                            )
                        )
            ), "invoice");*/

          return true;

    }


}
