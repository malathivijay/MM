<?php
namespace Simcify;

use AfricasTalking\SDK\AfricasTalking;
use Twilio\Rest\Client;

class Sms {

    /**
     * Send SMS With Africa's Talking
     * 
     * @param   string $phone number
     * @param   string $message
     * @return  array
     */
    public static function sms($phoneNumber,$message) {

        $url = 'https://api.mailjet.com/v4/sms-send';
 
        $curl = curl_init();
        
        $fields = array(
            'Text' => $message,
            'To' => $phoneNumber,
            'From' => 'RCDS'
        );
        
        $json_string = json_encode($fields);
        
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, TRUE);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $json_string);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Authorization: Bearer 471880dc0f56497789ac68cddcc8354b','Content-Type: application/json'));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true );
        
        //$data = curl_exec($curl);
        $err = curl_error($curl);

        if ($err) {
            return false;
        }else{
        return true;
        }

        curl_close($curl);

    }

    public static function africastalking($phoneNumber,$message,$sms="no") {

        if(strlen($phoneNumber)>10){
            $phoneNumber = "+91".substr($phoneNumber, -10);
        }else{
            $phoneNumber = "+91".$phoneNumber;
        }

        $fields = array(
            'receiver' => $phoneNumber,
            'message' => array('text'=>$message)
        );
        
        $json_string = json_encode($fields);

        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => "http://127.0.0.1:8888/chats/send?id=rCdSwHaTsApPsErVeR7549",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => $json_string,
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "Accept-Encoding: gzip, deflate"
          ),
        ));
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        
        curl_close($curl);

        $send= true;

        if($sms=="yes"){
            $send = sms($phoneNumber,$message);
        }
        
        if ($err) {
          return false;
        }else {
            return true;
        }

        

    }

    public static function getchat($phoneNumber) {

        $instance = "instance15144";
        $token = "fjhizcx35bv6aqm3";

        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api.ultramsg.com/".$instance."/chats/messages?token=".$token."&chatId=".$phoneNumber."@c.us&limit=",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "content-type: application/x-www-form-urlencoded"
        ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
        return "cURL Error #:" . $err;
        } else {
        return json_decode($response, true);
        }

        

    }

    public static function getcommunication() {

        $instance = "instance14870";
        $token = "7pl1t2hvigzeur5e";

        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api.ultramsg.com/".$instance."/chats?token=".$token,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "content-type: application/x-www-form-urlencoded"
        ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
        return "cURL Error #:" . $err;
        } else {
        return json_decode($response, true);
        }

        

    }

    /**
     * Send SMS With Twilio
     * 
     * @param   string $phone number
     * @param   string $message
     * @return  array
     */
    public static function twilio($phoneNumber,$message) {

        $client = new Client(env('TWILIO_SID'), env('TWILIO_AUTHTOKEN'));
        try{ 
            $response = $client->account->messages->create(
                $phoneNumber,
                array(
                    'from' => env('TWILIO_PHONENUMBER'), 
                    'body' => $message
                )
            );
          }catch(\Exception $e){  
            return false;
          }

        if ($response->status == "sent" || $response->status == "queued") {
            return true;
        }else{
            return false;
        }
    }
}

