<?php
namespace Simcify\Exceptions;

use Exception;

class DatabaseException extends Exception {}
