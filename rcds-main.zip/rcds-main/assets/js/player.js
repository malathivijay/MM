/*!
 * player.js
 * Version 1.0 - built Sat, Oct 6th 2018, 01:12 pm
 * https://simcycreative.com
 * Simcy Creative - <hello@simcycreative.com>
 * Private License
 */


/*
 *  Load a lecture to player
 */
 function loadLecture(lectureid) {
 	$(".previous-lecture, .next-lecture").show();
 	$(".player-canvas").html('<div class="loader-box"><div class="circle-loader"></div></div>');
 	var posting = $.post(lectureUrl, {
					        "lectureid": lectureid,
					        "csrf-token": Cookies.get("CSRF-TOKEN")
					    });
	posting.done(function (response) {
		$(".player-canvas").html(response);
	});
	markComplete(lectureid);
 }


/*
 *  Mark Lecture has complete
 */
 function markComplete(lectureid) {
 	$(".lecture-item").removeClass("active");
 	$(".lecture-item[data-id="+lectureid+"]").addClass("active complete");
 }


/*
 *  Start Class
 */
 $(".start-class").click(function(){
 	var lectureId = $(".lecture-item").first().attr("data-id");
 	loadLecture(lectureId);
 })


/*
 *  Open a lecture
 */
 $(".lecture-item").click(function(){
 	var lectureId = $(this).attr("data-id");
 	loadLecture(lectureId);
 })


/*
 *  Next lecture
 */
 $(".next-lecture").click(function(){
 	var activeLecture = $(".lecture-item.active");
 	var activeChapter = $(".lecture-item.active").closest(".chapters-list");
 	if ($(".lecture-item.active").next().length) {
 		var lectureId = $(".lecture-item.active").next().attr("data-id");
 		loadLecture(lectureId);
 	}else if(activeChapter.next().length){
 		var nextChapter = activeChapter.next();
 		if (nextChapter.find(".lecture-item").length) {
	 		var lectureId = nextChapter.find(".lecture-item").first().attr("data-id");
	 		loadLecture(lectureId);
 		}
 	}else{
 		var totalLectures = $(".lecture-item").length;
 		var completedLectures = $(".lecture-item.complete").length;
 		if (totalLectures > completedLectures) {
 			notify("The end!", "You have reached the end but there are some lectures you have not completed.", "warning", "Okay");
 		}else{
 			notify("Hooray!", "You have successfully completed this class..", "success", "Great!");
 		}
 	}
 });

/*
 *  Previous lecture
 */
 $(".previous-lecture").click(function(){
 	var activeLecture = $(".lecture-item.active");
 	var activeChapter = $(".lecture-item.active").closest(".chapters-list");
 	if ($(".lecture-item.active").prev().length) {
 		var lectureId = $(".lecture-item.active").prev().attr("data-id");
 		loadLecture(lectureId);
 	}else if(activeChapter.prev().length){
 		var nextChapter = activeChapter.prev();
 		if (nextChapter.find(".lecture-item").length) {
	 		var lectureId = nextChapter.find(".lecture-item").last().attr("data-id");
	 		loadLecture(lectureId);
 		}
 	}
 });



